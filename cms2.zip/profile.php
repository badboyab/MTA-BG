<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
include("./includes/files/session.disconnect.php");
 
$pageid = "config";
$pagename = "Paramètres";

if(isset($_POST['textamigo']) && isset($_POST['online']) && isset($_POST['join']))
{
$textamigo = Securise($_POST['textamigo']);
$online = Securise($_POST['online']);
$join = Securise($_POST['join']);
if($join != "" && $online != "" && $textamigo != "") {
if(is_numeric($textamigo) && is_numeric($online) && is_numeric($join)) {
mysql_query("UPDATE users SET block_newfriends = '".$textamigo."', hide_online = '".$online."', hide_inroom = '".$join."' WHERE id = '".$user['id']."'");
$message = "<div class=\"result\">Profil actualité</div>";
} else {
$message = "<div class=\"result\">Une erreur c'est produit lors de la modification.</div>";
}
} else {
$message = "<div class=\"result\">Merci de remplir les champs vide.</div>";
}
}

if(isset($_POST['currentPassword']) && isset($_POST['newPassword']) && isset($_POST['retypedNewPassword']))
{
$mdpactuel = Securise($_POST['currentPassword']);
$mdpnew = Securise($_POST['newPassword']);
$mdpnewre = Securise($_POST['retypedNewPassword']);
$mdp5actuel = Hashage($mdpactuel);
$md5 = Hashage($mdpnew);
if($mdp5actuel == $user['password']){
if($mdpnew == $mdpnewre){
if(strlen($mdpnew) < 6){
$result = "<div class=\"result\">Ton mot de passe est trop court !</div>";
}  else {
if(strlen($mdpnew) > 25){
$result = "<div class=\"result\">Ton mot de passe est trop long !</div>";
} else {
mysql_query("UPDATE users SET password = '".$md5."' WHERE username = '".$user['username']."' and password = '".$mdp5actuel."'") or die(mysql_error());
$result  = "<div class=\"result\">Profil actualité</div>";
}
}
} else {
$result = "<div class=\"result\">Les mots de passe ne correspondent pas.</div>";
}
} else {
$result = "<div class=\"result\">Le mot de passe actuel n'est pas celui-ci.</div>";
}
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/gallery/css/global.css?<?php echo $update; ?>">
<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<style type="text/css">
    .Offline{
        color: darkred;
    }
    .Online{
        color: darkgreen;
    }
    .badge-box{
        background-image: linear-gradient(#fff,#eee);
        height: 70px;
        width: 65px;
        text-align: center;
        line-height: 89px;
        border-radius: 4px;
        border: solid 1px #000;
        border-bottom: solid 2px #000;
        float: left;
        display: inline-block;
        margin-bottom: 2px;
        margin-right: 2px;
    }
    .center .titre{
    background-color: #444;
    color: #fff;
    border-radius: 4px 4px 0px 0px;
    padding: 8px;
    font-size: 16px;
    text-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);
    border: solid 1px rgba(0, 0, 0, 0.3);
}

.center .box{
    border-radius: 0px 0px 4px 4px;
    background-color: #fff;
    border: solid 1px rgba(0, 0, 0, 0.3);
    border-bottom: solid 2px rgba(0, 0, 0, 0.3);
    padding: 8px;
    clear: both;
    overflow: hidden;
    margin: auto;
    border-top: none;
    box-shadow: 1px 0px 0px rgba(255, 255, 255, 0.3), -1px -1px 0px rgba(255, 255, 255, 0.3);
}
    </style>
</head>
<div class="center">
<body id="home" class=" ">

<?php include("./templates/header.php"); ?>
<div class="page-contenu">
            <div class="left" id="column4">
                <div class="titre">Navigation</div>
                <div class="box">
                    <nav class="settings">
                        <ul>
                            <?php $do2 = $_GET['parametre']; if($do2 == "password") { ?>
                            <li>
                                <a href="<?php echo Settings('Url'); ?>/parametre">Général</a>
                            </li>
                            <li class="actif">
                                <a href="<?php echo Settings('Url'); ?>/parametre/password">Mot de passe</a>
                            </li>
                            <?php } else { ?>
                            <li class="actif">
                                <a href="<?php echo Settings('Url'); ?>/parametre">Général</a>
                            </li>
                            <li >
                                <a href="<?php echo Settings('Url'); ?>/parametre/password">Mot de passe</a>
                            </li>
                            <?php } ?>
                        </ul>
                    </nav>
                </div>
            </div>
            <div class="right" id="column5" style="margin:0;">
                <?php $do2 = $_GET['parametre']; if($do2 == "password") { ?>
                <div class="titre">Modifier mes informations</div>
                <div class="box">
                    
                                

                                        <form method="post">
                                            <?php if(isset($result)) { echo $result; } ?>
                                                <h3>Mot de passe</h3> 
                        <p> 
                        Change ton mot de passe, pour plus de sécurité mettez un mot de passe jamais utilisé:<br />
                        <input type="password" name="currentPassword" placeholder="Ancien mot de passe"><br/>
                        <input type="password" name="newPassword" placeholder="Nouveau mot de passe">
                        <input type="password" name="retypedNewPassword" placeholder="Confirmer nouveau mot de passe">
                        </p> 

                        <input type="submit" value="Enregistrer les modifcations">
                    </form>                 
                                    </div>
                <?php } ?>
                <?php $do2 = $_GET['parametre']; if($do2 != "password") { ?> 
                <div class="titre">Modifier mes informations</div>
                <div class="box">
                                        <form method="post">
                                            <?php if(isset($message)) { echo $message; } ?>
                                            <h3>Textamigo</h3> 
                    <p> 
                    <label><input type="radio" name="textamigo" value="0" <?php if($user['block_newfriends'] == "0") { ?> checked="checked" <?php } ?> />Accepter</label> 
                    <label><input type="radio" name="textamigo" value="1" <?php if($user['block_newfriends'] == "1") { ?> checked="checked" <?php } ?> />Refuser</label> 
                    </p> 
                     
                    <h3>Connexion</h3> 
                    <p> 
                    Choisis qui peut voir si tu es ou non connecté:<br /> 
                    <label><input type="radio" name="online" value="1" <?php if($user['hide_online'] == "1") { ?> checked="checked" <?php } ?> />Personne</label> 
                    <label><input type="radio" name="online" value="0" <?php if($user['hide_online'] == "0") { ?> checked="checked" <?php } ?>  />Tout le monde</label>  
                    </p> 
                     
                     
                    <h3>Préférences &quot;rejoindre&quot;</h3> 
                    <p> 
                    Choisis qui peut te suivre où que tu ailles:<br /> 
                    <label><input type="radio" name="join" value="1" <?php if($user['hide_inroom'] == "1") { ?> checked="checked" <?php } ?>  />Personne</label> 
                    <label><input type="radio" name="join" value="0" <?php if($user['hide_inroom'] == "0") { ?> checked="checked" <?php } ?> />Mes amis</label> 
                    </p> 

                    <input type="submit" value="Enregistrer les modifications">

                    </form>
                    
                                

                                    </div>
                    <?php } ?>
            </div>
        </div>
</div>
<!-- FOOTER -->
<?php include("./templates/footer.php"); ?>
<!-- FIN FOOTER -->

</body>
</html>