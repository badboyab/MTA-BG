<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/session.disconnect.php");

$pageid = 4;
  
if($user['rank'] < 7) {
Redirect("".Settings('Url')."");
}

if($user['rank'] >= 7) {
$deban = $_GET['value'];
if(isset($deban)) {
mysql_query("DELETE FROM bans WHERE value = '".$deban."'") or die(mysql_error());
if(Settings('Emulator') == "Azure") {
mysql_query("DELETE FROM users_bans WHERE value = '".$deban."'") or die(mysql_error());
}
mysql_query("INSERT INTO retrophp_stafflog (pseudo,action,date) VALUES ('".$user['username']."','Dé-bannissement (".$deban."). ','".time()."')");	
Redirect("".Settings('Url')."/admin/bans");			
}	
}

include("./templates/header.php");
?>
<div class="row">

			<div class="col-md-12">
				<article class="widget">
					<header class="widget__header">
						<h3 class="widget__title">Listes des joueurs bannis...</h3>
					</header>

					<div class="widget__content">
						<table class="table">
							<tbody>
								<?php $bans = mysql_query("SELECT * FROM bans ORDER BY id DESC"); while($ban_user = mysql_fetch_array($bans)) { ?>
								<tr>
									<td><?php echo $ban_user['value']; ?></td>
									<td>Pour la raison : <?php echo $ban_user['reason']; ?></td>
									<td>Banni par : <?php echo $ban_user['added_by']; ?></td>
									<td>Expire le : <?php echo $date." ".date('H:i:s', $ban_user['expire']); ?></td>
									<td><a href="<?php echo Settings('Url'); ?>/admin/bans/<?php echo $ban_user['value']; ?>" class="btn btn-red" style="text-decoration:none;">Débannir</a></td>
								</tr>
								<?php } ?>

								<?php if(Settings('Emulator') == "Azure") { $bans = mysql_query("SELECT * FROM users_bans ORDER BY id DESC"); while($ban_user = mysql_fetch_array($bans)) { ?>
								<tr>
									<td><?php echo $ban_user['value']; ?></td>
									<td>Pour la raison : <?php echo $ban_user['reason']; ?></td>
									<td>Banni par : <?php echo $ban_user['added_by']; ?></td>
									<td>Expire le : <?php echo $date." ".date('H:i:s', $ban_user['expire']); ?></td>
									<td><a href="<?php echo Settings('Url'); ?>/admin/bans/<?php echo $ban_user['value']; ?>" class="btn btn-red" style="text-decoration:none;">Débannir</a></td>
								</tr>
								<?php }} ?>
							</tbody>
						</table>

					</article>
				</div>

			</div>
<?php include("./templates/footer.php"); ?>