<!doctype html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Administration</title>
	<link href="<?php echo Settings('Url'); ?>/admin/css/bootstrap/bootstrap.min.css?<?php echo $update; ?>" rel="stylesheet" />
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
	<link rel="stylesheet" href="<?php echo Settings('Url'); ?>/admin/css/jquery-jvectormap-1.2.2.css?<?php echo $update; ?>"/>
	<link href="<?php echo Settings('Url'); ?>/admin/css/style.css?<?php echo $update; ?>" rel="stylesheet" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>

</head>
<body>

	<header class="top-bar">
		<a class="mobile-nav" href="#"><i class="pe-7s-menu"></i></a>
		<div class="main-logo"><span><?php echo Settings('Name'); ?></span></div>
		<?php $sql = mysql_query("SELECT * FROM retrophp_settings WHERE Maintenance = 'true'"); while($s = mysql_fetch_array($sql)) { ?>
		<input type="checkbox" id="s-logo" class="sw" disabled checked/>
		<label class="switch switch--dark switch--header" for="s-logo"></label>
		<?php } $sql = mysql_query("SELECT * FROM retrophp_settings WHERE Maintenance = 'false'"); while($s = mysql_fetch_array($sql)) {?>
		<input type="checkbox" id="s-logo" class="sw" disabled/>
		<label class="switch switch--dark switch--header" for="s-logo"></label>
		<?php } ?>
		
		<div class="main-search">
			<form method="post" action="./users" autocomplete="off">
			<input type="text" placeholder="Recherche d'un joueur" name="username" id="msearch">
		</form>
			<label for="msearch">
				<i class="pe-7s-search"></i>
			</label>
		</div>
		<ul class="profile">
			<li>
				<a class="dropdown-toggle" data-toggle="dropdown" href="#" onclick="return false;" class="profile__user">
					<figure class="pull-left rounded-image profile__img">
						<img class="media-object" src="<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $user['look']; ?>&action=&direction=2&head_direction=2" alt="user">
					</figure>
					<span class="profile__name">
						<span><?php echo $user['username']; ?></span> <i class="pe-7s-angle-down"></i>
					</span>
				</a>
				<ul class="dropdown-menu pull-right">
					<li><a href="<?php echo Settings('Url'); ?>/account/logout"><i class="icon pe-7s-close-circle"></i> Déconnexion</a></li>
				</ul>
			</li>
			<?php if($user['rank'] >= 10) { ?>
			<li>
				<a href="<?php echo Settings('Url'); ?>/admin/site">
					<i class="pe-7f-config"></i>
				</a>
			</li>
			<?php } ?>
		</ul>

	</header>

	<div class="wrapper">

		<aside class="sidebar">
			<ul class="main-nav">
				<?php if($pageid == 1) { ?>
				<li class="main-nav--active">
				<?php } else { ?> 
				<li class="main-nav--collapsible">
				<?php } ?>
					<a class="main-nav__link" style="text-decoration:none;" href="<?php echo Settings('Url'); ?>/admin/">
						<span class="main-nav__icon"><i class="icon pe-7s-home"></i></span>
						Accueil
					</a>
				</li>
				<li>
				<?php if($user['rank'] >= 10) { ?>
				<?php if($pageid == 2) { ?>
				<li class="main-nav--active">
				<?php } else { ?> 
				<li class="main-nav--collapsible">
				<?php } ?>
					<a class="main-nav__link" style="text-decoration:none;" href="<?php echo Settings('Url'); ?>/admin/site">
						<span class="main-nav__icon"><i class="icon pe-7s-tools"></i></span>
						Configuration
					</a>
					<ul class="main-nav__submenu">
						<li><a href="<?php echo Settings('Url'); ?>/admin/site/boutique"><i class="icon pe-7s-tools"></i><span>Boutique</span></a></li>
					</ul>
				</li>
				<?php } ?>

				<?php if($user['rank'] >= 9) { ?>
				<?php if($pageid == 3) { ?>
				<li class="main-nav--active">
				<?php } else { ?> 
				<li class="main-nav--collapsible">
				<?php } ?>
					<a class="main-nav__link" style="text-decoration:none;" href="<?php echo Settings('Url'); ?>/admin/staffs">
						<span class="main-nav__icon"><i class="icon pe-7s-star"></i></span>
						Gestion d'équipe
					</a>
				</li>
				<?php } ?>

				<?php if($user['rank'] >= 7) { ?>
				<?php if($pageid == 9) { ?>
				<li class="main-nav--active">
				<?php } else { ?> 
				<li class="main-nav--collapsible">
				<?php } ?>
					<a class="main-nav__link" style="text-decoration:none;" href="<?php echo Settings('Url'); ?>/admin/users">
						<span class="main-nav__icon"><i class="icon pe-7s-shopbag"></i></span>
						Utilisateurs
					</a>
				</li>
				<?php } ?>

				<?php if($pageid == 4) { ?>
				<li class="main-nav--active">
				<?php } else { ?> 
				<li class="main-nav--collapsible">
				<?php } ?>
					<a class="main-nav__link" style="text-decoration:none;" href="<?php echo Settings('Url'); ?>/admin/bans">
						<span class="main-nav__icon"><i class="icon pe-7s-lock"></i></span>
						Gestion des bans
					</a>
				</li>

				<?php if($user['rank'] >= 8) { ?>
				<?php if($pageid == 5) { ?>
				<li class="main-nav--active">
				<?php } else { ?> 
				<li class="main-nav--collapsible">
				<?php } ?>
					<a class="main-nav__link" style="text-decoration:none;" href="<?php echo Settings('Url'); ?>/admin/new">
						<span class="main-nav__icon"><i class="icon pe-7s-photo-gallery"></i></span>
						Poster un article
					</a>
				</li>
				<?php } ?>

				<?php if($user['rank'] >= 9) { ?>
				<?php if($pageid == 6) { ?>
				<li class="main-nav--active">
				<?php } else { ?> 
				<li class="main-nav--collapsible">
				<?php } ?>
					<a class="main-nav__link" style="text-decoration:none;" href="<?php echo Settings('Url'); ?>/admin/delete_new">
						<span class="main-nav__icon"><i class="icon pe-7s-trash"></i></span>
						Supprimer un article
					</a>
				</li>
				<?php } ?>

				<?php if($pageid == 7) { ?>
				<li class="main-nav--active">
				<?php } else { ?> 
				<li class="main-nav--collapsible">
				<?php } ?>
					<a class="main-nav__link" style="text-decoration:none;" href="<?php echo Settings('Url'); ?>/admin/logs_site">
						<span class="main-nav__icon"><i class="icon pe-7s-server"></i></span>
						Historique du site
					</a>
				</li>

				<?php if($pageid == 8) { ?>
				<li class="main-nav--active">
				<?php } else { ?> 
				<li class="main-nav--collapsible">
				<?php } ?>
					<a class="main-nav__link" style="text-decoration:none;" href="<?php echo Settings('Url'); ?>/admin/logs_hotel">
						<span class="main-nav__icon"><i class="icon pe-7s-menu"></i></span>
						Historique des commandes
					</a>
				</li>
				
			</ul>
		</aside>
		
		<section class="content">
			<header class="main-header clearfix">
				<h1 class="main-header__title">
					<i class="icon pe-7s-home"></i>
					Administration
				</h1>
				<ul class="main-header__breadcrumb">
					<li><a style="text-decoration:none; "><?php echo SystemConfig('server_ver'); ?></a></li>
				</ul>
				<div class="main-header__date">
					<i class="icon pe-7s-date"></i>
					<span><?php echo $date." ".date('', time()); ?></span>
					<i class="pe-7s-angle-down-circle"></i>
				</div>
			</header>
			
			<div class="main-stats row">
				<div class="main-stats__stat col-lg-3 col-md-12 col-sm-12">
					<h3 class="stat__title">NOMBRES D'INSCRITS</h3>
					<div class="stat__number" id="inscrit"> <?php echo $nb_inscrit['id']; ?></div>
					<div class="progress" id="progress-inscrit">
						<div class="progress-bar progress-bar--skyblue" role="progressbar" aria-valuenow="<?php echo $nb_inscrit['id']; ?>" aria-valuemin="0" aria-valuemax="1000" style="width: <?php echo $nb_inscrit['id'] / 50; ?>%;"></div>
					</div>
				</div>
				
				<div class="main-stats__stat col-lg-3 col-md-12 col-sm-12">
					<h3 class="stat__title">JOUEURS CONNECTÉS</h3>
					<div class="stat__number" id="online"> <?php echo $online['id']; ?></div>
					<div class="progress" id="progress-online">
						<div class="progress-bar progress-bar--anzac" role="progressbar" aria-valuenow="<?php echo $online['id']; ?>" aria-valuemin="0" aria-valuemax="<?php echo SystemConfig('record_connect'); ?>" style="width: <?php echo $online['id']; ?>%;"></div>
					</div> 
				</div> 

				<div class="main-stats__stat col-lg-3 col-md-12 col-sm-12">
					<h3 class="stat__title">NOMBRES DE VISITES</h3>
					<div class="stat__number" id="visites"> <?php echo $nb_visites['id']; ?></div>
					<div class="progress" id="progress-visites">
						<div class="progress-bar progress-bar--green" role="progressbar" aria-valuenow="<?php echo $nb_visites['id']; ?>" aria-valuemin="0" aria-valuemax="500" style="width: <?php echo $nb_visites['id'] / 50; ?>%;"></div>
					</div>
				</div> 

				<div class="main-stats__stat col-lg-3 col-md-12 col-sm-12">
					<h3 class="stat__title">RECORD DE CONNEXION</h3>
					<div class="stat__number" id="record"> <?php echo SystemConfig('record_connect'); ?></div>
					<div class="progress" id="progress-record">
						<div class="progress-bar progress-bar--red" role="progressbar" aria-valuenow="<?php echo SystemConfig('record_connect'); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo SystemConfig('record_connect'); ?>%;"></div>
					</div>
				</div>
			</div>