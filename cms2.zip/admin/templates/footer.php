<footer class="main-footer">
				<a class="back-top" href="#"><i class="pe-7s-angle-up-circle"></i></a>
				<p>2015 © <?php echo Settings('Name'); ?>.</p>
			</footer>

		</div>

		<script type="text/javascript" src="<?php echo Settings('Url'); ?>/admin/js/jquery-1.10.2.min.js?<?php echo $update; ?>"></script>
		<!-- <script type="text/javascript" src="<?php echo Settings('Url'); ?>/admin/js/reload.js?<?php echo $update; ?>"></script> -->
		<script type="text/javascript" src="<?php echo Settings('Url'); ?>/admin/js/jquery-ui.js?<?php echo $update; ?>"></script>
		<script type="text/javascript" src="<?php echo Settings('Url'); ?>/admin/js/bootstrap.min.js?<?php echo $update; ?>"></script>
		<script type="text/javascript" src="<?php echo Settings('Url'); ?>/admin/js/amcharts.js?<?php echo $update; ?>"></script>
		<script type="text/javascript" src="<?php echo Settings('Url'); ?>/admin/js/serial.js?<?php echo $update; ?>"></script>
		<script type="text/javascript" src="<?php echo Settings('Url'); ?>/admin/js/pie.js?<?php echo $update; ?>"></script>
		<script type="text/javascript" src="<?php echo Settings('Url'); ?>/admin/js/chart.js?<?php echo $update; ?>"></script>
		<script type="text/javascript" src="<?php echo Settings('Url'); ?>/admin/js/map.js?<?php echo $update; ?>"></script>
		<script src="<?php echo Settings('Url'); ?>/admin/js/jquery-jvectormap-1.2.2.min.js?<?php echo $update; ?>"></script>
		<script src="<?php echo Settings('Url'); ?>/admin/js/jquery-jvectormap-us-aea-en.js?<?php echo $update; ?>"></script>
		<script type="text/javascript" src="<?php echo Settings('Url'); ?>/admin/js/main.js?<?php echo $update; ?>"></script>


	</body>
	
</html>