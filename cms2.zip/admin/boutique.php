<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/session.disconnect.php");

$pageid = 2;
  
if($user['rank'] < 10) {
Redirect("".Settings('Url')."");
}

if($user['rank'] >= 10) {
if(isset($_POST['IDP']) && isset($_POST['IDD']) && isset($_POST['IDP_2']) && isset($_POST['IDD_2']))
{
$IDP = Securise($_POST['IDP']);
$IDD = Securise($_POST['IDD']);
$IDP_2 = Securise($_POST['IDP_2']);
$IDD_2 = Securise($_POST['IDD_2']);
if(isset($IDP) && isset($IDD) && isset($IDP_2) && isset($IDD_2)) {
mysql_query("UPDATE `retrophp_settings` SET `IDP` = '".$IDP."', `IDD` = '".$IDD."', `IDP_2` = '".$IDP_2."', `IDD_2` = '".$IDD_2."' WHERE `id` = 1");
mysql_query("INSERT INTO retrophp_stafflog (pseudo,action,date) VALUES ('".$user['username']."','Configuration de la boutique (Starpass).','".time()."')");
$post_starpass = true;
}
}

if(isset($_POST['Prix_VIP']) && isset($_POST['Prix_VIP_2']))
{
$Prix_VIP = Securise($_POST['Prix_VIP']);
$Prix_VIP_2 = Securise($_POST['Prix_VIP_2']);
if(isset($Prix_VIP) && isset($Prix_VIP_2)) {
mysql_query("UPDATE `retrophp_settings` SET `Prix_VIP` = '".$Prix_VIP."', `Prix_VIP_2` = '".$Prix_VIP_2."' WHERE `id` = 1");
mysql_query("INSERT INTO retrophp_stafflog (pseudo,action,date) VALUES ('".$user['username']."','Configuration du site (Prix VIP).','".time()."')");
$post_vip = true;
}
}

if(isset($_POST['Prix_1']) && isset($_POST['Prix_1_Euro']) && isset($_POST['Prix_2']) && isset($_POST['Prix_2_Euro']))
{
$Prix_1 = Securise($_POST['Prix_1']);
$Prix_1_Euro = Securise($_POST['Prix_1_Euro']);
$Prix_2 = Securise($_POST['Prix_2']);
$Prix_2_Euro = Securise($_POST['Prix_2_Euro']);
if(isset($Prix_1) && isset($Prix_1_Euro) && isset($Prix_2) && isset($Prix_2_Euro)) {
mysql_query("UPDATE `retrophp_settings` SET `Prix_1` = '".$Prix_1."', `Prix_1_Euro` = '".$Prix_1_Euro."', `Prix_2` = '".$Prix_2."', `Prix_2_Euro` = '".$Prix_2_Euro."' WHERE `id` = 1");
mysql_query("INSERT INTO retrophp_stafflog (pseudo,action,date) VALUES ('".$user['username']."','Configuration du site (Prix Diamants/Jetons).','".time()."')");
$post_social = true;
}
}
}

include("./templates/header.php");
?>
<div class="row">

				<div class="col-md-4">
					<article class="widget">
					<header class="widget__header">
						<h3 class="widget__title">Starpass</h3>
					</header>

					<div class="widget__content">
						<?php if($post_starpass == true){ ?>
						<div class="alert alert-warning alert-dismissable">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
							<div class="media">
								<figure class="pull-left alert--icon">
									<i class="pe-7s-attention"></i>
								</figure>
								<div class="media-body">
									<h3 class="alert--title">C'est fait !</h3> 
									<p class="alert--text">La modification a bien été prise en compte.</p>
								</div>
							</div>
						</div>
						<?php } ?>
						<a href="<?php echo Settings('Url'); ?>/images/form.png" target="_black">Liens à introduire sur Starpass</a>
						<form method="post">
						<p class="alert--text">Starpass {1} IDP.</p>
						<input type="text" class="input-text" name="IDP" value="<?php echo Settings('IDP'); ?>"/>
						<p class="alert--text">Starpass {1} IDD.</p>
						<input type="text" class="input-text" name="IDD" value="<?php echo Settings('IDD'); ?>"/>
						<p class="alert--text">Starpass {2} IDP.</p>
						<input type="text" class="input-text" name="IDP_2" value="<?php echo Settings('IDP_2'); ?>"/>
						<p class="alert--text">Starpass {2} IDD.</p>
						<input type="text" class="input-text" name="IDD_2" value="<?php echo Settings('IDD_2'); ?>"/>
						<button class="btn btn-light pull-right" type="submit">Mettre à jour</button>
						<div class="clearfix"></div>
					</form>
					</article>

		
				</div>

				<div class="col-md-5">
					<article class="widget">
					<header class="widget__header">
						<h3 class="widget__title">Boutique VIP (31 Jours)</h3>
					</header>

					<div class="widget__content">
						<?php if($post_vip == true){ ?>
						<div class="alert alert-warning alert-dismissable">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
							<div class="media">
								<figure class="pull-left alert--icon">
									<i class="pe-7s-attention"></i>
								</figure>
								<div class="media-body">
									<h3 class="alert--title">C'est fait !</h3> 
									<p class="alert--text">La modification a bien été prise en compte.</p>
								</div>
							</div>
						</div>
						<?php } ?>
						<form method="post">
						<p class="alert--text">Prix VIP Classic.</p>
						<input type="text" class="input-text" name="Prix_VIP" value="<?php echo Settings('Prix_VIP'); ?>"/>
						<p class="alert--text">Prix VIP Premium.</p>
						<input type="text" class="input-text" name="Prix_VIP_2" value="<?php echo Settings('Prix_VIP_2'); ?>"/>
						<button class="btn btn-light pull-right" type="submit">Mettre à jour</button>
						<div class="clearfix"></div>
					</form>
					</article>

		
				</div>

				<div class="col-md-3">
					<article class="widget">
					<header class="widget__header">
						<h3 class="widget__title">Diamants / Jetons</h3>
					</header>

					<div class="widget__content">
						<?php if($post_boutique == true){ ?>
						<div class="alert alert-warning alert-dismissable">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
							<div class="media">
								<figure class="pull-left alert--icon">
									<i class="pe-7s-attention"></i>
								</figure>
								<div class="media-body">
									<h3 class="alert--title">C'est fait !</h3> 
									<p class="alert--text">La modification a bien été prise en compte.</p>
								</div>
							</div>
						</div>
						<?php } ?>
						<form method="post" action="">
						<p class="alert--text">Premier prix.</p>
						<input type="text" class="input-text" name="Prix_1" value="<?php echo Settings('Prix_1'); ?>"/>
						<p class="alert--text">Premier prix en &#8364;.</p>
						<input type="text" class="input-text" name="Prix_1_Euro" value="<?php echo Settings('Prix_1_Euro'); ?>"/>
						<p class="alert--text">Deuxième prix.</p>
						<input type="text" class="input-text" name="Prix_2" value="<?php echo Settings('Prix_2'); ?>"/>
						<p class="alert--text">Deuxième prix en &#8364;.</p>
						<input type="text" class="input-text" name="Prix_2_Euro" value="<?php echo Settings('Prix_2_Euro'); ?>"/>
						<button class="btn btn-light pull-right" type="submit">Mettre à jour</button>
						<div class="clearfix"></div>
					</form>
					</article>

		
				</div>
	

			</div>
<?php include("./templates/footer.php"); ?>