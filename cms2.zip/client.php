<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
include("./includes/files/client.php");
include("./includes/files/session.disconnect.php");
    
$pageid = "hotel";
$pub = "client";

if($rtp_user['renamed'] == 1 && $rtp_user['gender_register'] == 1) {

$hotel_closed = mysql_query("SELECT * FROM retrophp_settings WHERE Hotel = 'false' or Hotel = 'reboot'");
while($close = mysql_fetch_array($hotel_closed)) {
Redirect("".Settings('Url')."/hotelclosed");
}

$hotel_open = mysql_query("SELECT * FROM retrophp_settings WHERE Hotel = 'true'");
while($open = mysql_fetch_array($hotel_open)) {
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo Settings('Name'); ?>: </title> 
 
<script type="text/javascript"> 
var andSoItBegins = (new Date()).getTime();
var ad_keywords = "";
document.habboLoggedIn = true;
var habboName = "<?php echo $user['username']; ?>";
var habboReqPath = "<?php echo Settings('Url'); ?>";
var habboStaticFilePath = "<?php echo Settings('Url_Images'); ?>";
var habboImagerUrl = "<?php echo Settings('Avatarimage'); ?>/habbo-imaging/";
var habboPartner = "";
var habboDefaultClientPopupUrl = "<?php echo Settings('Url'); ?>/client";
window.name = "habboMain";
if (typeof HabboClient != "undefined") { HabboClient.windowName = "uberClientWnd"; }
</script> 

<link rel="shortcut icon" href="<?php echo Settings('Url'); ?>/favicon.ico" type="image/vnd.microsoft.icon" /> 
<script src="<?php echo Settings('Url_Images'); ?>/flashclient/js/libs2.js?2" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/flashclient/js/visual.js?2" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/flashclient/js/libs.js?2" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/flashclient/js/common.js?2" type="text/javascript"></script>

<script src="<?php echo Settings('Url_Images'); ?>/flashclient/js/fullcontent.js?2" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/flashclient/css/style.css?6" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/flashclient/css/tooltips.css?2" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/flashclient/css/habboclient.css?2" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/flashclient/css/habboflashclient.css?2" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>/flashclient/js/habboflashclient.js?2" type="text/javascript"></script>
 
<meta name="build" content="<?php echo Settings('Build'); ?>" /> 

</head> 

<body id="client" class="flashclient"> 

<script type="text/javascript"> 
var habboDefaultClientPopupUrl = "<?php echo $url; ?>/client";
</script> 
 
<script type="text/javascript"> 

FlashExternalInterface.loginLogEnabled = true;
 
FlashExternalInterface.logLoginStep("web.view.start");
 
if (top == self) {
FlashHabboClient.cacheCheck();
}
var flashvars = {
"client.allow.cross.domain" : "1", 
"client.notify.cross.domain" : "0", 
"connection.info.host" : "<?php echo Serveur('Host'); ?>", 
"connection.info.port" : "<?php echo Serveur('Port'); ?>", 
"site.url" : "<?php echo Settings('Url'); ?>", 
"url.prefix" : "<?php echo Settings('Url'); ?>", 
"client.reload.url" : "<?php echo Settings('Url'); ?>/client", 
"client.fatal.error.url" : "<?php echo Settings('Url'); ?>/flash_client_error", 
"client.connection.failed.url" : "<?php echo Settings('Url'); ?>/flash_client_error", 
"external.variables.txt" : "<?php echo Serveur('variables'); ?>",
"external.texts.txt" : "<?php echo Serveur('Texts'); ?>",
<?php if(Settings('Emulator') != "Phoenix") { ?>
<?php if(Settings('Emulator') != "Butterfly" or Settings('Emulator') != "Mercury") { ?>
"external.override.variables.txt" : "<?php echo Serveur('Override'); ?>",
<?php } ?>
"productdata.load.url" : "<?php echo Serveur('Productdata'); ?>",
"furnidata.load.url" : "<?php echo Serveur('Furnidata'); ?>",
"hotelview.banner.url" : "<?php echo Serveur('Banner'); ?>",
<?php } ?>
"use.sso.ticket" : "1",
"sso.ticket" : "<?php echo TicketRefresh($user['username']); ?>", 
"processlog.enabled" : "0", 
"account_id" : "<?php echo $user['id']; ?>", 
"client.starting" : "Patience! <?php echo Settings('Name'); ?> d\351marre.", 
"flash.client.url" : "<?php echo Serveur('Base'); ?>", 
"user.hash" : "", 
"has.identity" : "0", 
"flash.client.origin" : "popup" 
 };
    var params = {
        "base" : "<?php echo Serveur('Base'); ?>",
        "allowScriptAccess" : "always",
        "menu" : "false"                
    };
 
        if (!(HabbletLoader.needsFlashKbWorkaround())) {
            params["wmode"] = "opaque";
        }
 
    FlashExternalInterface.signoutUrl = "<?php echo Settings('Url'); ?>/account/logout";
 
    var clientUrl = "<?php echo Serveur('Habbo'); ?>";
    swfobject.embedSWF(clientUrl, "flash-container", "100%", "100%", "10.0.0", "<?php echo Settings('Url_Images'); ?>/flashclient/flash/expressInstall.swf", flashvars, params);
 
    window.onbeforeunload = unloading;
    function unloading() {
        var clientObject;
        if (navigator.appName.indexOf("Microsoft") != -1) {
            clientObject = window["flash-container"];
        } else {
            clientObject = document["flash-container"];
        }
        try {
            clientObject.unloading();
        } catch (e) {}
    }
</script> 


<div id="overlay"></div> 

<div id="client-ui" > 
<div id="flash-wrapper"> 
<div id="flash-container"> 
<div id="content" style="width: 400px; margin: 20px auto 0 auto; display: none"> 
<div class="cbb clearfix"> 
<h2 class="title">Installer Adode Flash Player</h2> 
<div class="box-content"> 
<p>Pour installer Flash Player : <a href="http://get.adobe.com/flashplayer/">Clique ICI</a>. More instructions for installation can be found here: <a href="http://www.adobe.com/products/flashplayer/productinfo/instructions/">More information</a></p> 

<p><a href="http://www.adobe.com/go/getflashplayer"><img src="<?php echo Settings('Url'); ?>/images/get_flash_player.gif" alt="Get Adobe Flash player" /></a></p> 
</div> 
</div> 
</div> 
<script type="text/javascript"> 
$('content').show();
</script> 
<noscript> 
<div style="width: 400px; margin: 20px auto 0 auto; text-align: center"> 
<p>If you are not automatically redirected, please <a href="/client/nojs">click here</a></p> 
</div> 
</noscript> 
</div> 
</div>

</div>
</div>
<div id="content" class="client-content"></div>
</div>
<div style="display: none"> 

<script language="JavaScript" type="text/javascript"> 
setTimeout(function() {
HabboCounter.init(600);
}, 20000);

</script> 
</div> 
<script type="text/javascript"> 
RightClick.init("flash-wrapper", "flash-container");
</script> 

</body> 

</html>
<?php }} ?>
