
var Popup = {
	Start: function(){
		$('#popup').fadeIn();
		setTimeout(function(){
		$('#popup').fadeOut();
		}, 2000);
	}
}

$('.btn.payment1').click(function(){
	Popup.Start();

	// For testing purposes
    var R = Math.random();

	if(R > 0.5)
	{
		PopupPage.Open1();
	} 
	else 
	{
		PopupPage.Open1();		
	}
});

$('.btn.payment2').click(function(){
	Popup.Start();

	// For testing purposes
    var R = Math.random();

	if(R > 0.5)
	{
		PopupPage.Open2();
	} 
	else 
	{
		PopupPage.Open2();		
	}
});

$('.btn.payment3').click(function(){
	Popup.Start();

	// For testing purposes
    var R = Math.random();

	if(R > 0.5)
	{
		PopupPage.Open3();
	} 
	else 
	{
		PopupPage.Open3();		
	}
});

$('.btn.payment4').click(function(){
	Popup.Start();

	// For testing purposes
    var R = Math.random();

	if(R > 0.5)
	{
		PopupPage.Open4();
	} 
	else 
	{
		PopupPage.Open4();		
	}
});