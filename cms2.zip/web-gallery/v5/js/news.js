var News = {

    Init: function (r) {
        News.DisplayBullet(r);
    },

    DisplayBullet: function (data) {

        window.nAux = data.length;
        $.each(data, function (i, item) {

            setTimeout(function () {

                News.Rotate(item["background"], item["title"], item["content"], item["url"])

                if (--window.nAux == 0)
                    setTimeout(function () {
                        News.DisplayBullet(data);
                    }, 6000);
            }, 6000 * i);

        });
    },

    Rotate: function (bg, title, content, url) {
        $('.bullet').fadeOut(function () {
            $('.bullet').css("background", "url(" + bg + ")");
            $('.bullet-title').html(title);
            $('.bullet-content').html(content);
            $('#bullet-url').attr("href", function () {
                return url;
            });
        });
        $('.bullet').fadeIn();

    }
};

News.Init(Articles);