<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Erreur</title>

    <link href="http://getbootstrap.com/2.3.2/assets/css/bootstrap.css" rel="stylesheet">
    <link href="http://getbootstrap.com/2.3.2/assets/css/bootstrap-responsive.css" rel="stylesheet">
    <style type="text/css">
      body {
        padding-top: 40px;
        padding-bottom: 40px;
        background-color: #f5f5f5;
      }

      .box {
        max-width: 300px;
        padding: 19px 29px 29px;
        margin: 0 auto 20px;
        background-color: #fff;
        border: 1px solid #e5e5e5;
      }

    </style>
  </head>

  <body>

    <div class="container">

      <div class="box">
      <p style="color: red;">Impossible d'accéder à la base de données.</p>
      Les informations dans le fichier "includes/settings.inc.php" est incorrect pour accéder à la base de données!
      </div>

    </div> 

  </body>
</html>
