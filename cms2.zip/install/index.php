<?php
include("../includes/settings.inc.php");

if(isset($_POST['sql']) && isset($_POST['emu'])) {
$emu = $_POST['emu'];
if(isset($emu)) {
$requete = mysql_query("SHOW TABLES LIKE 'users'")or die(mysql_error());
if(mysql_num_rows($requete) == 1)
{
mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_abonnement` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `abonnement` enum('Classic','Premium') DEFAULT NULL,
  `timestamp_activated` int(11) NOT NULL,
  `timestamp_expire` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");

mysql_query("ALTER TABLE `retrophp_abonnement`
 ADD PRIMARY KEY (`id`);");

mysql_query("ALTER TABLE `retrophp_abonnement`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;");

mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_badges` (
`id` int(11) NOT NULL,
  `badge_id` varchar(255) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `prix` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;");

mysql_query("INSERT INTO `retrophp_badges` (`id`, `badge_id`, `titre`, `description`, `prix`) VALUES
(1, 'FR038', 'Badge Trèfle', 'Que la chance soit avec toi !', 1);");

mysql_query("ALTER TABLE `retrophp_badges`
 ADD PRIMARY KEY (`id`);");

mysql_query("ALTER TABLE `retrophp_badges`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;");

mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_ipstaff` (
`id` int(11) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `actif` enum('0','1') NOT NULL DEFAULT '1',
  `code` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");

mysql_query("ALTER TABLE `retrophp_ipstaff`
 ADD PRIMARY KEY (`id`);");


mysql_query("ALTER TABLE `retrophp_ipstaff`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");

mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_news` (
`id` int(11) unsigned NOT NULL,
  `id_page` text COLLATE latin1_general_ci NOT NULL,
  `title` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `snippet` text COLLATE latin1_general_ci,
  `body` text COLLATE latin1_general_ci,
  `topstory_image` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `mini_text` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'En savoir plus',
  `auteur` text COLLATE latin1_general_ci,
  `date` double DEFAULT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;");


mysql_query("INSERT INTO `retrophp_news` (`id`, `id_page`, `title`, `snippet`, `body`, `topstory_image`, `mini_text`, `auteur`, `date`) VALUES
(1, 'retrophp', 'RetroPHP', 'Des nouveautés, des reproductions et bien plus encore.', '...', 'http://habboo-a.akamaihd.net/c_images/web_promo/lpromo_xmas14_bundle3.png', 'En savoir plus', 'Tyler', 0);
");

mysql_query("ALTER TABLE `retrophp_news`
 ADD PRIMARY KEY (`id`);");

mysql_query("ALTER TABLE `retrophp_news`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;");

mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_payment` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pseudo` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `statut` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `nombres` int(11) NOT NULL DEFAULT '0',
  `type` enum('jetons','diamants','duckets') COLLATE latin1_general_ci NOT NULL,
  `code` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `operation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `remis` enum('0','1') COLLATE latin1_general_ci NOT NULL,
  `date` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;");

mysql_query("ALTER TABLE `retrophp_payment`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);");

mysql_query("ALTER TABLE `retrophp_payment`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;");

mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_settings` (
`id` int(6) NOT NULL,
  `Name` varchar(255) NOT NULL DEFAULT 'Habbo',
  `Nickname` varchar(255) NOT NULL DEFAULT 'Habbo',
  `Url` varchar(255) NOT NULL DEFAULT 'http://localhost/',
  `Court_Url` varchar(255) NOT NULL DEFAULT 'http://localhost/',
  `Url_Images` varchar(255) NOT NULL DEFAULT 'http://localhost/web-gallery',
  `C_Images` varchar(255) NOT NULL,
  `Avatarimage` varchar(255) NOT NULL DEFAULT 'http://avatarimage.retrophp.com',
  `Logo` varchar(255) DEFAULT 'habbologo_whiteR.out.png',
  `Help_Link` text NOT NULL,
  `Maintenance` enum('true','false') NOT NULL DEFAULT 'false',
  `Hotel` enum('true','false','reboot') NOT NULL DEFAULT 'false',
  `Emulator` enum('Phoenix','Butterfly','Mercury','Azure') NOT NULL DEFAULT 'Phoenix',
  `Facebook` text NOT NULL,
  `Twitter` text NOT NULL,
  `Youtube` text NOT NULL,
  `APP_ID` varchar(255) NOT NULL,
  `APP_SECRET` varchar(255) NOT NULL,
  `IDP` varchar(50) NOT NULL,
  `IDP_2` varchar(50) NOT NULL,
  `IDD` varchar(50) NOT NULL,
  `IDD_2` varchar(50) NOT NULL,
  `Prix_1` int(11) NOT NULL,
  `Prix_2` int(11) NOT NULL,
  `Prix_1_Euro` varchar(255) NOT NULL,
  `Prix_2_Euro` varchar(255) NOT NULL,
  `Prix_VIP` int(11) NOT NULL,
  `Prix_VIP_2` int(11) NOT NULL,
  `Description` text NOT NULL,
  `Keyword` text NOT NULL,
  `Build` varchar(255) NOT NULL DEFAULT 'RetroPHP',
  `Fondateur` text NOT NULL,
  `Lang` varchar(50) NOT NULL DEFAULT 'fr_FR',
  `Contact` varchar(255) NOT NULL DEFAULT 'community@retrophp.com',
  `Credits` varchar(255) NOT NULL DEFAULT '90000',
  `Pixels` int(11) NOT NULL DEFAULT '2',
  `Jetons` int(11) NOT NULL DEFAULT '0',
  `Mission` text NOT NULL,
  `Rank` int(11) NOT NULL DEFAULT '1',
  `Look_Boy` varchar(255) NOT NULL DEFAULT 'sh-295-62.hr-831-45.ch-215-92.hd-180-3.lg-280-64',
  `Look_Girl` varchar(255) NOT NULL DEFAULT 'hr-3012-45.sh-730-92.ch-824-92.hd-600-3.lg-710-64'
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;");

$url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$site = str_replace("/install/","",$url);

mysql_query("INSERT INTO `retrophp_settings` (`id`, `Name`, `Nickname`, `Url`, `Court_Url`, `Url_Images`, `C_Images`, `Avatarimage`, `Logo`, `Help_Link`, `Maintenance`, `Hotel`, `Emulator`, `Facebook`, `Twitter`, `Youtube`, `APP_ID`, `APP_SECRET`, `IDP`, `IDP_2`, `IDD`, `IDD_2`, `Prix_1`, `Prix_2`, `Prix_1_Euro`, `Prix_2_Euro`, `Prix_VIP`, `Prix_VIP_2`, `Description`, `Keyword`, `Build`, `Fondateur`, `Lang`, `Contact`, `Credits`, `Pixels`, `Jetons`, `Mission`, `Rank`, `Look_Boy`, `Look_Girl`) VALUES
(1, 'Habbo', 'Habbo', '".$site."', 'habbo.fr', '".$site."/web-gallery', 'http://habboo-a.akamaihd.net/c_images', 'http://images.retrophp.com/habbo-imaging/', 'habbologo_whiteR.out.png', '#', 'false', 'true', '".$emu."', 'HabboFR', 'HabboFR', 'Habbo', '', '', '', '', '', '', 50, 130, '1,35', '2,68', 35, 80, 'fais-toi plein d\'amis, deviens célèbre! Séjourne GRATUITEMENT dans le plus grand hôtel virtuel au monde! Crée ton avatar pour jouer et faire de nouvelles rencontres...', 'virtuel, monde, réseau social, gratuit, communauté, avatar, chat, connecté, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécurité, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, création, badges, musique, célébrité, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur', 'RetroPHP', 'RetroPHP', 'fr_FR', 'community@retrophp.com', '9000000', 2, 1, '', 1, 'sh-295-62.hr-831-45.ch-215-92.hd-180-3.lg-280-64', 'hr-3012-45.sh-730-92.ch-824-92.hd-600-3.lg-710-64');
");

mysql_query("ALTER TABLE `retrophp_settings`
 ADD PRIMARY KEY (`id`);");

mysql_query("ALTER TABLE `retrophp_settings`
MODIFY `id` int(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;");

mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_stafflog` (
`id` int(11) unsigned NOT NULL,
  `pseudo` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `action` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `date` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;");

mysql_query("ALTER TABLE `retrophp_stafflog`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);");

mysql_query("ALTER TABLE `retrophp_stafflog`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");

mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_swfs` (
`id` int(11) NOT NULL,
  `Host` text COLLATE latin1_general_ci,
  `Port` text COLLATE latin1_general_ci,
  `Variables` text COLLATE latin1_general_ci,
  `Texts` text COLLATE latin1_general_ci,
  `Override` text COLLATE latin1_general_ci NOT NULL,
  `Productdata` text COLLATE latin1_general_ci,
  `Furnidata` text COLLATE latin1_general_ci,
  `Banner` text COLLATE latin1_general_ci,
  `Base` text COLLATE latin1_general_ci,
  `Habbo` text COLLATE latin1_general_ci
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;");


mysql_query("INSERT INTO `retrophp_swfs` (`id`, `Host`, `Port`, `Variables`, `Texts`, `Override`, `Productdata`, `Furnidata`, `Banner`, `Base`, `Habbo`) VALUES
(1, '127.0.0.1', '30000', 'http://localhost/gamedata/external_variables.txt', 'http://localhost/gamedata/external_flash_texts.txt', 'http://localhost/gamedata/external_override_variables.txt', 'http://localhost/gamedata/productdata.txt', 'http://localhost/gamedata/furnidata.txt', 'http://localhost/gamedata/supersecret.php', 'http://localhost/gordon/', 'http://localhost/gamedata/habbo.swf');
");

mysql_query("ALTER TABLE `retrophp_swfs`
 ADD PRIMARY KEY (`id`);");

mysql_query("ALTER TABLE `retrophp_swfs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;");

mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_visites` (
`id` int(11) unsigned NOT NULL,
  `ip` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");

mysql_query("ALTER TABLE `retrophp_visites`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`), ADD UNIQUE KEY `ip` (`ip`);");

mysql_query("ALTER TABLE `retrophp_visites`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");

mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_voucher` (
`id` int(11) unsigned NOT NULL,
  `code` varchar(25) NOT NULL,
  `montant` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");

mysql_query("ALTER TABLE `retrophp_voucher`
 ADD PRIMARY KEY (`id`);");

mysql_query("ALTER TABLE `retrophp_voucher`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;");

mysql_query("DROP TABLE IF EXISTS `ranks`;");

mysql_query("CREATE TABLE IF NOT EXISTS `ranks` (
`id` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `badgeid` varchar(20) DEFAULT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;");

mysql_query("INSERT INTO `ranks` (`id`, `name`, `badgeid`) VALUES
(1, 'Membre', NULL),
(2, 'VIP Classic', 'VIP'),
(3, 'VIP Premium', 'VIP'),
(4, 'Pubeur', 'PBR'),
(5, 'Helpeur', 'HLP'),
(6, 'Grade spéciale', NULL),
(7, 'Modérateur', 'MOD'),
(8, 'Game Manager', 'ADM'),
(9, 'Hotel Manager', 'ADM'),
(10, 'Fondateur', 'ADM');");

mysql_query("ALTER TABLE `ranks`
 ADD PRIMARY KEY (`id`);");

mysql_query("ALTER TABLE `ranks`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;");

mysql_query("ALTER TABLE `users` DROP `last_offline`;");
mysql_query("ALTER TABLE `users` ADD `last_offline` DOUBLE NOT NULL;");
mysql_query("ALTER TABLE `users` DROP `disabled`;");
mysql_query("ALTER TABLE `users` ADD `disabled` INT(6) NOT NULL;");

mysql_query("ALTER TABLE `users` DROP `seasonal_currency`;");
mysql_query("ALTER TABLE `users` ADD `seasonal_currency` INT(11) NOT NULL DEFAULT '0' AFTER `credits`;");

mysql_query("ALTER TABLE `users`  
ADD `hote_id` INT(11) NOT NULL , 
ADD `avatars` INT(11) NOT NULL DEFAULT '49';");

mysql_query("CREATE TABLE IF NOT EXISTS `retrophp_users` (
`uid` int(11) unsigned NOT NULL,
  `facebook` enum('0','1') NOT NULL DEFAULT '0',
  `facebook_id` varchar(255) NOT NULL,
  `user_key` varchar(255) NOT NULL,
  `renamed` enum('0','1') NOT NULL DEFAULT '0',
  `gender_register` enum('0','1') NOT NULL DEFAULT '0',
  `statistiques` int(11) NOT NULL DEFAULT '0',
  `newsletter` enum('0','1') NOT NULL DEFAULT '0',
  `disabled_home` enum('0','1') NOT NULL DEFAULT '0',
  `mail_verified` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

mysql_query("ALTER TABLE `retrophp_users`
 ADD PRIMARY KEY (`uid`);");

mysql_query("ALTER TABLE `retrophp_users`
MODIFY `uid` int(11) unsigned NOT NULL AUTO_INCREMENT;");

mysql_query("ALTER TABLE `server_status` ADD `record_connect` INT(11) NOT NULL DEFAULT '0' AFTER `users_online`;");


mysql_close();

$valide = true;
} else { 
$error = true;
}
}
}

$do2 = isset($_GET['supp']); if($do2 == "true") {
unlink("index.php");
@header("Location: ../");
}
?>

<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Installation du CMS</title>

    <link href="http://getbootstrap.com/2.3.2/assets/css/bootstrap.css" rel="stylesheet">
    <link href="http://getbootstrap.com/2.3.2/assets/css/bootstrap-responsive.css" rel="stylesheet">
    <style type="text/css">
      body {
        padding-top: 40px;
        padding-bottom: 40px;
        background-color: #f5f5f5;
      }

      .box {
        max-width: 300px;
        padding: 19px 29px 29px;
        margin: 0 auto 20px;
        background-color: #fff;
        border: 1px solid #e5e5e5;
      }

    </style>
  </head>

  <body>

    <div class="container">

      <div class="box">
        <?php if(isset($valide) == true) { ?><p style="color: green;">Félicitation !</p><?php } ?>
        <?php if(isset($error) == true) { ?><p style="color: red;">Votre base de donnée ne contient pas de tables. Importez les tables avant de continuer.</p><?php } ?>
         <?php if(isset($valide) == true) { ?> 
         Le SQL contenant les données pour le fonctionnement du CMS a bien été importer.
         <br><br>
         <center><a href="../" class="btn btn-large btn-warning" type="submit">Accéder à mon site</a><br><br><a href="?supp=true" class="btn btn-large btn-danger" type="submit">Supprimer fichier d'installation</a></center>
         <?php } else { ?>
         Tout d'abord nous avons besoin des tables de Phoenix/Butterfly/Mercury/Azure.<br><br>
         <i>Upload ta base de donnée.</i><br><br>
         Une fois l'opération faite, selectionne ton emulateur et clique sur le bouton "Valider"<br>
        <center>
          <form method="post">
          <br>
          <select name="emu">
            <option value="Phoenix">Phoenix</option>
            <option value="Butterfly">Butterfly</option>
            <option value="Mercury">Mercury</option>
            <option value="Azure">Azure</option>
            </select>
          <input class="btn btn-large btn-primary" name="sql" type="submit" value="Valider l'installation">
          </form>
        </center>
        <?php } ?>
      </div>

    </div> 

  </body>
</html>
