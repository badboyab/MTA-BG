<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("./includes/files/session.connect.php");

$key = Securise($_GET['ukey']);

$retrophp_user_key = mysql_query("SELECT * FROM retrophp_users WHERE user_key = '".$key."'");
$ukey = mysql_fetch_assoc($retrophp_user_key);

$user_key = mysql_query("SELECT * FROM users WHERE id = '".$ukey['id']."'");
$key = mysql_fetch_assoc($user_key);

if(empty($key)) { 
Redirect("".Settings('Url')."");
}

if(isset($_POST['password']) && isset($_POST['retypedPassword']))
{
$mdpnew = Securise($_POST['password']);
$mdpnewre = Securise($_POST['retypedPassword']);
$md5 = Hashage($mdpnew);
if($mdpnew == $mdpnewre){
if(strlen($mdpnew) < 6){
    $failure = true;
$result = "Ton mot de passe est trop court !";
}  else {
if(strlen($mdpnew) > 25){
    $failure = true;
$result = "Ton mot de passe est trop long !";
} else {
if($key['hote_id'] == '0') {
mysql_query("UPDATE users SET password = '".$md5."' WHERE id = '".$key['id']."'") or die(mysql_error());
mysql_query("UPDATE retrophp_users SET user_key = '".$generate_key."' WHERE user_key = '".$ukey['user_key']."'") or die(mysql_error());
}
Redirect("".Settings('Url')."");
$failure = false;
}
}
} else {
$failure = true;
$result = "Les deux mot de passes ne sont pas identiques ";
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo Settings('Name'); ?>:  </title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<link rel="shortcut icon" href="<?php echo Settings('Url_Images'); ?>/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/common.css" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/process.css" type="text/css" />

<script src="<?php echo Settings('Url_Images'); ?>/static/js/libs2.js" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/visual.js" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/libs.js" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/common.js" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/fullcontent.js" type="text/javascript"></script>
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/frontpage.css" type="text/css" />

<?php include("../templates/meta.php"); ?>

</head>
<body class="process-template black secure-page">

<div id="container">
	<div class="process-template-box clearfix">
		<div id="content" class="wide">
		    <div id="header" class="clearfix">
			    <h1><a href="<?php echo Settings('Url'); ?>/"></a></h1>
			</div>
			<div id="process-content">
	        	<p class="phishing-warning">Cet écran a pour objet de protéger tes infos personnelles du phishing. Vérifie que l'adresse ci-dessus commence bien par <?php echo Settings('Url'); ?>/. Si ce nest pas le cas, stoppe tout immédiatement!</p>

<div id="reset-password-form-container">
    <?php if($failure == true) { ?>
    <div id="errors">
        <div class="rounded-container"><div style="background-color: rgb(0, 0, 0);"><div style="margin: 0px 4px; height: 1px; overflow: hidden; background-color: rgb(0, 0, 0);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(131, 0, 15);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(190, 0, 22);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(219, 0, 25);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div></div></div></div><div style="margin: 0px 2px; height: 1px; overflow: hidden; background-color: rgb(0, 0, 0);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(133, 0, 15);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(225, 0, 26);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div></div></div><div style="margin: 0px 1px; height: 1px; overflow: hidden; background-color: rgb(0, 0, 0);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(169, 0, 19);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div></div><div style="margin: 0px 1px; height: 1px; overflow: hidden; background-color: rgb(133, 0, 15);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div><div style="margin: 0px; height: 1px; overflow: hidden; background-color: rgb(0, 0, 0);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(225, 0, 26);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div></div><div style="margin: 0px; height: 1px; overflow: hidden; background-color: rgb(131, 0, 15);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div><div style="margin: 0px; height: 1px; overflow: hidden; background-color: rgb(190, 0, 22);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div><div style="margin: 0px; height: 1px; overflow: hidden; background-color: rgb(219, 0, 25);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div></div><div class="rounded-red rounded-done">
            <div id="error-title" class="error">
                    <?php echo $result; ?> <br>
            </div>
        </div><div style="background-color: rgb(0, 0, 0);"><div style="margin: 0px; height: 1px; overflow: hidden; background-color: rgb(219, 0, 25);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div><div style="margin: 0px; height: 1px; overflow: hidden; background-color: rgb(190, 0, 22);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div><div style="margin: 0px; height: 1px; overflow: hidden; background-color: rgb(131, 0, 15);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div><div style="margin: 0px; height: 1px; overflow: hidden; background-color: rgb(0, 0, 0);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(225, 0, 26);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div></div><div style="margin: 0px 1px; height: 1px; overflow: hidden; background-color: rgb(133, 0, 15);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div><div style="margin: 0px 1px; height: 1px; overflow: hidden; background-color: rgb(0, 0, 0);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(169, 0, 19);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div></div><div style="margin: 0px 2px; height: 1px; overflow: hidden; background-color: rgb(0, 0, 0);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(133, 0, 15);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(225, 0, 26);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div></div></div><div style="margin: 0px 4px; height: 1px; overflow: hidden; background-color: rgb(0, 0, 0);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(131, 0, 15);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(190, 0, 22);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(219, 0, 25);"><div style="height: 1px; overflow: hidden; margin: 0px 1px; background-color: rgb(226, 0, 26);"></div></div></div></div></div></div></div>
    </div>
    <?php } ?>
    <div id="reset-password-form-content">
        <div id="left-column">
            <div class="header bottom-top-border">Définir le mot de passe</div>
            <form method="post" action="" id="pwreset-form">
                <fieldset id="register-fieldset-password">
                    <div class="form-content clearfix">
                        <div class="label registration-text">Compte email</div>
                        <input type="text" id="email-address" value="<?PHP echo $key['mail'] ; ?>" autocomplete="off"
                               readOnly="true"/>
                    </div>
                    <div class="form-content clearfix">
                        <div class="left">
                            <div id="password">
                                <div class="label registration-text">Nouveau mot de passe</div>
                                <input type="password" name="password" id="register-password" maxlength="32"
                                        />
                            </div>
                            <div id="password-retype">
                                <div class="label registration-text">Nouveau mot de passe</div>
                                <input type="password" name="retypedPassword" id="register-password2" maxlength="32"
                                        />
                            </div>
                        </div>
                        <div class="right">
                            <div class="help">Ton mot de passe doit comprendre au moins <b>6 caractères</b> et inclure des <b>lettres et des chiffres</b></div>
                        </div>
                    </div>
                </fieldset>
                <div id="password-change-all-account-notice-text" class="bottom-top-dotted-border">
                    <div class="force-email-notice"></div>
                    <span class="white">Le changement de mot de passe concernera tous les avatars liés à ton adresse email.</span></div>
                <input type="hidden" name="token" value="<?PHP echo $ukey['user_key'] ; ?>"/>
            </form>
            <div id="change-password-buttons">
                <a href="<?php echo Settings('Url'); ?>/" id="change-password-cancel-link">Annuler la demande</a>
                <a href="#" id="reset-password-submit-button"
                   class="new-button"><b>Sauvegarder</b><i></i></a>
            </div>
        </div>

        <div id="right-column">
            <div class="header bottom-top-border">Tes avatars</div>
            <div id="password-change-accounts-notice-text" class="bottom-border"><span
                    class="white">Ces avatars seront associés à ton compte.</span></div>
            <ul id="reset-password-account-list" class="clearfix">
                    <li class="white">
                        <div class="green-tick"></div>
                        <span><?php echo $key['username'] ; ?></span>
                        <?php $user_compte = mysql_query("SELECT * FROM users WHERE hote_id = '".$key['id']."' mail = '".$key['mail']."'"); while($compte = mysql_fetch_array($user_compte)) { ?>
                        <span><?PHP echo $compte['username'] ; ?></span>
                        <?php } ?>
                    </li>
            </ul>
        </div>
    </div>
</div>

<script type="text/javascript">
    Event.observe($("reset-password-submit-button"), "click", function() {
        $("pwreset-form").submit();
    });

    $("register-password").focus();
</script>
			</div>
        </div>
    </div>
</div>
<script type="text/javascript">
if (typeof HabboView != "undefined") {
	HabboView.run();
}
</script>
</body>
</html>
