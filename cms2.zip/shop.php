<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
include("./includes/files/session.disconnect.php");
    
$pagename = "Boutique";
$pageid = "boutique";
 $menu_id="11"


?>
<!DOCTYPE html>

<title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<head>
    <meta charset="UTF-8">
    <title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
    <link rel="stylesheet" type="text/css" href="gallery/css/global.css?1461255333">
    <link rel="stylesheet" type="text/css" href="gallery/css/shop.css?1461255333">
    <link rel="shortcut icon" href="./favicon.ico">

    <meta name="twitter:title" content="Adov: Entre dans un hôtel où tout est gratuit, fais-toi plein d'amis et deviens célèbre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="Rétro Habbo">
    <meta property="og:site_name" content="Habbo Hôtel"/>
    <meta property="og:title" content="Habbo: Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, réseau social, gratuit, communautée, avatar, chat, connectée, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécuritée, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>
<style>
    #box p{
        font-size: 12px;
    }</style>
</head>

<?php include("./templates/header.php"); ?>

<div id="content" class="page">
                <div id="titreshop">Boutique</div>
        <div id="contenushop">
            <div id="head">
                <h1 class="titre">Achat de jetons</h1>
                <p class="desc">
                    Les jetons sont la monnaie de Habdo, ils vous permettront d'acheter des badges, des abonnements ou encore divers packs. Attention les jetons sont une monnaie payante, sans eux tu ne pourras bénéficier d'aucun avantage !                 </p>
                <div style="background:url(<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $user['look']; ?>);    height: 115px; width: 50px;position: absolute;bottom: -3px;left: 59px;"></div>
            </div>
            <div class="clear"></div>
            <br>
            <div id="msgjeton">
                À chaque code starpass valide, tu recevras sur Adov <b>100 jetons</b> qui te seront accrédités sur ton compte.
            </div>
            <br>
           <div id="starpass_365084"></div><script type="text/javascript" src="http://script.starpass.fr/script.php?idd=365084&amp;datas="></script><noscript>Veuillez activer le Javascript de votre navigateur s'il vous pla&icirc;t.<br /><a href="http://www.starpass.fr/">Micropaiement StarPass</a></noscript>
            <div class="clear"></div>
            <p class="perm">
                <span class="permission">Demande toujours la permission</span> <br>
                Avant d'acheter des jetons, demande toujours la permission à tes parents, ou à la personne qui va payer la facture si tu es majeur!
            </p>
            <br>
        </div>
    <div class="clear"></div>
<!-- FOOTER -->
<?php include("./templates/footer.php"); ?>
<!-- FIN FOOTER -->

</body>
</html>