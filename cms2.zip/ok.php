<style>
/**
* Wolpeur
*/
@import url(http://fonts.googleapis.com/css?family=Ubuntu:400,300,600,700,800);

#titreshop{
	background-color: #367897;
	padding: 8px;
	border-radius: 6px 6px 0 0;
	border: solid 1px #000;
	border-bottom: none;
	text-align: center;
	margin: 5px 0 0 0;
	font-size: 15px;
	color: #fff;
	font-weight: 600;
	box-shadow: inset 2px 2px 0 #408CAF, inset -2px 0 0 #408CAF;
}
#Convertisseur #container{
	margin: 0 auto;
	color: #fff;
	clear: both;
	overflow: hidden;
	width: 300px;
	position: relative;
	z-index: 10000;
}

#contenushop{
	background-color: #E9E9E1;
	border-radius: 0 0 6px 6px;
	border: solid 1px #000;
	border-bottom: solid 2px #000;
	box-shadow: inset 2px 0 0 #fff, inset -2px -2px 0 #fff;
	font-family: 'Ubuntu';
}
#Convertisseur input[type="submit"]{
	background: linear-gradient(#00A100 50%, #009000 50%);
    border-radius: 6px;
    border: solid 2px #000;
    font-weight: bold;
    font-size: 13px;
    text-align: center;
    width: 200px;
    padding: 8px;
    margin: 5px 0 5px 0;
    color: #fff;
    box-shadow: inset 3px 3px 0 #009000, inset -3px -3px 0 #009000;
}








</style>
				
				<link rel="stylesheet" type="text/css" href="./gallery/css/shop.css?1450716853">
	<div id="Convertisseur">
		<div id="container">
							
							<div id="titreshop">Choisis les offres</div>
							<div id="contenushop">
								<div>
								<br>
									<center><input type="text" placeholder="Mon pseudonyme"  name="username">
										<br/><form method="post" action="?convert=2">
										<input type="submit" value="50 Habbo Points - 100 jetons">
									</form></center>
								</div>
							</div>
						</div>
					</div>