<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
    
$pagename = "Palmarès";
$pageid = "palmares";
 $menu_id="10"
?>
<!DOCTYPE html>


<title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
<head>
    <meta charset="UTF-8">
    <title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
 <link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/gallery/css/global.css?1461255333">
    <link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/gallery/css/staffs2.css?1461255333">
    <link rel="shortcut icon" href="./favicon.ico">
    <meta name="twitter:title" content="Adov: Entre dans un hôtel où tout est gratuit, fais-toi plein d'amis et deviens célèbre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="Rétro Habbo">
    <meta property="og:site_name" content="Habbo Hôtel"/>
    <meta property="og:title" content="Habbo: Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, réseau social, gratuit, communautée, avatar, chat, connectée, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécuritée, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>
<style type="text/css">
    #staff .about{
            font-size: 12px;
    color: #444;
    padding: 17px 0px 0 0px;
    float: right;
    width: 176px;
    }

    h1#foo{
            color: #444;
    padding: 0;
    margin: 0 0 0 19px;
    font-size: 37px;
    line-height: 89px;
    }
    </style>
</head>

<?php include("./templates/header.php"); ?>

<div id="content" class="page">
        <img style="border-radius:9px;" src="https://i.gyazo.com/8c20b465afcb9a74c646df42df52926c.png">
        <br>
        <div id="left" class="column88">
            <div id="box" style="clear:both;overflow:hidden;">  
                <div class="titre" style="background-color:#DE6565;text-align:center;">Top Gamers</div>
               
                <div style="float:left;width: 69px;margin-top: 15px;">
                <h1 id="foo" style="color:#FFD700;">1 </h1><h1 id="foo" style="color:#C0C0C0;">2 </h1><h1 id="foo" style="color:#B8860B;">3 </h1><h1 id="foo" style="">4 </h1><h1 id="foo" style="">5 </h1><h1 id="foo" style="">6 </h1><h1 id="foo" style="">7 </h1><h1 id="foo" style="">8 </h1><h1 id="foo" style="">9 </h1><h1 id="foo" style="">10 </h1>               </div>
                <div style="float:right;width:256px;">
 <?php $sql = mysql_query("SELECT * FROM users ORDER BY vip_points DESC LIMIT 10"); while($d = mysql_fetch_array($sql)) { ?>
                                <div id="staff" style="width: 100%;">
                    <div class="avatar" style="background-image:url(<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $d['look']; ?>);">
                    </div>
                    <div class="about">
                        <span class="pseudo"><?php echo $d['username']; ?></span>
                        <span class="mission">Points Gamer: <?php echo $d['vip_points']; ?></span>
                                   
                    </div>
                </div>
                               
        
                        <?php } ?>          </div>
            </div>
        </div>      
        <div id="right" class="column63">
            <div id="box">  
                <p style="padding:14px;">
                Ici, c'est le tableau des gamers. À chaque fois que tu gagneras un jeu animé par un staff, tu remporteras 1 point. À la fin de chaque mois, les trois premiers remporteront des récompenses inédites. <i>(le classement se remettra à zero à chaque début de mois)</i>
                <br><br>
                <b>1</b> - 200 jetons <br>
                <b>2</b> - 100 jetons <br>
                <b>3</b> - 25 adov points<br><br>
                </p>
                <p style="padding-left: 14px;margin-top: -15px;border-top: solid 1px rgba(68, 68, 68, 0.67);">
                
                <b><u>Le palmarès des gagnants:</b></u><br>
                <b>Mars 2016 : Yazpeur !</b>
                
                </p>
            </div>
        </div>      
    <div class="clear"></div>
<!-- FOOTER -->
<?php include("./templates/footer.php"); ?>
<!-- FIN FOOTER -->

</body>
</html>