<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
include("./includes/files/submit.php");
include("./includes/files/register.submit.php");
include("./includes/files/session.connect.php");

$pagename = "Inscris-toi!";
$pageid = "registre";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
	<link rel="stylesheet" type="text/css" href="gallery/css/index.css?1461255333">
	 <link rel="shortcut icon" href="./favicon.ico">
	 <meta name="twitter:title" content="Adov: Entre dans un hôtel où tout est gratuit, fais-toi plein d'amis et deviens célèbre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="Rétro Habbo">
    <meta property="og:site_name" content="Habbo Hôtel"/>
    <meta property="og:title" content="Habbo: Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, réseau social, gratuit, communautée, avatar, chat, connectée, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécuritée, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>

	<script src='https://www.google.com/recaptcha/api.js'></script>
	<style>
	input{
    width: 300px;
}
.error-result{
	background-color: darkred;
	padding: 10px;
	color: #fff;
	border-bottom: dotted 3px rgba(0, 0, 0, 0.3);
	text-align: center;
	font-size: 15px;
	text-shadow: 0px 0px 2px rgba(0, 0, 0, 0.3);
}</style>
</head>
         	<?php if($erreurc == true) { ?>
	<div class="error-result"><?php echo $erreurmess; ?></div>
    <?php } ?>
	

    <?php if(isset($message5)) { ?>
    <div class="error-result"><?php if(isset($message5['username'])) { echo "".$message5['username'].""; } ?></div>
    <?php } ?>
            <?php if(isset($message4)) { ?>
    <div class="error-result"><?php if(isset($message4['email'])) { echo "".$message4['email'].""; } ?></div>
    <?php } ?>

    <?php if(isset($message2)) { ?>
    <div class="error-result"><?php if(isset($message2['password'])) { echo "".$message2['password'].""; } ?></div>
    <?php } ?>
    <?php if(isset($message3)) { ?>
    <div class="error-result"><?php if(isset($message3['password'])) { echo "".$message3['password'].""; } ?></div>
    <?php } ?>
<body>
		<header>
		<div id="center">

			<h1 class="logo"></h1>
			<div id="form">
				<a href="./" class="retour">J'ai un compte</a>
			</div>
		</div>
	</header>
	<div id="registerForm">
		<div id="center">
			<div id="register">
				<h1>Inscription</h1>
				<p style="font-size:13px;">
					Tu es à deux doigts de devenir un membre à part entière de la communauté <b><?php echo Settings('Name'); ?></b>.. rempli ces champs afin de devenir joueur du rétro.
				</p>
				<form action="?do=register" method="post">
					<label for="username">Nom d'utilisateur</label>
					<input class="input-register" type="text" name="username" placeholder="Nom d'utilisateur">
					<label for="mail">Adresse électronique</label>
					<input class="input-register" type="text" name="email" placeholder="Adresse électronique">
					<label for="password">Mot de passe</label>
					<input class="input-register" type="password" name="password" placeholder="Mot de passe">
					<label for="repassword">Répète ton mot de passe</label>
					<input class="input-register" type="password" name="repassword" placeholder="Répète le (pour être sûr)">
					<label for="captcha">Captcha (reCaptcha)</label>
					<div class="g-recaptcha" data-sitekey="6LeNRRgTAAAAAI07ZKlYI3XkDNsucCNL6sM2h4tm"></div>	
					<input class="input-register-submit" type="submit" value="Validation">
				</form>
						
				
			</div>
		</div>
		<div id="img">
			<img src="https://habboo-a.akamaihd.net/habbo-web/america/en/assets/images/teaser_registration.03349de5.png" alt="">
		</div>
	</div>
	<div id="center">
<?php include("./templates/footer.php"); ?>
</body>
</html>