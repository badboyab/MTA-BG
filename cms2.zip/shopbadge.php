<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
include("./includes/files/session.disconnect.php");
    
$pagename = "Boutique";
$pageid = "boutique";
 $menu_id="13"


?>
<!DOCTYPE html>


<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<head>
    <meta charset="UTF-8">
    <title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
    <link rel="stylesheet" type="text/css" href="gallery/css/global.css?1461255333">
    <link rel="stylesheet" type="text/css" href="gallery/css/shop.css?1461255333">
    <link rel="shortcut icon" href="./favicon.ico">

    <meta name="twitter:title" content="Adov: Entre dans un hôtel où tout est gratuit, fais-toi plein d'amis et deviens célèbre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="Rétro Habbo">
    <meta property="og:site_name" content="Habbo Hôtel"/>
    <meta property="og:title" content="Habbo: Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, réseau social, gratuit, communautée, avatar, chat, connectée, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécuritée, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>
<style>
    #box p{
        font-size: 12px;
    }

    .error-result{
        background-color: darkred;
        padding: 10px;
        color: #fff;
        border-bottom: dotted 3px rgba(0, 0, 0, 0.3);
        text-align: center;
        font-size: 15px;
        text-shadow: 0px 0px 2px rgba(0, 0, 0, 0.3);
    }

    .success-result{
        background-color: green;
        padding: 10px;
        color: #fff;
        border-bottom: dotted 3px rgba(0, 0, 0, 0.3);
        text-align: center;
        font-size: 15px;
        text-shadow: 0px 0px 2px rgba(0, 0, 0, 0.3);
    }
    .pray {
    background-color: #F2F2F2;
    width: 340px;
    margin-left: -43px;
}
.shake {
    display: inline-block;
}
#credits-methods li {
    background-color: transparent;
}
#credits-methods {
    list-style: none;
    margin-top: 4px;
    clear: both;
}
body a.new-button.fill, html>body a.new-button.fill b {
    display: block;
    float: none;
}
a.new-button b {
    float: left;
    padding: 5px 17px 4px 20px;
    font-size: 11px;
    height: 17px;
    margin-right: 3px;
    background: rgb(226, 226, 217) url(/game/web-gallery/images/new_button.png) no-repeat -3px 0;
    color: #000;
    font-weight: bold;
    text-align: center;
    display: inline;
}
a.new-button i {
    position: absolute;
    right: 0;
    top: 0;
    width: 3px;
    height: 25px;
    background: transparent url(/game/web-gallery/images/new_button.png) no-repeat 0 0;
}
    </style>
</head>

<?php include("./templates/header.php"); ?>


        <center>
    <div id="hash2">
 <center> <h3> <img style="width: 17px; height: 17px;" alt=""
src="/gallery/imgs/inter.png"> ATTENTION ! D&eacute;connecte toi de l'hotel avant d'acheter <img style="width: 17px; height: 17px;" alt=""
src="/gallery/imgs/inter.png"></h3> </center> </div>
<br>
</center>
                <div id='container'></div>
        <div id='content'>
        <div id="left" class="column4" style="width:360px;">
            <div id="box">  
                <div class="titre" style="background-color: #EA0066;"><center>Collections de badges</center></div>
</center>
<center>


  <?php $sql = mysql_query("SELECT * FROM retrophp_badges"); while($b = mysql_fetch_array($sql)) { ?>
    <a href="<?php echo Settings('Url'); ?>/shopbadge.php/<?php echo $b['badge_id']; ?>"><img style="margin-top:23px;margin-left:3px;" src="<?php echo Settings('C_Images'); ?>/album1584/<?php echo $b['badge_id']; ?>.gif"></a>
                </div>
                <?php } ?>
</center>
</center>
</div></div>

<div id='container'>
        <div id='content'>
         <div id="right" class="column4" style="width:350px;">
            <div id="box">  
                <div class="titre" style="background-color: #f66200;"><center>Badges individuels</center></div>
</center>
</div></div>

        </div></div>
    <div class="clear"></div>
<!-- FOOTER -->
<?php include("./templates/footer.php"); ?>
<!-- FIN FOOTER -->

</body>
</html>