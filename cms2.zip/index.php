﻿<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
include("./includes/files/submit.php");
include("./includes/files/register.submit.php");
include("./includes/files/session.connect.php");

$pagename = "Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis.";
$pageid = "index";
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link rel="alternate" hreflang="<?php echo Settings('Lang'); ?>" href="<?php echo Settings('Url'); ?>" />
    <meta itemprop="name" content="<?php echo Settings('Name'); ?>">
    <meta itemprop="description" content="<?php echo Settings('Name'); ?> Hotel - <?php echo Settings('Description'); ?>">
    <meta itemprop="image" content="<?php echo Settings('Url'); ?>/images/<?php echo Settings('Logo'); ?>">

    <meta property="fb:app_id" content="<?php echo Settings('APP_ID'); ?>" />

    <meta name="google" content="notranslate" />

    <meta property="og:site_name" content="<?php echo Settings('Name'); ?>" />
    <meta property="og:title" content="<?php echo $pagename; ?>" />
    <meta property="og:url" content="<?php echo Settings('Url'); ?>" />
    <meta property="og:image" content="<?php echo Settings('Url'); ?>/images/fb_img.gif" />

    <meta name="description" content="<?php echo Settings('Name'); ?> Hotel - <?php echo Settings('Description'); ?>" />
    <meta name="keywords" content="<?php echo Settings('Name'); ?>, <?php echo Settings('Keyword'); ?>" />
    <title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/gallery/css/index.css?<?php echo $update; ?>">
</head>
    <?php if($erreurc == true) { ?>
    <div class="error-result"><?php echo $erreurmess; ?></div>
    <?php } ?>
    

    <?php if(isset($message5)) { ?>
    <div class="error-result"><?php if(isset($message5['username'])) { echo "".$message5['username'].""; } ?></div>
    <?php } ?>
            <?php if(isset($message4)) { ?>
    <div class="error-result"><?php if(isset($message4['email'])) { echo "".$message4['email'].""; } ?></div>
    <?php } ?>

    <?php if(isset($message2)) { ?>
    <div class="error-result"><?php if(isset($message2['password'])) { echo "".$message2['password'].""; } ?></div>
    <?php } ?>
    <?php if(isset($message3)) { ?>
    <div class="error-result"><?php if(isset($message3['password'])) { echo "".$message3['password'].""; } ?></div>
    <?php } ?>
<body>
        <header>
        <div id="center">
            <h1 class="logo"></h1>
            <div id="form">
                <form method="post" action="?do=connect">
                <?php if($erreurc == false) { ?>
                <input type="text" placeholder="Mon pseudonyme" value="<?PHP echo $ipseudo['username'] ; ?>" name="username">
                <input type="password" placeholder="Mot de passe" name="password">
                <?php } ?>
                <?php if($erreurc == true) { ?>
                <input type="text" placeholder="Pseudo" value="<?PHP echo $username; ?>" name="username">
                <input type="text" placeholder="Mot de passe" name="password">
                <?php } ?>
                <input type="submit" value="Connexion">
            </form>
            </div>
        </div>
    </header>
    <div id="hotel">
        <h1>Bienvenue sur <?php echo Settings('Name'); ?> Hôtel</h1>
        <p>
            Si tu n'as pas de compte, inscris-toi c'est gratuit!
        </p>
        <a href="./registre" class="btn">Inscription</a>
    </div>
    <div id="center">
        <footer>
    <div id="leftfooter">
        <div class="hotelcopy"></div>
    </div>
    <div id="rightfooter">
    <p class="right">
    <span style="font-size:12px;"> Wolpeur &copy; Copyright - <span class="dev"><?php echo Settings('Name'); ?></span> 2016-2017</span>
    <br>
    <?php echo Settings('Name'); ?> est un projet indépendant, à but non lucratif. 
    <br> 
    Nous ne sommes pas approuvé, affiliés, ou offertes par Sulake Corporation LTD.
    </p>
    </div>
</footer>
    </div>
    <div style="position: fixed;"><strong><font style="color:rgba(100,100,100,0); font-size:2px;">adov, habdo hotel, habbo, HABBO, habboo, habb0, britania, bobbabeta, beta, habbo hotel, retro, habbo retro, habbo retro gratuit, autre habbo, habbo autre, habbo retro qui marche bien, habbobeta, habbol, habboz, habbodreams, habbor, habbonoel, bobbahotel, newlifebobba, vip, virtuel, monde, réseau social, gratuit, communauté, avatar, chat, connecté, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécurité, jouer, jeux, amis, rares, ados, jeunes, habbo hotel, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, création, badges, musique, célébrité, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, butterfly, kiff, love, rencontre habbo, rencontre, habbo, habbo gratuit, habbo credit, credit, credits, youtube, facebook, habbo france, habbo dreams, jabbo, rabbo</font>
</strong></div>
</body>
</html>