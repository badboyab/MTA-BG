<?php 
// RetroPHP ne prend désormais pas en compte les divers problèmes que vous pouvez rencontrer sur votre CMS si celui-ci n'a pas été acheté sur RetroPHP. //
$cms = "PobbaCMS";
$version = "0.4"; 
?>