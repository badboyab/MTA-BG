<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
    
$pagename = "Communauté";
$pageid = "communaute";
 $menu_id="4"
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
    <link rel="stylesheet" type="text/css" href="gallery/css/global.css?1461255333">
    <link rel="stylesheet" type="text/css" href="gallery/css/community.css?1461255333">
    <link rel="shortcut icon" href="./favicon.ico">

    <meta name="twitter:title" content="Adov: Entre dans un hôtel où tout est gratuit, fais-toi plein d'amis et deviens célèbre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="Rétro Habbo">
    <meta property="og:site_name" content="Habbo Hôtel"/>
    <meta property="og:title" content="Habbo: Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, réseau social, gratuit, communautée, avatar, chat, connectée, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécuritée, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>
<style>
    #box p{
        font-size: 12px;
    }</style>
</head>
<body>
<?php include("./templates/header.php"); ?>
    <div id="content" class="page">
        <h1 class="news_titre">Les 30 derniers articles</h1>
        <ul class="news">
         <?php
$news1_5 = mysql_query("SELECT * FROM retrophp_news ORDER BY ID DESC LIMIT 13") or die(mysql_error());
if(mysql_num_rows($news1_5) > 0){
?>
<?php
$i = 0;
$back = '1';
    $sql = mysql_query("SELECT * FROM retrophp_news ORDER BY id DESC LIMIT 0,13");
    while($news = mysql_fetch_array($sql)) { 
    $i++ 
    ?>
        <li>
            <div class="img" style="background-image:url(<?php echo $news['topstory_image']; ?>);"></div>
            <h3><?php echo $news['title']; ?></h3>
            <p>
                <?php echo $news['snippet']; ?>
            </p>
            <a class="suite" href="<?php echo Settings('Url'); ?>/articles/<?php echo $news['id_page']; ?>"><?php echo $news['mini_text']; ?></a>
        </li>
         
      <?php 
if($back == '1'){
$back = '2';
} else if($back == '2') {
$back = '3';
} else if($back == '3') {
$back = '4';
} else if($back == '4') {
$back = '5';
} else {
$back = '1';
} } ?>
<?php } ?> 
         
        </ul>
        
    
    <div class="clear"></div>
<?php include("./templates/footer.php"); ?>
    </div>
</body>
</html>