<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
include("./includes/files/submit.php");
include("./includes/files/register.submit.php");
include("./includes/files/session.connect.php");

$pagename = "Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis.";
$pageid = "index";
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<link rel="alternate" hreflang="<?php echo Settings('Lang'); ?>" href="<?php echo Settings('Url'); ?>" />
	<meta itemprop="name" content="<?php echo Settings('Name'); ?>">
	<meta itemprop="description" content="<?php echo Settings('Name'); ?> Hotel - <?php echo Settings('Description'); ?>">
	<meta itemprop="image" content="<?php echo Settings('Url'); ?>/images/<?php echo Settings('Logo'); ?>">

	<meta property="fb:app_id" content="<?php echo Settings('APP_ID'); ?>" />

	<meta name="google" content="notranslate" />

	<meta property="og:site_name" content="<?php echo Settings('Name'); ?>" />
	<meta property="og:title" content="<?php echo $pagename; ?>" />
	<meta property="og:url" content="<?php echo Settings('Url'); ?>" />
	<meta property="og:image" content="<?php echo Settings('Url'); ?>/images/fb_img.gif" />

	<meta name="description" content="<?php echo Settings('Name'); ?> Hotel - <?php echo Settings('Description'); ?>" />
	<meta name="keywords" content="<?php echo Settings('Name'); ?>, <?php echo Settings('Keyword'); ?>" />
	<title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/templates/view/css/index.css?<?php echo $update; ?>">
</head>

<body>

	<?php if($erreurc == true) { ?>
	<div class="error-result"><?php echo $erreurmess; ?></div>
    <?php } ?>
	

    <?php if(isset($message5)) { ?>
    <div class="error-result"><?php if(isset($message5['username'])) { echo "".$message5['username'].""; } ?></div>
    <?php } ?>
            <?php if(isset($message4)) { ?>
    <div class="error-result"><?php if(isset($message4['email'])) { echo "".$message4['email'].""; } ?></div>
    <?php } ?>

    <?php if(isset($message2)) { ?>
    <div class="error-result"><?php if(isset($message2['password'])) { echo "".$message2['password'].""; } ?></div>
    <?php } ?>
    <?php if(isset($message3)) { ?>
    <div class="error-result"><?php if(isset($message3['password'])) { echo "".$message3['password'].""; } ?></div>
    <?php } ?>
	<div class="center">
		<div class="logo">
			<img src="<?php echo Settings('Url'); ?>/templates/view/imgs/logo2.png?<?php echo $update; ?>" alt="<?php echo Settings('Name'); ?>">
		</div>

		<div class="right">
			<form method="post" action="?do=connect">
				<?php if($erreurc == false) { ?>
    			<input type="text" placeholder="Mon pseudonyme" value="<?PHP echo $ipseudo['username'] ; ?>" name="username">
				<input type="password" placeholder="Mot de passe" name="password">
    			<?php } ?>
    			<?php if($erreurc == true) { ?>
    			<input type="text" placeholder="Pseudo" value="<?PHP echo $username; ?>" name="username">
    			<input type="text" placeholder="Mot de passe" name="password">
    			<?php } ?>
				<input type="submit" value="Connexion">
			</form>
		</div>
		<div class="clear"></div>
		<div class="container">
			<div class="left">
				
			</div>
			<div class="right">
				<div style="padding:8px;">
					<h1>Inscris-toi gratuitement sur <?php echo Settings('Name'); ?> !</h1>
					<p class="descr-bvn">
						Bienvenue sur <?php echo Settings('Name'); ?>! Un monde virtuel qui t'offre l'occasion de revivre d'anciennes sensations mixées dans de nouvelles.  Les anciens membres pylônes ayant marqué le passé du monde des rétros-serveurs s'engagent à vous procurer l'une des meilleures et de plus innovantes des expériences pixellisées que vous aurez jamais eu au sein de ce vaste monde.					</p>
					<form method="post" action="?do=register">
					<input class="input-register" type="text" name="username" placeholder="Nom d'utilisateur"> <br>
					<input class="input-register" type="text" name="email" placeholder="Adresse électronique"> <br>
					<input class="input-register" type="password" name="password" placeholder="Mot de passe"> <br>
					<input class="input-register" type="password" name="repassword" placeholder="Répète le (pour être sûr)"> <br>
					<div class="clear"></div>
					<input class="input-register-submit" type="submit" value="Validation">
					</form>
				</div>
			</div>
		</div>
		<div class="clear"></div>
		<footer>
			<?php echo Settings('Name'); ?> est un projet indépendant, à but non lucratif. <br>
			Nous ne sommes pas approuvé, affiliés, ou offertes par Sulake Corporation LTD.			
		</footer>
	</div>
</body>
</html>
