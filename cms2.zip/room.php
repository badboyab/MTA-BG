<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include './init.php';

$id = safe($_GET['id'],'SQL');

if(Settings('Emulator') == 'Butterfly') {
$rm = $bdd->query("SELECT * FROM rooms WHERE id = '".safe($id,'SQL')."'");
} else {
$rm = $bdd->query("SELECT * FROM rooms WHERE id = '".safe($id,'SQL')."'");
}
$room = $rm->fetch(PDO::FETCH_ASSOC);


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo Settings('Name'); ?>: <?php echo $room['caption']; ?> </title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>


<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>

<?php include './templates/meta.php'; ?>

</head>
<body>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/visual.js?<?php echo $update; ?>" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/common.js?<?php echo $update; ?>" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/common.css?1<?php echo $update; ?>" type="text/css" />

<div style="width:500px; margin: 0 auto; text-align: left" id="content">
<div class="habblet-container">		
	<div class="cbb clearfix blue">
		<h2 class="title">Bienvenue à <?php echo Settings('Name'); ?> Hotel!</h2>
	<div class="habblet box-content">
			<img src="<?php echo Settings('Url'); ?>/images/app_habbo_hotel_image.gif" style="float: left; margin-right: 20px; width: 75px; height: 75px"/>
			<div id="fb-like-room-details" style="float: left; width: 300px">
				<h4 style="margin: 0; padding: 0">Nom</h4>
				<?php $titre = htmlentities($room['caption'], ENT_QUOTES, "UTF-8"); ?>
				<?php echo utf8_encode(safe($titre,'SQL')); ?>
				<h4 style="margin: 10px 0 0 0; padding: 0">Propriétaire</h4>
				<?php echo $room['owner']; ?>
				<p style="margin-top: 20px" class="clearfix">

				<a href="<?php echo Settings('Name'); ?>/client?roomId=<?php echo $room['id']; ?>" id="enter-room" style="display: none" class="btn-gloss left"><b>Clique pour entrer dans l'appart</b><i></i></a>

				<div style="display: none; vertical-align: middle;" id="progress"><img src="<?php echo Settings('Url'); ?>/images/ajax-loading.gif" width="31" height="31" style="vertical-align: middle;"/> Accéder à l'appart</div>
				</p>
			</div>			
	</div>
									
	</div>
</div>
</div>

<script type="text/javascript">
		HabboClient.isClientPresent(function(response) {
			if (response == false) {
				$("progress").show();
				setTimeout(function() {
					window.location.replace("<?php echo Settings('Url'); ?>/client?roomId=<?php echo $room['id']; ?>");
				}, 4000);
			} else {
		        $("room-opened-notice").show();			  
		        new Ajax.Request("<?php echo Settings('Url'); ?>/client", {
		            parameters: "roomId=<?php echo $room['id']; ?>"
		        }, false);				
			}
		});
		
</script>
<script type="text/javascript">
if (typeof HabboView != "undefined") {
	HabboView.run();
}
</script>


</body>
</html>
