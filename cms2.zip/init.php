<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                D�veloppement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
header('Pragma: no-cache');

@session_start();

/*+===================================+
|   Importation des librarys          |
+===================================+*/

@include("./includes/settings.inc.php");
@include("../includes/settings.inc.php");

$requete = mysql_query("SHOW TABLES LIKE 'retrophp_settings'")or die(mysql_error());
if(mysql_num_rows($requete) == 0) { @header("Location: ./install/"); }

@include("./includes/functions.php");
@include("../includes/functions.php");

@include("./includes/core.php");
@include("../includes/core.php");
?>