<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");

$pageid = "news";

$id = Securise($_GET['id']);
$sql = mysql_query("SELECT * FROM retrophp_news WHERE id_page = '".$id."'");
$n = mysql_fetch_assoc($sql);

$date1 = date('d F Y', $n['date']); 
$date1 = str_replace("Monday", "Lundi", $date1);
$date1 = str_replace("Tuesday", "Mardi", $date1);
$date1 = str_replace("Wednesday", "Mercredi", $date1);
$date1 = str_replace("Thursday", "Jeudi", $date1);
$date1 = str_replace("Friday", "Vendredi", $date1);
$date1 = str_replace("Saturday", "Samedi", $date1);
$date1 = str_replace("Sunday", "Dimanche", $date1);
$date1 = str_replace("January", "janv.", $date1);
$date1 = str_replace("February", "fév.", $date1);
$date1 = str_replace("March", "mars", $date1);
$date1 = str_replace("April", "avr.", $date1);
$date1 = str_replace("May", "mai", $date1);
$date1 = str_replace("June", "juin", $date1);
$date1 = str_replace("July", "juil.", $date1);
$date1 = str_replace("August", "août", $date1);
$date1 = str_replace("September", "sept.", $date1);
$date1 = str_replace("October", "oct.", $date1);
$date1 = str_replace("November", "nov.", $date1);
$date1 = str_replace("December", "déc.", $date1);

$pagename = "Les News - ".$n['title'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
 <link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/gallery/css/global.css?1461255333">
    <link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/gallery/css/community.css?1461255333">
    <link rel="shortcut icon" href="./favicon.ico">

    <meta name="twitter:title" content="Adov: Entre dans un hôtel où tout est gratuit, fais-toi plein d'amis et deviens célèbre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="Rétro Habbo">
    <meta property="og:site_name" content="Habbo Hôtel"/>
    <meta property="og:title" content="Habbo: Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, réseau social, gratuit, communautée, avatar, chat, connectée, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécuritée, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>
 <style type="text/css">
    #box p{
        font-size: 12px;
    }</style>
</head>
<body>
    <?php include("./templates/header.php"); ?>
    <div id="content" class="page">
        
                    <div id="left" style="width:200px;">
            <div id="box2">
                <div class="titre2">Articles</div>
                <ul class="list">
   <?php
$sql = mysql_query("SELECT * FROM retrophp_news ORDER BY id DESC");   
while($news = mysql_fetch_array($sql)) { ?>
<?php if($news['id'] == $n['id']) { ?>
                     <li>
                       <?php echo $news['title']; ?>
                    </li>
<?php } else { ?>
 <a href="<?php echo Settings('Url'); ?>/articles/<?php echo $news['id_page']; ?>"><?php echo $news['title']; ?> »</a><?php }} ?>
                                </ul>
            </div>
        </div>
        <div id="right" style="width:554px;">
            <div id="box2">
                <div class="titre2"><?php echo $n['title']; ?>
                <div class="titre3"><i>Publié par l'équipe</i></div></div>
                <div class="article-body"><br>
               <?php echo $n['body']; ?>
                <br>
                </div>
                <div class="clear"></div>
                <b style="color:#444;font-size:13px;">Publié le <?php echo $date1." ".date('', $n['date']); ?></b>
            </div>
        </div>
            
    <div class="clear"></div>
<?php include("./templates/footer.php"); ?>
    </div>
</body>
</html>