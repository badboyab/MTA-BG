<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

$pageid = "maintenance";
include("./init.php");

$pagename = "maintenance";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="refresh" content="60; url=/">
    <title><?PHP echo $name; ?></title>
    <meta name="description" content="">
    <link rel="stylesheet" type="text/css" href="//habboo-a.akamaihd.net/maintenance/main-66f55605d9ee2b8f3c571910eb12c551.css">
</head>
<?php include("./templates/meta.php"); ?>
<body>
<header>
    <div class="wrapper"> 
        <a href="<?php echo Settings('Url'); ?>/" class="habbo-image"></a>
    </div> 
</header>
<div class="page-content">
    <div class="wrapper" style="position:relative">
        <div class="card-wrapper">
            <div class="card left" style="height:370px">
                <h1>MAINTENANCE BREAK!</h1>
                <p>Nous sommes désolés mais tu ne peux pas te connecter pour l'instant. Nous sommes en train de mettre à jour.</p> 
                <img src="//habboo-a.akamaihd.net/maintenance/habboWeb_error-ebecbcd43a969fd176de350b5e85fe81.png" alt=""/></div>
            </div>
            <div class="card-wrapper">
            </div>
        </div>
    </div> 
    <footer class="footer">
        <div class="wrapper">
            <div class="footer__media">
                <p class="footer__media__label" translate="">Nous suivre</p>
                <ul>
                    <li class="footer__media__item">
                        <a href="#" class="icon__button">
                            <span class="icon--facebook--footer"></span>
                        </a>
                    </li>
                    <li class="footer__media__item">
                        <a href="#" class="icon__button">
                            <span class="icon--twitter--footer"></span>
                        </a>
                    </li>
                    <li class="footer__media__item">
                        <a href="#" class="icon__button">
                            <span class="icon--youtube--footer"></span>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="footer__content">
                <ul class="footer__nav">
                    <li class="footer__nav__item">
                        <a href="#">Aide - Contact</a>
                    </li>               
                    <li class="footer__nav__item">
                        <a href="/safety/habbo_way">La Habbo attitude</a>
                    </li>
                    <li class="footer__nav__item">
                        <a href="#">Partenaires/publicité</a>
                    </li>
                </ul>
                <p class="footer__copyright">© 2004 - 2014 Sulake Corporation Oy. HABBO is a registered trademark of Sulake Corporation Oy in the European Union, the USA, Japan, the People's Republic of China and various other jurisdictions. All rights reserved.</p>
            </div>
        </div> 
    </footer>
</body>
</html>