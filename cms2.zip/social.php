<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
    
$pagename = "Réseaux sociaux";
$pageid = "social";
 $menu_id="8"
?>
<!DOCTYPE html>


<title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
<head>
    <meta charset="UTF-8">
    <title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
 <link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/gallery/css/global.css?1461255333">
    <link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/gallery/css/social.css?1461255333">
    <link rel="shortcut icon" href="./favicon.ico">
    <meta name="twitter:title" content="Adov: Entre dans un hôtel où tout est gratuit, fais-toi plein d'amis et deviens célèbre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="Rétro Habbo">
    <meta property="og:site_name" content="Habbo Hôtel"/>
    <meta property="og:title" content="Habbo: Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, réseau social, gratuit, communautée, avatar, chat, connectée, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécuritée, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>
 <style type="text/css">
    #box p{
        font-size: 12px;
    }</style>
</head>

<?php include("./templates/header.php"); ?>

<div id="content" class="page">
        <div id="box">
            <div class="titre" style="background-color:#999087;">R&eacute;seaux Sociaux</div>
            <div id="social">
                <h2>Joue-la social!</h2>
                <h3>Adov prend le virage social - Et toi?</h3>
                <p>
                    <img src="http://habdo.fr/gallery/imgs/icon_face_book.png"><br>
                    <b>Facebook</b><br>
                    FR: <a href="https://www.facebook.com/HabdoFR" target="_blank">www.facebook.com/HabdoFR</a><br>
                </p>
                
                <p>
                    <img src="http://habdo.fr/gallery/imgs/logo_twitter.png"><br>
                    <b>Twitter</b><br>
                    Joue les prolongations sur nos pages Twitter. 'SUIS'-nous pour tout savoir en temps r&eacute;el des nouveaut&eacute;s, des offres et de tout autre contenu &agrave; ne pas manquer!<br>
                <br>
                    FR: <a href="https://twitter.com/HabdoFR" target="_blank">www.twitter.com/HabdoFR</a><br>
                </p>
            </div>
        </div>
    <div class="clear"></div>
<!-- FOOTER -->
<?php include("./templates/footer.php"); ?>
<!-- FIN FOOTER -->

</body>
</html>