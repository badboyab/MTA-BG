<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
include("./includes/files/session.disconnect.php");
    
$pagename = "Boutique";
$pageid = "boutique";
 $menu_id="12"


?>
<!DOCTYPE html>

<title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<head>
    <meta charset="UTF-8">
    <title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
    <link rel="stylesheet" type="text/css" href="gallery/css/global.css?1461255333">
    <link rel="stylesheet" type="text/css" href="gallery/css/vip.css?1461255333">
    <link rel="shortcut icon" href="./favicon.ico">

    <meta name="twitter:title" content="Adov: Entre dans un hôtel où tout est gratuit, fais-toi plein d'amis et deviens célèbre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="Rétro Habbo">
    <meta property="og:site_name" content="Habbo Hôtel"/>
    <meta property="og:title" content="Habbo: Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, réseau social, gratuit, communautée, avatar, chat, connectée, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécuritée, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>
<style>
    #box p{
        font-size: 12px;
    }</style>
</head>

<?php include("./templates/header.php"); ?>

<div id="content" class="page">
        <center>
    <div id="hash2">
 <center> <h3> <img style="width: 17px; height: 17px;" alt=""
src="/gallery/imgs/inter.png"> ATTENTION ! D&eacute;connecte toi de l'hotel avant d'acheter <img style="width: 17px; height: 17px;" alt=""
src="/gallery/imgs/inter.png"></h3> </center> </div>
<br>
</center>
                <div id="box">
             <div id="column1" class="column" style="width: 760px;">
        <div class="habblet-container ">
            <div class="cbb clearfix blue ">
                <div class="vipclub_2">
                    <img style="width: 64px; height: 110px;margin-top:90px;margin-left:80px;" src="<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $user['look']; ?>&amp;action=wav"/>
                    <a href="shop"><div class="x_jetons">Prix 150 jetons</div></a>
                </div>
                <br/>
                <div class="lleft_1">
                    <div class="avantage_2"></div> <br/>
                    <span class="list">1.</span> La possibilité de rentrer dans tous <b>les apparts fermés de l'hôtel</b><br/>
                    <span class="list">2.</span> 500 000 crédits offerts!<br/>
                    <span class="list">3.</span> 300 duckets offerts!<br/>
                    <span class="list">4.</span> 5000 win-win offerts!<br/>
                    <span class="list">5.</span> Possibilité de changer de nom gratuitement<br/>
                    <span class="list">6.</span> Tu reçois un textamigo du Fondateur<br/>
                 
                    <span class="list">8.</span> La catégorie <b>VIP RARES</b> dans ton catalogue!<br/>
                    <span class="list">9.</span> <b>15 badges</b> d'une collection<br/>
                    <img src="/game/c_images/album1584/HFW15.gif" alt=""/>
                    <img src="/game/c_images/album1584/BR937.gif" alt=""/>
                    <img src="/game/c_images/album1584/IT979.gif" alt=""/>
                    <img src="/game/c_images/album1584/HST82.gif" alt=""/>
                    <img src="/game/c_images/album1584/DE827.gif" alt=""/>
                    <img src="/game/c_images/album1584/FR723.gif" alt=""/>
                    <img src="/game/c_images/album1584/BR631.gif" alt=""/>
                    <img src="/game/c_images/album1584/UK460.gif" alt=""/>
                    <img src="/game/c_images/album1584/IT203.gif" alt=""/>
                    <img src="/game/c_images/album1584/UK390.gif" alt=""/>
                    <img src="/game/c_images/album1584/IT713.gif" alt=""/>
                    <img src="/game/c_images/album1584/VIPW1.gif" alt=""/>
                    <img src="/game/c_images/album1584/VIPW2.gif" alt=""/>
                    <img src="/game/c_images/album1584/VIPW3.gif" alt=""/>
                    <img src="/game/c_images/album1584/VIPW.gif" alt=""/><br />
                    <span class="list">10.</span> Lecture de ton CV prioritaire aux recrutements<br/>
                    <span class="list">11.</span> Avoir la classe <img src="/gallery/imgs/smiley-cool.gif"><br/>
                    <span class="list">12.</span> Les <b>commandes</b> exclusives à découvrir:<br/>
                    <b>:transf</b> - qui te permettra de te transformer en un animal de ton choix<br/>
                    <b>:fastwalk</b> - Marcher beaucoup plus vite<br/>
                    <b>:mimic</b> - Copier le look d'une personne<br/>
                    <b>:push</b> - Pousser un utilisateur<br/>
                    <b>:spull</b> - Tirer une personne vers vous<br/>
                    <b>:follow</b> - Rejoindre une personne<br/>
                    <b>:fastwalk</b> - Marcher beaucoup plus vite<br/>
                    <b>:moonwalk</b> - Marcher à reculon<br/>
                    <b>:enable</b> - Utiliser un effet<br/>
                    et bien d'autres à découvrir grâce à la commande : 
                    <b>:commands</b><br />
                    <span class="list">13.</span> Et bien plus encore...<br/>
                    <center><img alt="" src="/gallery/imgs/xmas_habbo.png"/></center>
                    
                </div>
                <div class="rrigth_1">
                    <div class="catalogue_2"></div>
                    <div style="text-align:center;"><br/>
                    <div class="catavip_2"></div><br/>
                    <u><b>Rares offert en cadeau :</b></u></div>

                    <div class="rarevip"></div><br/>
                    <div style="text-align:center;"><b>Deux rares offerts dans ton inventaire ! </b>
                    </div>
                </div>
                <a href="<?php echo Settings('Url'); ?>/proceedWithPayment/2"><
                <div style="text-align:center;"><input class="button_vip" type="submit" id="greeninput2" name="submitvip" value="Adhérer au VIP CLUB">
            </a>   </div></div>
        </div></div></div>
    <div class="clear"></div>
<!-- FOOTER -->
<?php include("./templates/footer.php"); ?>
<!-- FIN FOOTER -->

</body>
</html>