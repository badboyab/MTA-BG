<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
   $pagename = "HomePage"; 
$pageid = "homepage";
 $menu_id="2"

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>

    <link rel="stylesheet" type="text/css" href="gallery/css/global.css?1461255333">
<style type="text/css">
    .Offline{
        color: darkred;
    }
    .Online{
        color: darkgreen;
    }
    .badge-box{
        background-image: linear-gradient(#fff,#eee);
        height: 70px;
        width: 65px;
        text-align: center;
        line-height: 89px;
        border-radius: 4px;
        border: solid 1px #000;
        border-bottom: solid 2px #000;
        float: left;
        display: inline-block;
        margin-bottom: 2px;
        margin-right: 2px;
    }
    .center .titre{
    background-color: #444;
    color: #fff;
    border-radius: 4px 4px 0px 0px;
    padding: 8px;
    font-size: 16px;
    text-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);
    border: solid 1px rgba(0, 0, 0, 0.3);
}

.center .box{
    border-radius: 0px 0px 4px 4px;
    background-color: #fff;
    border: solid 1px rgba(0, 0, 0, 0.3);
    border-bottom: solid 2px rgba(0, 0, 0, 0.3);
    padding: 8px;
    clear: both;
    overflow: hidden;
    margin: auto;
    border-top: none;
    box-shadow: 1px 0px 0px rgba(255, 255, 255, 0.3), -1px -1px 0px rgba(255, 255, 255, 0.3);
}
    </style>

</head>

<body><?php include("./templates/header.php"); ?>
    <div class="center">
  <center>    <table><tr><td><div class="page-contenu">
            <div class="left" style="width:440px;">
                 <div class="titre"><b><?php echo  $user['username']; ?></b></div>
                <div class="box">
                    <div style="margin-top:-15px;">
                        <div style="float:left;width:58px;">
                        <img src="<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo  $user['look']; ?>&action=std,wav&gesture=std&direction=3&head_direction=3&size=n&img_format=png" style="float:left;margin-left:-5px;margin-top:15px;">
                        </div>
                        <div style="float:left;width:359px;margin-left:5px;font-size:13px;">
                        <div class="OnlineStatus"><br>
                        <?php if ( $user['online'] == 0) { ?>
                        <div class="Offline"><strong>Etat:</strong> Hors-Ligne</div>
                        <?php } ?>  
                        <?php if ( $user['online'] == 1) { ?>
                        <div class="Online"><strong>Etat:</strong> En-Ligne</div>
                        <?php } ?>                      </div>
                        <div class="UsersName"><strong>Nom:</strong> <?php echo  $user['username']; ?></div>
                        <div class="UsersMotto"><strong>Message Perso:</strong> <?php echo utf8_encode(stripslashes($user['motto'])); ?></div>
                        <div class="UsersMotto"><strong>Crédits: </strong><?php echo  $user['credits']; ?></div>
                        <div class="UsersMotto"><strong>Diamants:</strong> <?php echo  $user['seasonal_currency']; ?></div>
                        <div class="UsersLastLogin"><strong>Dernière connexion:</strong> <b><?php echo $date." ".date('H:i:s', $usid['last_offline']); ?></b> </div>
                        <div class="UsersCreated"><strong>Créé le:</strong> <?php echo $date." ".date('',  $user['account_created']); ?></div>
                         </div>
                  </div>
                </div>
                <div style="margin-top:2%;"></div>
                <div class="titre">Tous tes badges</div>
                <div class="box">
                    <?php
$badges = mysql_query("SELECT DISTINCT badge_id FROM user".$us."_badges WHERE user_id = ". $user['id']."");
while($badge = mysql_fetch_array($badges)) {
?>
                                        <div class="badge-box">
                        <img src="<?php echo Settings('C_Images'); ?>/album1584/<?php echo $badge['badge_id'];?>.gif">
                    </div>
                    <?php } ?>
                                    </div>
            </div>
                </td><td> <br><div class="right" style="width:310px;">
                <div class="titre">Les 5 derniers VIPS </div>
                <div class="box">
                    <?php $sql = mysql_query("SELECT * FROM users WHERE rank = '2' LIMIT 5"); while($vip = mysql_fetch_array($sql)) { ?>
                                        <div class="last-inscrit">
                        <div style="width:59px;height:48px;background:url('<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $vip['look']; ?>&direction=2') 0px 90px;float:left;margin:0px 10px 0px 0px;"></div>
                        <div style="width:211px;float:left;">
                            <a style="color:#444;text-decoration:none;" href=""><span style="font-size:17px;color:#444;font-weight:bold;"><?php echo $vip['username']; ?></span></a>
                            <span style="border-bottom: dotted 2px rgba(0, 0, 0, 0.2);display:block;font-size:14px;color:#444;">Nombre de diamants : <?php echo $vip['seasonal_currency']; ?> <br>
                             <br>
</div>
                        </div>
                    
                    <?php } ?></div>
                               </td></tr></table>         
                                    
            </div>
     
    <div class="clear"></div>
<?php include("./templates/footer.php"); ?>

</div>
</body>
</html>