<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");

    ?>
<!DOCTYPE html>

<html>
    
    <head> 

        
        <meta charset="utf-8">
        <meta name="viewport" content="width=1260">
<link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
        <title><?php echo Settings('Name'); ?> Erreur </title>


	<style>


/* FONT FACE */

@charset "utf-8";

/* MULTI FIXE */

*,form,img,p,tr,td,th,ul,li,button{
margin:0;
padding:0;
border: none;
outline: none;
background-color: transparent;
}

a,a:hover,a:link,a:visited{
font-size:10px;
color:white;
text-decoration:none;
}

::-webkit-input-placeholder { color: #454545; }
::-moz-placeholder { color:#454545; } /* firefox 19+ */
:-ms-input-placeholder { color:#454545; } /* ie */
input:-moz-placeholder { color:#454545; }

/* BODY */ 

html{
height: 100%;
}

body{
height: 100%;
width: 100%;
background-color: #2AA5D9;
background-repeat: repeat-x;
margin: auto;
font-family: "roman";
font-size: 11px;
position: absolute;
top: 0;
}

    /* OVERLAY */
    
    .body-overlay{
    height: 100%;
    width: 100%;
    position: fixed;
    background-color: rgba(0, 0, 0, 0.4);
    z-index: 1;
    cursor: pointer;
    top: 0;
    }

    /* BOUTON */
    
    button[effect="press"]{
    color: white;
    cursor: pointer;
    font-weight: bold;
    box-shadow: 3px 3px rgba(0, 0, 0, 0.4);
    text-transform: uppercase;
    font-family: 'Varela Round', sans-serif;
    text-shadow: 0px 0px 4px rgba(0, 0, 0, 0.4);
    }

    button[effect="press"]:active{
    position: relative;
    left: 3px;
    top: 3px;
    box-shadow: none;
    }  
    

    /* FOOTER */
    
    div#footer{
    height: 203px; /* 111PX != ADS */
    width: 100%;
    background-color: #101C16;
    overflow: hidden;
    display: none;
    }

        .footer-content{
        max-width: 860px;
        min-width: 800px;
        height: 54px;
        margin: 28px auto auto auto;
        padding: 0 10px 0 10px;
        }
            .footer-copyright{
            width: 90%;
            height: 31px;
            }
            
                .footer-copyright > span{
                color: white;
                font-size: 12px;
                float: left;
                }
                
            .footer-link{
            width: 90%;
            height: 13px;
            margin-top: 10px;
            }
            
                .footer-link > a{
                margin-right: 16px;
                float: left;
                color: white;
                font-size: 11px;
                text-decoration: underline;
                cursor: pointer;
                }
                

            .footer-ads{
            width: 728px;
            margin: 10px auto 0 auto;
            }

    /* ALERTE INFORMATION */

    .alerte-information{
    height: auto;
    background-color: white;
    width: 506px;
    position: fixed;
    margin-left: -269px;
    left: 50%;
    top: 50%;
    font-family: "roman";
    font-size: 12px;
    padding: 10px;
    overflow-y: hidden;
    z-index: 2;
    }

        .alerte-information > h3{
        font-family: 'Varela Round', sans-serif;
        font-size: 12px;
        float: left;
        background-color: #626262;
        padding: 5px;
        color: white;
        text-transform: uppercase;
        }


            .alerte-information-content.erreur{
            background-color: #E40D0D;
            }

            .alerte-information-content.succes{
            background-color: #006C1C;                
            }

            .alerte-information-content > span{
            max-width: 340px;
            font-size: 15px;
            text-align: center;
            display: block;
            margin: auto;
            text-shadow: 0px 0px 12px rgba(0, 0, 0, 0.4);
            color: white;
            }


    /* ALERTE NEWS ~ CONDITION */

    .alerte-news{
    height: auto;
    background-color: white;
    width: 506px;
    position: fixed;
    margin-left: -269px;
    left: 50%;
    top: 50%;
    font-family: "roman";
    font-size: 12px;
    padding: 16px;
    overflow-y: hidden;
    z-index: 2;
    }

        .alerte-news > h3{
        font-family: 'Varela Round', sans-serif;
        font-size: 12px;
        float: left;
        background-color: #626262;
        padding: 5px;
        color: white;
        text-transform: uppercase;
        }

            .alerte-news-texte{
            height: auto;
            width: auto;
            }

    /* BUTTON ALERTE */

    button.alerte{
    margin: 10px auto 0 auto; 
    width: 300px; 
    background-color: #3CA21E; 
    height:36px; 
    font-size:11px; 
    display:block;
    }

    /* SCROLL BAR */

    .mCSB_scrollTools .mCSB_draggerRail {
    width: 15px;
    height: 100%;
    margin: 0 auto;
    background-color: #E7E7E7;
    }

    .mCSB_scrollTools .mCSB_dragger {
    cursor: pointer;
    width: 100%;
    height: 30px;
    z-index: 1;
    }

    .mCSB_inside>.mCSB_container {
    margin-right: 30px;
    }

    .mCSB_scrollTools .mCSB_draggerContainer {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    height: auto;
    }

    .mCustomScrollBox {
    position: relative;
    overflow: hidden;
    height: 100%;
    max-width: 100%;
    outline: 0;
    direction: ltr;
    }

    .mCSB_scrollTools {
    position: absolute;
    width: 15px;
    height: auto;
    left: auto;
    top: 0;
    right: 0;
    bottom: 0;
    }

    .mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
    position: relative;
    width: 13px;
    height: 100%;
    margin: 0 auto;
    text-align: center;
    background-color: #CECFCE;
    }
	/*
 * CSS : Erreur
 * PARENT CSS : none
 * PARENT DIV : none
 */

body.erreur{
height: 100%;
width: 100%;
background: url(//i.imgur.com/VGDe9dy.png) repeat;
margin: auto;
font-family: "roman";
font-size: 11px;
position: absolute;
top: 0;
}

#page{
height: 435px;
width: 774px;
position: relative;
top: 50%;
background: url(//i.imgur.com/zcArr8e.png) no-repeat;
margin: -217px auto auto auto;
}

	.page-erreur{
	float: right;
	font-family: 'Varela Round', sans-serif;
	color: #343434;
	width: 492px;
	text-transform: uppercase;
	position: relative;
	top: 50%;
	margin-top: -44px;
	text-align: center;
	}

		.page-erreur > h3{
		font-size: 56px;
		}

		.page-erreur > span{
		font-size: 18px;
		display: block;
		}

		button.back{
		font-size: 11px;
		width: 320px;
		background-color: #3CA21E;
		height: 36px;
		margin: 20px auto 0 auto;
		}
		</style>
        
    </head>
   
    <body class="erreur">

        <div id="page">
            
            <div class="page-erreur">

                
                        <h3>Oups...</h3>
                        <span>Mauvaise frappe de ta part!</span></br>
                         <span>Tu vas être rédirigé dans 15 secondes...</span>
                       <?php header('Refresh: 15; URL=./');?>
						<button onclick="javascript:window.location.href='/me'; return false;" effect="press" class="back">Retourner sur <?php echo Settings('Name'); ?></button>
						
						
            </div>
            
        </div>

    </body>

</html>
