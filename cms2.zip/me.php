<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                D�veloppement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
include("./includes/files/register.php");
include("./includes/files/session.disconnect.php");
    
$pagename = "Accueil";
$pageid = "accueil";
 $menu_id="1"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo Settings('Name'); ?>: <?php echo $user['username']; ?></title>
    <link rel="stylesheet" type="text/css" href="gallery/css/global.css?1461255333">
    <link rel="stylesheet" type="text/css" href="gallery/css/me.css?1461255333">
    <link rel="shortcut icon" href="./favicon.ico">

    <meta name="twitter:title" content="Adov: Entre dans un h�tel o� tout est gratuit, fais-toi plein d'amis et deviens c�l�bre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens c�l�bre en s�journant GRATUITEMENT dans l'un des plus grand r�tro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="R�tro Habbo">
    <meta property="og:site_name" content="Habbo H�tel"/>
    <meta property="og:title" content="Habbo: Cr�e ton avatar, d�core ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens c�l�bre en s�journant GRATUITEMENT dans l'un des plus grand r�tro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens c�l�bre en s�journant GRATUITEMENT dans l'un des plus grand r�tro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, r�seau social, gratuit, communaut�e, avatar, chat, connect�e, adolescence, jeu de r�le, rejoindre, social, groupes, forums, s�curit�e, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, cr�er, connecter, meuble, mobilier, animaux, d�co, design, appart, d�corer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>
</head>
<body><?php include("./templates/header.php"); ?>
   
    <div id="content" class="page">
<div id="me">
            <div id="avatar">
                <img src="<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $user['look']; ?>);&amp;action=wav">
            </div>
            <div id="name-box" class="info-box">
                <div class="label">Pseudo:</div>
                <div class="content"><?PHP echo $user['username']; ?></div>
            </div>
            <div id="motto-box" class="info-box">
                <div class="label">Mission:</div>
                <div class="content"><?php echo utf8_encode(stripslashes($user['motto'])); ?></div>
            </div>
            <div id="last-logged-in-box" class="info-box">
                <div class="label">Derni&egrave;re connexion :</div>
                <div class="content"><?php echo $date." ".date('H:i:s', $usid['last_offline']); ?></div>
            </div>
            <div id="enter-hotel-btn">
                <a target="_blank" href="./client.php" class="btn">Entrer dans <?php echo Settings('Name'); ?> H&ocirc;tel</a>
            </div>
        </div>

        <div class="clear"></div>
            
<?php $news = mysql_query("SELECT * FROM retrophp_news LIMIT 1"); while($a = mysql_fetch_array($news)) { ?>
                   <div id="news" style="background-image: url(<?php echo $a['topstory_image']; ?>); background-position: 50% 50%;">
            <div id="column">
             <h1><?php echo $a['title']; ?></h1>
                <p>
                    <?php echo $a['snippet']; ?>
                </p>
            </div>
            <div id="bottom">
                <a href="<?php echo Settings('Url'); ?>/articles/<?php echo $a['id_page']; ?>" class="btn"><?php echo $a['mini_text']; ?></a>
            </div>
        </div>

<?php } ?>
                <br>
        <div id="box" style="width: 399px;">
            <div class="titre" style="background-color:#2195C4;">R&eacute;seaux Sociaux</div><br>
            <center>
<script>(function(d, s, id) {
              var js, fjs = d.getElementsByTagName(s)[0];
              if (d.getElementById(id)) return;
              js = d.createElement(s); js.id = id;
              js.src = "//connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v2.3";
              fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-page" data-href="https://www.facebook.com/<?php echo Settings('Facebook'); ?>" data-width="389" data-height="310" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/<?php echo Settings('Facebook'); ?>"><a href="https://www.facebook.com/<?php echo Settings('Facebook'); ?>"><?php echo Settings('Name'); ?></a></blockquote></div></div>
    <div class="clear"></div></center></div>
<?php include("./templates/footer.php"); ?>
    </div>
</body>
</html>