<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/session.disconnect.php");

if($rtp_user['facebook'] >= 1) {
Redirect("".Settings('Url')."/identity/settings");
}
    
if($rtp_user['mail_verified'] == 0) {
$mail = Securise($_GET['email']);

$query = mysql_query("SELECT * FROM users WHERE mail = '".$mail."'");
$email = mysql_fetch_assoc($query);

if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn|outlook|gmail).[a-z]{2,4}$#", $mail)) // On filtre les serveurs qui rencontrent des bogues.
{
$passage_ligne = "\r\n";
}
else
{
$passage_ligne = "\n";
}


//=====Dï¿ 1/2 claration des messages au format texte et au format HTML.
$affichage_txt = "Bienvenue sur ".Settings('Name')."";
$affichage_html = "<div id=\":b3\" class=\"ii gt m146ca299d0080ed7 adP adO\"><div id=\":b4\" class=\"a3s\" style=\"overflow: hidden;\"><u></u>

<div>

<table width=\"98%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
    <tbody><tr>
        <td align=\"center\">

            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"595\">
                <tbody><tr>
                    <td align=\"left\" style=\"border-bottom:1px solid #aaaaaa\" height=\"70\" valign=\"middle\">
                        <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
                            <tbody><tr>
                                <td>
                                    <img src=\"".Settings('Url')."/images/".Settings('Logo')."\" alt=\"".$mail."\" style=\"margin-left:12px;display:block\">
                                </td>
                            </tr>

                        </tbody></table>
                    </td>
                </tr>


<tr>
    <td align=\"left\" style=\"border-bottom:1px dashed #aaaaaa\" valign=\"middle\">
        <table style=\"margin-left:12px;margin-right:12px;padding:0 0 10px 0;width:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
            <tbody><tr>
                <td valign=\"top\">

                                    <p style=\"font-family:Verdana,Arial,sans-serif;font-size:20px;padding-top:15px\">
                                        Salut <b><span style=\"font-weight:bold\">".$mail."</span></b>
                                    </p>
                                    <p style=\"font-family:Verdana,Arial,sans-serif;font-size:12px;padding-bottom:5px\">
                                        Merci d'avoir rejoint la communaut&eacute; <b><span style=\"font-weight:bold\">".Settings('Name')."</span></b>!
                                        <br><br>
                                        Voici un <a style=\"color:#007df2\" href=\"#\" target=\"_blank\">Cadeau de bienvenue</a> tr&egrave;s sp&eacute;cial pour toi.
                                    </p>
                                    <p style=\"font-family:Verdana,Arial,sans-serif;font-size:12px;font-style:italic;padding-top:5px;padding-bottom:5px\">
                                        <em>A tr&egrave;s bient&ocirc;t!</em>
                                    </p>
                                    <p style=\"font-family:Verdana,Arial,sans-serif;font-size:12px;font-style:italic;padding-top:5px;padding-bottom:5px\">
                                        <em>
                                            <a href=\"".Settings('Url')."\" style=\"color:#007df2\" target=\"_blank\">A bient&ocirc;t</a>
                                            <br>".Settings('Name')."
                                        </em>
                                    </p>
</td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
    <td align=\"left\" style=\"border-bottom:1px solid #aaaaaa\" height=\"100\" valign=\"middle\">
        <table style=\"margin-left:12px\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
            <tbody><tr>
                <td valign=\"middle\">
                    <table style=\"background-color:#51b708;height:50px\" height=\"50px;\" cellpadding=\"0\" cellspacing=\"0\">
                        <tbody><tr>
                            <td style=\"height:100%;vertical-align:middle;border:solid 2px #000000\" valign=\"middle\">
                                <p style=\"font-family:Verdana,Arial,sans-serif;font-weight:bold;font-size:18px;color:#ffffff;margin-top:0;margin-bottom:0\">
                                               <a style=\"text-decoration:none;padding:15px 20px;color:#ffffff\" href=\"".Settings('Url')."/identity/validate?ukey=".$rtp_user['user_key']."\" target=\"_blank\">
                                                        Activer mon compte
                                                    </a>
</p>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
    <td valign=\"top\" align=\"center\">
        <table style=\"font-family:Verdana,Arial,sans-serif;text-align:justify;font-size:11px;color:#aaaaaa;padding-top:10px;padding-right:10px;padding-left:10px;padding-bottom:10px;margin-top:0pt;margin-right:0pt;margin-left:0pt;margin-bottom:0pt\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"595\">
            <tbody><tr>
                <td style=\"height:8px\"></td>
            </tr>
            
        </tbody></table>
    </td>
</tr>
</tbody></table>

</td>
</tr>
</tbody></table>

</div></div></div></div>";
//==========


//=====Crï¿ 1/2 ation de la boundary
$boundary = "-----=".md5(rand());
//==========


//=====Dï¿ 1/2 finition du sujet.
$sujet = "Bienvenue sur ".Settings('Name')."";
//=========


//=====Crï¿ 1/2 ation du header de l'e-mail.
$header = "From: \"".Settings('Name')." FR\"<auto-contact@".Settings('Court_Url').">".$passage_ligne;
$header.= "Reply-to: \"".Settings('Name')." FR\" <".$mail.">".$passage_ligne;
$header.= "MIME-Version: 1.0".$passage_ligne;
$header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"$boundary\"".$passage_ligne;
//==========


//=====Crï¿ 1/2 ation du message.
$affichage = $passage_ligne."--".$boundary.$passage_ligne;
//=====Ajout du message au format texte.
$affichage.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$passage_ligne;
$affichage.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
$affichage.= $passage_ligne.$affichage_txt.$passage_ligne;
//==========
$affichage.= $passage_ligne."--".$boundary.$passage_ligne;
//=====Ajout du message au format HTML
$affichage.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
$affichage.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
$affichage.= $passage_ligne.$affichage_html.$passage_ligne;
//==========
$affichage.= $passage_ligne."--".$boundary."--".$passage_ligne;
$affichage.= $passage_ligne."--".$boundary."--".$passage_ligne;
//==========


//=====Envoi de l'e-mail.
mail($mail,$sujet,$affichage,$header);
//==========

$do2 = $_GET['emailChanged'];
if($do2 == "true") {
Redirect("".Settings('Url')."/identity/email?emailChanged=true");
}

if($rtp_user['mail_verified'] == 1) {
Redirect("".Settings('Url')."/identity/email");
}

$do2 = $_GET['emailChanged'];
if($do2 == "false") {
Redirect("".Settings('Url')."/identity/email?accountActivationEmailResent=true");
}

$do2 = $_GET['emailRegister'];
if($do2 == "true") {
Redirect("".Settings('Url')."/client");
}
}
?>