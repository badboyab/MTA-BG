<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/session.disconnect.php");

if($rtp_user['facebook'] >= 1) {
Redirect("".Settings('Url')."/identity/settings");
}

$do2 = $_GET['emailChanged'];
if($do2 == "true") {
Redirect("".Settings('Url')."/identity/verified?email=".$user['mail']."&&emailChanged=true");
}

$do2 = $_GET['emailChanged'];
if($do2 == "false") {
Redirect("".Settings('Url')."/identity/verified?email=".$user['mail']."&&emailChanged=false");
}

$do2 = $_GET['emailRegister'];
if($do2 == "true") {
Redirect("".Settings('Url')."/identity/verified?email=".$user['mail']."&&emailRegister=true");
}
?>