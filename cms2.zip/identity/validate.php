<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/register.php");
include("../includes/files/session.disconnect.php");

if($rtp_user['facebook'] >= 1) {
Redirect("".Settings('Url')."/identity/settings");
}

$key = Securise($_GET['ukey']);
$query = mysql_query("SELECT * FROM retrophp_users WHERE user_key = '".$key."'");
$ukey = mysql_fetch_assoc($query);
mysql_query("UPDATE retrophp_users SET mail_verified=1 WHERE user_key = '".$key."'");
mysql_query("INSERT INTO `user_achievement` (`userid`, `group`, `level`, `progress`) VALUES ('".$ukey["id"]."', 'ACH_EmailVerification', '1', '0')");
mysql_query("INSERT INTO `user_badges` (`user_id`, `badge_id`) VALUES ('".$ukey["id"]."', 'ACH_EmailVerification')");
mysql_query("UPDATE retrophp_users SET user_key = '".$generate_key."' WHERE user_key = '".$key."'");
Redirect("".Settings('Url')."/identity/activate");
?>