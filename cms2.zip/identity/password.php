<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/register.php");
include("../includes/files/session.disconnect.php");

if($rtp_user['facebook'] >= 1) {
Redirect("".Settings('Url')."/identity/settings");
}

if(isset($_POST['currentPassword']) && isset($_POST['newPassword']) && isset($_POST['retypedNewPassword']))
{
$mdpactuel = Securise($_POST['currentPassword']);
$mdpnew = Securise($_POST['newPassword']);
$mdpnewre = Securise($_POST['retypedNewPassword']);
$mdp5actuel = Hashage($mdpactuel);
$md5 = Hashage($mdpnew);
if($mdp5actuel == $user['password']){
if($mdpnew == $mdpnewre){
if(strlen($mdpnew) < 6){
$result = "<div class=\"error-messages-holder\"><h3>Tu dois d'abord régler le problème suivant avant de pouvoir continuer.</h3><ul><li><p class=\"error-message\">Ton mot de passe est trop court !</p></li></ul></div>";
}  else {
if(strlen($mdpnew) > 25){
$result = "<div class=\"error-messages-holder\"><h3>Tu dois d'abord régler le problème suivant avant de pouvoir continuer.</h3><ul><li><p class=\"error-message\">Ton mot de passe est trop long !</p></li></ul></div>";
} else {
mysql_query("UPDATE users SET password = '".$md5."' WHERE username = '".$user['username']."' and password = '".$mdp5actuel."'") or die(mysql_error());
Redirect("".Settings('Url')."/identity/settings?passwordChanged=true");
}
}
} else {
$result = "<div class=\"error-messages-holder\"><h3>Tu dois d'abord régler le problème suivant avant de pouvoir continuer.</h3><ul><li><p class=\"error-message\">Les mots de passe ne correspondent pas.</p></li></ul></div>";
}
} else {
$result = "<div class=\"error-messages-holder\"><h3>Tu dois d'abord régler le problème suivant avant de pouvoir continuer.</h3><ul><li><p class=\"error-message\">Le mot de passe actuel n'est pas celui-ci.</p></li></ul></div>";
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title><?php echo Settings('Name'); ?>: Préférences </title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<link rel="shortcut icon" href="<?php echo Settings('Url_Images'); ?>/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/embed.css?<?php echo $update; ?>" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>/static/js/embed.js?<?php echo $update; ?>" type="text/javascript"></script>
<link media="only screen and (max-device-width: 480px)" href="<?php echo Settings('Url_Images'); ?>/styles/small-device.css?<?php echo $update; ?>" type= "text/css" rel="stylesheet">

<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/common.css?<?php echo $update; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/embeddedregistration.css?<?php echo $update; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/identitysettings.css?<?php echo $update; ?>" type="text/css" />

<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>


<?php include("../templates/meta.php"); ?>

</head>

<body id="embedpage">
<div id="overlay"></div>

<div id="container">

    <div class="settings-container clearfix">
        <h1>Préférences</h1>
            <div id="back-link">
                <a href="<?php echo Settings('Url'); ?>/identity/avatars">Mes personnages</a> &raquo; <a href="<?php echo Settings('Url'); ?>/identity/settings"> Préférences</a> &raquo; Changer de mot de passe
            </div>        
        <div style="padding: 0 10px">
<?php if(isset($result)) { echo $result; } ?>

         <form id="change-password" method="post" action="">
            <input type="hidden" name="fromClient" value="false" />
            <div class="field field-currentpassword">
              <label for="current-password">Mot de passe actuel</label>
              <input type="password" id="current-password" size="35" name="currentPassword" value="" class="password-field" maxlength="32"/>
              <p class="help">Au moins 6 caractères, chiffres et lettres</p>
            </div>

            <div class="form-box">
            <div class="field field-password">
              <label for="password">Nouveau mot de passe</label>
              <input type="password" id="password" size="35" name="newPassword" value="" class="password-field" maxlength="32"/>
            </div>

            <div class="field field-password2">
              <label for="password2">Nouveau mot de passe (Encore)</label>
              <input type="password" id="password2" size="35" name="retypedNewPassword" value="" class="password-field" maxlength="32"/>
              <p class="help">Choisis un mot de passe d'au moins 6 caractères comprenant des lettres et d'autres caractères.</p>
            </div>
            </div>

            <div style="overflow: hidden">
                <a href="#" class="new-button password-button" id="next-btn" onclick="$(this).up('form').submit(); return false;"><b>Changer</b><i></i></a>
            </div>
         </form>
        </div>
    </div>
    <div class="settings-container-bottom"></div>
<!-- FOOTER -->
<?php include("../templates/footer.php"); ?>
<!-- FIN FOOTER -->
</div></div>

<script type="text/javascript">
if (typeof HabboView != "undefined") {
    HabboView.run();
}
</script>

</body>
</html>