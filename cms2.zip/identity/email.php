<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/register.php");
include("../includes/files/session.disconnect.php");

if($rtp_user['facebook'] >= '1') {
Redirect("".Settings('Url')."/identity/settings");
}

if(isset($_POST['email']))
{
$email = Securise($_POST['email']);
$email_check = preg_match("/^[a-z0-9_\.-]+@([a-z0-9]+([\-]+[a-z0-9]+)*\.)+[a-z]{2,7}$/i", $email);
$tmp2 = mysql_query("SELECT id FROM users WHERE mail = '".$email."' LIMIT 1") or die(mysql_error());
$tmp2 = mysql_num_rows($tmp2);
if(isset($email)) {
$failure = false;
if(strlen($email) < 6){
$message4['email'] = "Merci d'entrer une email valide.";
$failure = true;
} elseif($email_check !== 1){
$message4['email'] = "Merci d'entrer une email valide.";
$failure = true;
}
elseif($tmp2 > 0){
$message4['email'] = "Cette adresse email existe déjà.";
$failure = true; 
}
if($failure == false){
mysql_query("UPDATE users SET `mail` = '".$email."' WHERE `id` =".$user['id'].";") or die(mysql_error());
mysql_query("UPDATE retrophp_users SET `mail_verified` = '0' WHERE `uid` = '".$user['id']."'") or die(mysql_error());
Redirect("".Settings('Url')."/identity/envoie?emailChanged=true");
exit();
}
} 
}
$do = Securise($_GET['emailChanged']);
if($do == "true")
{ 
$message = '<p class="confirmation" style="margin-top:10px">Un e-mail de de confirmation vient de t\'être envoyé. Tu dois d\'abord activer ton adresse e-mail avant que les changements ne soient appliqués.</p>';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title><?php echo Settings('Name'); ?>: Préférences emails </title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<link rel="shortcut icon" href="<?php echo Settings('Url_Images'); ?>/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/embed.css?<?php echo $update; ?>" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>/static/js/embed.js?<?php echo $update; ?>" type="text/javascript"></script>
<link media="only screen and (max-device-width: 480px)" href="<?php echo Settings('Url_Images'); ?>/styles/small-device.css?<?php echo $update; ?>" type= "text/css" rel="stylesheet">

<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/common.css?<?php echo $update; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/embeddedregistration.css?<?php echo $update; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/identitysettings.css?<?php echo $update; ?>" type="text/css" />

<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>


<?php include("../templates/meta.php"); ?>

</head>

<body id="embedpage">
<div id="overlay"></div>

<div id="container">

    <div class="settings-container clearfix">
        <h1>Préférences emails</h1>
        <div id="back-link">
            <a href="<?php echo Settings('Url'); ?>/identity/avatars">Mes personnages</a> &raquo; <a href="<?php echo Settings('Url'); ?>/identity/settings"> Préférences</a> &raquo; Préférences emails
        </div>
        <div style="padding: 10px 10px 0 10px">
             <?php if($message == true) { ?>
 <?php echo $message; ?>
 <?php } ?>
<?php if(isset($message4)) { ?>
    <div class="error-messages-holder">
                <h3>Désolé un problème est survenu.</h3>
                <ul>
                    <li><p class="error-message"><?php if(isset($message4['email'])) { echo "".$message4['email'].""; } ?></p></li>
                </ul>
            </div>
    <?php } ?>
            <?php $do2 = $_GET['accountActivationEmailResent']; ?>
<?php if($do2 == "true") { ?>                  
<p class="confirmation" style="margin-top:10px">Un email d'activation t'as été envoyé! Vérifie dans ta boîte email.
Si tu ne le vois pas, vérifie dans tes courriers indésirables et appuies bien sur le bouton 'Ceci n'est pas du spam'</p>
<?php } ?>

            <p>Rappelle-toi que tu ne peux plus ajouter d'adresses additionnelles. Mais tu peux modifier ton adresse principale. Avant que les changements ne soient appliqués, tu dois activer ton adresse e-mail.</p>
            <h3>Adresse principale</h3>
            <div class="primary-email">
                    <?php echo $user['mail']; ?>
                    <?php $sql = mysql_query("SELECT * FROM retrophp_users WHERE mail_verified = 0 AND uid = '".$user['id']."'"); while($s = mysql_fetch_array($sql)) { ?>
                <br clear="all"/>
                        <a id="resend-activation"
                           href="<?php echo Settings('Url'); ?>/identity/envoie?emailChanged=false"
                           class="new-button left"><b>Renvoyer l'email d'activation</b><i></i></a>
                           <?php } ?>
                        
                        <br clear="all"/>
            </div>
            <h3>Adresses additionelles</h3>
                Tu n'as pas d'adresses e-mail additionnelles.
            <div class="form-box" style="margin-top: 10px">
<form action="" method="post" id="new-email-form" autocomplete="off">
                <div class="field">
                    <label for="newEmailAddress" style="width: auto">Entre une nouvelle adresse e-mail.</label>
                    <input type="text" id="newEmailAddress" name="email" value="" class="text-field"><br><br>
                    <a href="#" class="new-button" id="next-btn" style="display:block;margin-top:0px;margin-left:-0px;" onclick="$(this).up('form').submit(); return false;" value="Modifie ton adresse e-mail"><b>Modifie ton adresse e-mail</b><i></i></a>
               <br>
                </div>
</form>
            </div>


        </div>
    </div>
    <div class="settings-container-bottom"></div>


<!-- FOOTER -->
<?php include("../templates/footer.php"); ?>
<!-- FIN FOOTER -->
</div></div>

<script type="text/javascript">
if (typeof HabboView != "undefined") {
    HabboView.run();
}
</script>

</body>
</html>
