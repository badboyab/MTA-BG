<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/register.php");
include("../includes/files/session.disconnect.php");

$av = mysql_query("SELECT * FROM users WHERE mail = '".$user['mail']."' AND id = '".$user['hote_id']."' or mail = '".$user['mail']."' AND hote_id = '0'");
$avatars = mysql_fetch_assoc($av);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title><?php echo Settings('Name'); ?>: Choisis un personnage </title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<link rel="shortcut icon" href="<?php echo Settings('Url_Images'); ?>/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/embed.css?<?php echo $update; ?>" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>/static/js/embed.js?<?php echo $update; ?>" type="text/javascript"></script>
<link media="only screen and (max-device-width: 480px)" href="<?php echo Settings('Url_Images'); ?>/styles/small-device.css?<?php echo $update; ?>" type= "text/css" rel="stylesheet">

<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/common.css?<?php echo $update; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/avatarselection.css?<?php echo $update; ?>" type="text/css" />

<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>


<?php include("../templates/meta.php"); ?>

</head>

<body id="embedpage">
<div id="overlay"></div>

<div id="container">

    <div id="select-avatar">
    <div class="pick-avatar-container clearfix">
        <div class="title">
            <span class="habblet-close"></span>
            <h1>Choisis ton perso</h1>
        </div>
        <div id="content">
            <div id="user-info">
                  <img src="https://ssl.facebook.com/pics/q_silhouette.gif"/>
              <div>
                  <div id="name"><?php echo $user['username']; ?></div>
                  <a href="<?php echo Settings('Url'); ?>/me" id="logout">Retour à l'hôtel</a>
                  <a href="<?php echo Settings('Url'); ?>/identity/settings" id="manage-account">Préférences</a>
              </div>

            </div>
            <div id="first-avatar">
                    <img src="<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $user['look']; ?>&action=&direction=3&head_direction=3" width="64" height="110"/>
                    <div id="first-avatar-info">
                        <div class="first-avatar-name"><?php echo $user['username']; ?></div>
                        <div class="first-avatar-lastonline">Dernière connexion: <br/> <span title="<?php echo $date." ".date('H:i:s', $user['last_offline']); ?>"><?php echo $date." ".date('H:i:s', $user['last_offline']); ?></span></div>
                        <a id="first-avatar-play-link" href="<?php echo Settings('Url'); ?>/me">
                            <div class="play-button-container">
                                <div class="play-button"><div class="play-text">Jouer</div></div>
                                <div class="play-button-end"></div>
                            </div>
                        </a>
                    </div>
            </div>

<br/>       <?php if($rtp_user['mail_verified'] == 0) { ?>
            <div id="disabled-link-new-avatar"><a class="new-button disabled-button" onclick="return false;" href=""><b>+ Ajouter</b><i></i></a></div>
            <?php } if($rtp_user['mail_verified'] == 1) { ?>
            <div id="link-new-avatar"><a class="new-button" onclick="" href="<?php echo Settings('Url'); ?>/identity/add_avatar"><b>+ Ajouter</b><i></i></a></div>
            <?php } ?>
<?php $sql = mysql_query("SELECT * FROM retrophp_users WHERE facebook_id = '' AND mail_verified=0 AND uid=".$user['id'].""); while($s = mysql_fetch_array($sql)) { ?>
<p style="margin: 5px 10px"><a href="<?php echo Settings('Url'); ?>/identity/email">Merci de vérifier ton adresse e-mail pour ajouter un nouveau personnage.</a></p>
   <?php } ?>
                <?php $sql = mysql_query("SELECT * FROM retrophp_users WHERE facebook_id = '' AND mail_verified=1 AND uid=".$user['id'].""); while($s = mysql_fetch_array($sql)) { ?>
               <p style="margin: 5px 10px">Tu peux ajouter <?php echo $avatars['avatars']; ?> avatars</p>
               <?php } ?>
            <div class="other-avatars">

                  <?php $sql = mysql_query("SELECT * FROM users WHERE id != ".$user['id']." AND mail = '".$user['mail']."'"); while($us = mysql_fetch_array($sql)) { ?>

                  <ul>
                    <li class="">
                      <img src="<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $us['look']; ?>&action=&direction=4&head_direction=&gesture=&size=s" width="33" height="56"/>
                      <div class="avatar-info">
                        <div class="avatar-info-container">
                          <div class="avatar-name"><?php echo $us['username']; ?></div>
                          <div class="avatar-lastonline">Dernière connexion: <span title="<?php echo $date." ".date('H:i:s', $us['last_offline']); ?>"><br/><?php echo $date." ".date('H:i:s', $us['last_offline']); ?></span></div>
                        </div>
                          <div class="avatar-select"><a href="<?php echo Settings('Url'); ?>/identity/useOrCreateAvatar/<?php echo $us['id']; ?>?disableFriendLinking=true"><b>Jouer</b><i></i></a></div>
                      </div>
                    </li>
                  </ul>
                  <?php } ?>


            </div>
        </div>
    </div>
    <div class="pick-avatar-container-bottom"></div>
  </div>

<!-- FOOTER -->
<?php include("../templates/footer.php"); ?>
<!-- FIN FOOTER -->
</div></div>

<script type="text/javascript">
if (typeof HabboView != "undefined") {
    HabboView.run();
}
</script>

</body>
</html>
