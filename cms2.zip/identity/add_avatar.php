<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/register.php");
include("../includes/files/session.disconnect.php");

if(isset($_POST['pseudo']))
{
$name = Securise($_POST['pseudo']);
$filter = preg_replace("/[^a-z\d'\-=\?!@:\.]/i", "", $name);
$tmp = mysql_query("SELECT id FROM users WHERE username = '".$name."' LIMIT 1") or die(mysql_error());
$tmp = mysql_num_rows($tmp);
if(isset($name)) {
$failure = false;
if(strlen($name) < 3){
$message1['name'] = "Votre pseudo est trop court.";
$failure = true;
}
if($tmp > 0){
$message1['name'] = "Votre Pseudo est déjà utilisé.";
$failure = true;
} elseif($filter !== $name){
$message1['name'] = "Votre Pseudo contient des carractères non-autorisé.";
$failure = true;
} elseif(strlen($name) > 24){
$message1['name'] = "Votre Pseudo est trop long.";
$failure = true;
} elseif(strlen($name) < 1){
$message1['name'] = "Merci d'entrer un Pseudo.";
$failure = true;
}
      
if($failure == false){
$message = "Nom <strong>".$name."</strong> disponible.";

if($user['gender'] == 'M') { 
mysql_query("INSERT INTO users (username,look,mail,auth_ticket,rank,ip_reg,motto,credits,activity_points,last_offline,account_created,hote_id) VALUES ('".$name."','".Settings('Look_Boy')."','".$user['mail']."','','".Settings('Rank')."','".$ip."','".Settings('Mission')."','".Settings('Credits')."','".Settings('Pixels')."','".time()."','".time()."','".$user['id']."')") or die(mysql_error());
}

if($user['gender'] == 'F') { 
mysql_query("INSERT INTO users (username,look,mail,auth_ticket,rank,ip_reg,motto,credits,activity_points,last_offline,account_created,hote_id) VALUES ('".$name."','".Settings('Look_Girl')."','".$user['mail']."','','".Settings('Rank')."','".$ip."','".Settings('Mission')."','".Settings('Credits')."','".Settings('Pixels')."','".time()."','".time()."','".$user['id']."')") or die(mysql_error());
}

if($user['hote_id'] == 0) { 
mysql_query("UPDATE `users` SET `avatars` = `avatars` - '1' WHERE `mail` = '".$user['mail']."' AND `hote_id` = '0'");
} else {
mysql_query("UPDATE `users` SET `avatars` = `avatars` - '1' WHERE `mail` = '".$user['mail']."' AND `id` = '".$user['hote_id']."'");
}
Redirect("".Settings('Url')."/identity/avatars");
}
} 
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title><?php echo Settings('Name'); ?>: Ajouter un nouvel avatar </title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<link rel="shortcut icon" href="<?php echo Settings('Url_Images'); ?>/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/embed.css?<?php echo $update; ?>" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>/static/js/embed.js?<?php echo $update; ?>" type="text/javascript"></script>
<link media="only screen and (max-device-width: 480px)" href="<?php echo Settings('Url_Images'); ?>/styles/small-device.css?<?php echo $update; ?>" type= "text/css" rel="stylesheet">

<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/common.css?<?php echo $update; ?>" type="text/css" />

<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/avatarselection.css?<?php echo $update; ?>" type="text/css" />

<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>


<?php include("../templates/meta.php"); ?>

</head>

<body id="embedpage">
<div id="overlay"></div>

<div id="container">


  <div id="add-avatar">
    <div class="add-avatar-container clearfix">
        <div class="title">
          <span class="habblet-close"></span>
          <h1>Ajouter un nouvel avatar</h1>
        </div>
        <div id="content">
            <a id="back-link" href="<?php echo Settings('Url'); ?>/identity/avatars">&laquo; Retour aux avatars</a>
            <form id="add-avatar-form" method="post" action="">

            <input type="hidden" name="__app_key" value="d4059c7f20" />

            <div id="error-messages-container" style="margin-top: 10px">
            </div>
<?php if(isset($message1)) { ?>
<div id="error-messages-container" style="margin-top: 10px">
            <div class="error-messages-holder">
                <h3>Tu dois d'abord régler le problème suivant avant de pouvoir continuer.</h3>
                <ul>
                    <li><p class="error-message">
<?php if(isset($message1['name'])) { echo "".$message1['name'].""; } ?>
</p></li>
                </ul>
            </div></div>
<?php } ?> 
            <div id="name-field-container">
                <div class="field field-habbo-name">
                  <label for="habbo-name">Nom du personnage</label>
                  <a href="#" class="new-button" id="check-name-btn"><b>Vérifier</b><i></i></a>
                  <input type="text" id="habbo-name" size="32" value="<?php echo $name; ?>" name="pseudo" class="text-field" maxlength="32"/>
<?php if(isset($message)) { echo "<div id=\"name-suggestions\"><div class=\"available\">".$message."</div></div>"; } ?> 
                  <p class="help">Ton nom peut contenir des minuscules, des majuscules, des chiffres et les caractères suivants _-=?!@:.,</p>
                </div>
            </div>
            <a href="#" class="new-button" id="next-btn" onclick="$(this).up('form').submit(); return false;"><b>Créer un avatar</b><i></i></a>
        </form>
        </div>
    </div>
    <div class="add-avatar-container-bottom"></div>
  </div>
</div>
<!-- FOOTER -->
<?php include("../templates/footer.php"); ?>
<!-- FIN FOOTER -->

<script type="text/javascript">
if (typeof HabboView != "undefined") {
    HabboView.run();
}
</script>

</body>
</html>
