<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/register.php");
include("../includes/files/session.disconnect.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title><?php echo Settings('Name'); ?>: Préférences </title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<link rel="shortcut icon" href="<?php echo Settings('Url_Images'); ?>/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/embed.css?<?php echo $update; ?>" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>/static/js/embed.js?<?php echo $update; ?>" type="text/javascript"></script>
<link media="only screen and (max-device-width: 480px)" href="<?php echo Settings('Url_Images'); ?>/styles/small-device.css?<?php echo $update; ?>" type= "text/css" rel="stylesheet">

<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/common.css?<?php echo $update; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/embeddedregistration.css?<?php echo $update; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/identitysettings.css?<?php echo $update; ?>" type="text/css" />

<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>


<?php include("../templates/meta.php"); ?>

<!--[if IE 8]>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/ie8.css" type="text/css" />
<![endif]-->
<!--[if lt IE 8]>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/ie.css" type="text/css" />
<![endif]-->
<!--[if lt IE 7]>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/ie6.css" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>/static/js/pngfix.js" type="text/javascript"></script>
<script type="text/javascript">
try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
</script>

<style type="text/css">
body { behavior: url(/js/csshover.htc); }
</style>
<![endif]-->
</head>

<body id="embedpage">
<div id="overlay"></div>

<div id="container">

    <div class="settings-container clearfix">
        <h1>Préférences</h1>
        <div id="back-link">
        <a href="<?php echo Settings('Url'); ?>/identity/avatars">Mes personnages</a> &raquo; Préférences      
        </div>
        
        <div style="padding: 0 10px">

        <h3>Email:</h3>
        <?php $sql = mysql_query("SELECT * FROM retrophp_users WHERE facebook_id = '' AND uid = '".$user['id']."'");
while($s = mysql_fetch_array($sql)) { ?>
<div class="opt-email">
            <span><?php echo $user['mail']; ?></span>
            <a id="manage-email" class="new-button " href="<?php echo Settings('Url'); ?>/identity/email"><b>Préférences email</b><i></i></a>
        </div>
           <?php } ?>

    <?php $sql = mysql_query("SELECT * FROM retrophp_users WHERE facebook = '1' AND uid = '".$user['id']."'");
while($s = mysql_fetch_array($sql)) { ?>
stockage de l'adresse e-mail n'est pas pris en charge pour votre compte à l'heure actuelle.
<? } ?>
       
        <br clear="all"/>

        <?php $sql = mysql_query("SELECT * FROM retrophp_users WHERE facebook_id = '' AND uid = '".$user['id']."'");
while($s = mysql_fetch_array($sql)) { ?>
<h3>Gestion des modes d'accès</h3>
        <p>Voici une liste des services web que tu utilises pour te connecter</p>
        <div class="opt-auth-providers clearfix settings-auth" style="float: none; width: auto">        
                <p>
                    <img src="<?php echo Settings('Url_Images'); ?>/v2/images/rpx/icon_habbo_big.png" style="vertical-align: middle" title="habbo"/>
                    <?php echo $user['mail']; ?>
                </p>
        <p>
        </p>
        </div>
        <a id="manage-auth-providers" class="new-button " onclick="" href="#"><b>Modifier les préférences</b><i></i></a>
   <? } ?>


          <?php $sql = mysql_query("SELECT * FROM retrophp_users WHERE facebook = '1' AND uid = '".$user['id']."'");
while($s = mysql_fetch_array($sql)) { ?>
<h3><font><font class="">Se connecter avec:</font></font></h3>
    <p><font><font>Voici une liste de services Web que vous utilisez pour vous connecter</font></font></p>
    <div class="opt-auth-providers clearfix settings-auth" style="float: none; width: auto">        
                <p>
                    <img src="<?php echo Settings('Url_Images'); ?>/v2/images/rpx/icon_facebook_big.png?1" style="vertical-align: middle" title="facebook"><font><font class="">
                    <?php echo $user['username']; ?>
                     </font>
                </p>
        <p>
        </p>
        </div>
        <a id="manage-auth-providers" class="new-button " href="#"><b><font><font class="">Gérer les options</font></font></b><i></i></a>
<?php } ?>  
       
        <br clear="all"/>
                
        <h3>Mot de passe:</h3>
<?php $do2 = $_GET['passwordChanged']; ?>
<?php if($do2 == "true") { ?>                  
<p class="confirmation">Tu as modifié ton mot de passe avec succès</p>
<?php } ?>
<div class="opt-password">
<?php $sql = mysql_query("SELECT * FROM retrophp_users WHERE facebook_id = '' AND uid = '".$user['id']."'");
while($s = mysql_fetch_array($sql)) { ?>
<span>**************</span>
            <a id="manage-password" class="new-button" href="<?php echo Settings('Url'); ?>/identity/password"><b>Changer</b><i></i></a>
<?php } ?>

    <?php $sql = mysql_query("SELECT * FROM retrophp_users WHERE facebook = '1' AND uid = '".$user['id']."'");
while($s = mysql_fetch_array($sql)) { ?>
<span><a href="#"><font><font class="">Mettre en place un compte</font></font></a></span>
<?php } ?>
</div>
        
        <div class="opt-email">

        </div>
        </div>
    </div>
    <div class="settings-container-bottom">
  </div>

<?php include("../templates/footer.php"); ?>

</div></div>
</body>
</html>
