<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/register.php");
include("../includes/files/session.disconnect.php");
    
if(isset($_GET['id'])) {
$query = Securise($_GET['id']);
$sql = mysql_query("SELECT * FROM users WHERE id = '".$query."'");
$row = mysql_num_rows($sql);
if($row < 1) { 
echo "Error";
} else {
$us1 = mysql_query("SELECT * FROM users WHERE id = '".$query."'");
$uss1 = mysql_fetch_assoc($us1);
$sql = mysql_query("SELECT * FROM users WHERE mail = '".$user['mail']."' AND hote_id = '".$user['id']."'");
mysql_query("UPDATE users SET last_offline = '".time()."' WHERE id = '".$user['id']."'");
while($us = mysql_fetch_array($sql)) {
session_start();
$_SESSION['username'] = $uss1['username'];
Redirect("".Settings('Url')."/me");
}
$sql = mysql_query("SELECT * FROM users WHERE mail = '".$user['mail']."' AND id = '".$user['hote_id']."'");
while($us = mysql_fetch_array($sql)) {
session_start();
$_SESSION['username'] = $uss1['username'];
Redirect("".Settings('Url')."/me");
}
}
}
Redirect("".Settings('Url')."/me");
?>
