<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/register.php");
include("../includes/files/session.disconnect.php");

if($rtp_user['facebook'] >= 1) {
Redirect("".$url."/identity/settings");
}

if($rtp_user['mail_verified'] == 0) {
Redirect("".$url."/identity/settings");
}

if(isset($_POST['directEmailAllowed']))
{
$directEmailAllowed = Securise($_POST['directEmailAllowed']);
if($directEmailAllowed != "") {
if(is_numeric($directEmailAllowed)) {
mysql_query("UPDATE retrophp_users SET newsletter = '".$directEmailAllowed."' WHERE uid = '".$user['id']."'");
Redirect("".Settings('Url')."/identity/activate");
} else {
}
} else {
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title><?php echo Settings('Name'); ?>: Active ton compte </title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<link rel="shortcut icon" href="<?php echo Settings('Url_Images'); ?>/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/embed.css?<?php echo $update; ?>" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>/static/js/embed.js?<?php echo $update; ?>" type="text/javascript"></script>
<link media="only screen and (max-device-width: 480px)" href="<?php echo Settings('Url_Images'); ?>/styles/small-device.css?<?php echo $update; ?>" type= "text/css" rel="stylesheet">

<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/common.css?<?php echo $update; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/embeddedregistration.css?<?php echo $update; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/identitysettings.css?<?php echo $update; ?>" type="text/css" />

<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>


<?php include("../templates/meta.php"); ?>

</head>

<body id="embedpage">
<div id="overlay"></div>

<div id="container">

    <div class="activateemail-container clearfix">
        <h1 style="margin-bottom: 0">Active ton compte</h1>
        <div class="form-wrapper">
            <?php if($rtp_user['newsletter'] == 0) { ?>
            <form method="post" action="" id="activate-account-form">
                <img src="<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $user['look']; ?>&action=&direction=3&head_direction=3" width="64" height="110"/>
                <div id="info">
                <p class="confirmation">Adresse email vérifiée.</p>
                <dl>
                    <dt>Nom</dt>
                    <dd><?php echo $user['username']; ?></dd>
                    <dt>Email</dt>
                    <dd><?php echo $user['mail']; ?></dd>
                </dl>
                <label><input type="checkbox" name="directEmailAllowed" <?php if($rtp_user['newsletter'] == "0") { ?>value="1"<?php } ?><?php if($rtp_user['newsletter'] == "1") { ?> value="0" checked="checked"<?php } ?>/> Oui, je souhaite recevoir des infos de <?php echo Settings('Name'); ?>.</label><br/>
                </div>
                <p>
                <a href="#" class="new-button green-button left" onclick="$(this).up('form').submit(); return false;"><b>OK</b><i></i></a>
                <a class="landing-link" href="<?php echo Settings('Url'); ?>">Retour à l'accueil</a>
                </p>
                <input type="submit" value="OK" id="next"/>
            </form>
            <?php } if($rtp_user['newsletter'] == 1) { ?>
            <div style="padding: 50px 10px 0;">
                <p class="confirmation">Tu recevras désormais les messages de <?php echo Settings('Name'); ?>!</p>
            <p>
                <a href="<?php echo Settings('Url'); ?>">Retour à l'accueil</a>
            </p>
        </div>
            <?php } ?>
        </div>
    </div>
    <div class="activateemail-container-bottom"></div>
    <script type="text/javascript">
        $(document.body).addClassName("js");
    </script>

<?php include("../templates/footer.php"); ?>

<script type="text/javascript">
if (typeof HabboView != "undefined") {
    HabboView.run();
}
</script>

</body>
</html>
