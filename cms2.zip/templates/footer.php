    <center><footer>
    <div id="leftfooter">
        <div class="hotelcopy"></div>
    </div>
    <div id="rightfooter">
    <p class="right">
    <span style="font-size:12px;"> Imaginez par Wolpeur, repris par Yazpeur &copy; Copyright - <span class="dev"><?php echo Settings('Name'); ?></span> 2016-2017</span>
    <br>
    <?php echo Settings('Name'); ?> est un projet ind&eacute;pendant, à but non lucratif. 
    <br> 
    Nous ne sommes pas approuv&eacute;, affili&eacute;s, ou offertes par Sulake Corporation LTD.
    </p>
    </div>
</footer></center>