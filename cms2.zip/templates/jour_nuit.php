<SCRIPT LANGUAGE="JavaScript"> 
<!-- 
var today=new Date(); 
var heure=""; 
function messagevariable() { 
var time=today.getHours(); 
heure="" 
if(time>=6 && time<8) 
heure="<div id=\"habbo-hotel-image\">" 
if(time>=8 && time<18) 
heure="<div id=\"habbo-hotel-image\">" 
if(time>=18 || time<6) 
heure="<div id=\"habbo-hotel-night\">" 
} 
// --></SCRIPT> 
<SCRIPT LANGUAGE="JavaScript"> 
<!-- 
messagevariable(); 
document.writeln(heure) 
// --> 
</SCRIPT>
</div>