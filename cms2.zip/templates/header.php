 <header>
    <div id="content" style="padding: 10px 0 0 0;">
  <div class="hotel"></div>
    <h1 class="logo"></h1>
    <div id="compteur">
      <b><?php echo $nb_inscrit['id']; ?></b> inscrits sur <?php echo Settings('Name'); ?> !
    </div>
    <a href="<?php echo Settings('Url'); ?>/account/logout" class="logout">D&eacute;connexion</a>
  </div>
  <div id="global">

<style>

</style>
   <div id="left_header">

 

   </div>
  </div>
 </header>
 
 <!-- NAV -->
<nav id="menu" class="navigation">
  <div id="content">
    <ul>
        <?php if($menu_id == "1" or $menu_id == "2" or $menu_id == "3" or $menu_id == "16") { ?>
      <li class="active icon me" style="background-image:url(<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $user['look']; ?>);">
        <a href="<?php echo Settings('Url'); ?>/me"><?php echo $user['username']; ?></a>
      </li>
        <?php } else { ?>
   <li class=" icon me" style="background-image:url(<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $user['look']; ?>);">
        <a href="<?php echo Settings('Url'); ?>/me"><?php echo $user['username']; ?></a>
      </li>
         <?php } ?>

<?php if($menu_id == "4" or $pageid == "news" or $menu_id == "6" or $menu_id == "7" or $menu_id == "8" or $menu_id == "9" or $menu_id == "10") { ?>
      <li class="active icon community">
        <a href="<?php echo Settings('Url'); ?>/community.php">Communaut&eacute;</a>
      </li>
       <?php } else { ?>
        <li class=" icon community">
        <a href="<?php echo Settings('Url'); ?>/community.php">Communaut&eacute;</a>
      </li>
        <?php } ?>

        <?php if($menu_id == "11" or $menu_id == "12" or $menu_id == "13" or $menu_id == "14") { ?>
      <li class="active icon shop">
        <a href="<?php echo Settings('Url'); ?>/shop.php">Boutique</a>
      </li>
      <?php } else { ?>
      <li class=" icon shop">
        <a href="<?php echo Settings('Url'); ?>/shop.php">Boutique</a>
      </li>
      <?php  } ?>
      <?php if($user['rank'] >= '7') { ?> 
          <li class=" icon adm">
        <a href="<?php echo Settings('Url'); ?>/admin/"  target="_blank">Administration</a>
      </li><?php  } ?>
          </ul>
  </div>
</nav>
<div id="subnav"  class="navigation">
  <div id="content">
    <?php if($menu_id == "1" or $menu_id == "2" or $menu_id == "3" or $menu_id == "16") { ?>
    <ul>

      <li>
        <?php if($menu_id == "1") { ?>
        <a class="active" href="<?php echo Settings('Url'); ?>/me"><?php echo $user['username']; ?></a>
         <?php } else { ?>
         <a href="<?php echo Settings('Url'); ?>/me"><?php echo $user['username']; ?></a>
          <?php } ?>
      </li>
          <li>
            <?php if($menu_id == "2") { ?>
        <a class="active" href="<?php echo Settings('Url'); ?>/home">Home</a>
          <?php } else { ?>
          <a  href="<?php echo Settings('Url'); ?>/home">Home</a>
            <?php }  ?>
      </li>
     <li>
         <?php if($menu_id == "16") { ?>
      <a class="active"  href="<?php echo Settings('Url'); ?>parametre">Paramètres</a>
      <?php } else {  ?>
      <a  href="<?php echo Settings('Url'); ?>/parametre">Paramètres</a>
      <?php }   ?>
      </li>
    
      <li>
         <?php if($menu_id == "3") { ?>
      <a class="active" href="<?php echo Settings('Url'); ?>/#">Transactions</a>
       <?php } else { ?>
       <a  href="<?php echo Settings('Url'); ?>/#">Transactions</a>
        <?php } ?>
      </li>
   
    
        </ul>
    <?php } elseif($menu_id == "4" or $pageid == "news" or $menu_id == "6" or $menu_id == "7" or $menu_id == "8" or $menu_id == "9" or $menu_id == "10" ) { ?>
     <ul>
          <li>
            <?php if($menu_id == "4" ) { ?>
        <a class="active" href="<?php echo Settings('Url'); ?>/community">Communauté</a>
        <?php } else {  ?>
         <a  href="<?php echo Settings('Url'); ?>/community">Communauté</a>
        <?php } ?>
      </li>
          <li>
            <?php if($menu_id == "6") { ?>
        <a class="active" href="<?php echo Settings('Url'); ?>/staffs">Staffs</a>
        <?php } else {  ?>
         <a   href="<?php echo Settings('Url'); ?>/staffs">Staffs</a>
        <?php }   ?>
      </li>
              <li>
                 <?php if($menu_id == "7") { ?>
        <a  class="active" href="<?php echo Settings('Url'); ?>/otherstaff">Autres Staffs</a>
        <?php } else {  ?>
         <a  href="<?php echo Settings('Url'); ?>/otherstaff">Autres Staffs</a>
        <?php }  ?>
      </li>
   

      <li>
         <?php if($menu_id == "9") { ?>
      <a class="active" href="<?php echo Settings('Url'); ?>/palmares">Palmarès</a>
       <?php } else {  ?>
         <a  href="<?php echo Settings('Url'); ?>/palmares">Palmarès</a>
        <?php }   ?>
      </li>
          <li>
        
         <?php if($menu_id == "10") { ?>
      <a class="active"  href="<?php echo Settings('Url'); ?>/gamers">Gamers</a>
       <?php } else {  ?>
       <a   href="<?php echo Settings('Url'); ?>/gamers">Gamers</a>
        <?php }  ?>
      </li>
    
        </ul>

           <?php } elseif($menu_id == "11" or $menu_id == "12" or $menu_id == "13" or $menu_id == "14") { ?>

            <ul>
          <li>
            <?php if($menu_id == "11") { ?>
        <a class="active" href="<?php echo Settings('Url'); ?>/shop">Boutique</a>
         <?php } else {  ?>
          <a href="<?php echo Settings('Url'); ?>/shop">Boutique</a>
          <?php }  ?>
      </li>
          <li>
             <?php if($menu_id == "12") { ?>
        <a class="active" href="<?php echo Settings('Url'); ?>/vip">Vip</a>
         <?php } else {  ?>
          <a  href="<?php echo Settings('Url'); ?>/vip">Vip</a>
          <?php }   ?>
      </li>
       <li>
         <?php if($menu_id == "14") { ?>
      <a class="active"  href="<?php echo Settings('Url'); ?>/convert">Convertisseur</a>
      <?php } else {  ?>
      <a  href="<?php echo Settings('Url'); ?>/convert">Convertisseur</a>
      <?php }   ?>
      </li>

   <!--   <li>
         <?php if($menu_id == "13") { ?>
      <a class="active"  href="<?php echo Settings('Url'); ?>/shopbadge">Badges</a>
      <?php } else {  ?>
      <a  href="<?php echo Settings('Url'); ?>/shopbadge">Badges</a>
      <?php }   ?>
      </li> -->
    
        </ul>

           <?php } ?>

  </div>
</div>