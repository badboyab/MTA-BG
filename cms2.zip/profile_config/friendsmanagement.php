<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/register.php");
include("../includes/files/session.disconnect.php");

$pagename = "Mes données";
$pageid = "settings";
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>

<link rel="shortcut icon" href="<?php echo Settings('Url_Images'); ?>/v2/favicon.ico?<?php echo $update; ?>" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/common.css?<?php echo $update; ?>" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>/static/js/libs2.js?<?php echo $update; ?>" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/visual.js?<?php echo $update; ?>" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/libs.js?<?php echo $update; ?>" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/common.js?<?php echo $update; ?>" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/fullcontent.js?<?php echo $update; ?>" type="text/javascript"></script>
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/lightweightmepage.css?<?php echo $update; ?>" type="text/css" />

<script src="<?php echo Settings('Url_Images'); ?>/static/js/lightweightmepage.js?<?php echo $update; ?>" type="text/javascript"></script>

<script src="<?php echo Settings('Url_Images'); ?>/static/js/settings.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/settings.css" type="text/css" />

<?php include("./templates/meta.php"); ?>

<!--[if IE 8]>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>static/styles/ie8.css" type="text/css" />
<![endif]-->
<!--[if lt IE 8]>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>static/styles/ie.css" type="text/css" />
<![endif]-->
<!--[if lt IE 7]>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>static/styles/ie6.css" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>static/js/pngfix.js" type="text/javascript"></script>
<script type="text/javascript">
try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
</script>

<style type="text/css">
body { behavior: url(/js/csshover.htc); }
</style>
<![endif]-->
</head>

<body id="home" class=" ">

<?php include("../templates/header.php"); ?>

<div id="container">
    <div id="content" style="position: relative" class="clearfix">
    <div>

<div class="content">
<div class="habblet-container" style="float:left; width:210px;">
<div class="cbb settings">

<h2 class="title">Mes Préférences</h2>
<div class="box-content">
            <div id="settingsNavigation">
            <ul>

                <li ><a href="<?php echo Settings('Url'); ?>/profile?tab=2">Mission</a>
                </li>

                    <?php $sql = mysql_query("SELECT * FROM users WHERE facebook_id = '' AND id=".$user['id']."");
while($s = mysql_fetch_array($sql)) {
    echo '<li
                        ><a href="/profile/email?tab=3">Email: Changement et Activation</a>
                    </li>

                    <li
                      ><a href="/profile/password?tab=4">Mot de passe</a>
                    </li>';
    } ?>


                <li class="selected">Gestion des amis                </li>

                <li>
                    <a href="<?php echo Settings('Url'); ?>/identity/settings">Paramètres de connexion</a>
                </li>
            </ul>
            </div>
</div></div>
</div>  <div id="friend-management" class="habblet-container">
    <div class="cbb clearfix settings">
      <h2 class="title">Gestion des amis</h2>
      <div id="friend-management-container" class="box-content">
        <div id="category-view" class="clearfix">
          <div id="search-view">
            Rechercher un ami ci-dessous:
            <div id="friend-search" class="friendlist-search">
          <input type="text" maxlength="32" id="friend_query" class="friend-search-query" />
          <a class="friendlist-search new-button search-icon" id="friend-search-button"><b><span></span></b><i></i></a>
            </div>
          </div>
          <div id="category-list">
<div id="friends-category-title">
    Catégories d'amis
</div>

<div class="category-default category-item selected-category" id="category-item-0">Amis</div>

    <input type="text" maxlength="32" id="category-name" class="create-category" /><div id="add-category-button" class="friendmanagement-small-icons add-category-item add-category"></div>
          </div>
        </div>
        <div id="friend-list" class="clearfix">
<div id="friend-list-header-container" class="clearfix">
    <div id="friend-list-header">
        <div class="page-limit">
            <div class="big-icons friend-header-icon">Amis
              
            </div>
        </div>
    </div>
    <div id="friend-list-paging">
        </div>
    </div>


<form id="friend-list-form">
    <table id="friend-list-table" border="0" cellpadding="0" cellspacing="0">
        <thead>
            <tr class="friend-list-header">
                <th class="friend-select" />
                <th class="friend-name">
                    <a class="sort">Nom</a>
                </th>
                <th class="friend-login">
                    <a class="sort">Dernière connexion</a>
                </th>
                
            </tr>
        </thead>
        <tbody>
           <?php
    $i = 0;
    $sql = mysql_query("SELECT * FROM messenger_friendships WHERE user_one_id = '".$user['id']."' ORDER BY user_one_id DESC LIMIT 30");
      while($friend = mysql_fetch_array($sql)) {
          $getfriend = mysql_query("SELECT * FROM users WHERE id = '".$friend['user_two_id']."'");
          $f = mysql_fetch_array($getfriend);
          $i++;
          if(IsEven($i)) {
            $oddeven = "odd";
            } else {
            $oddeven = "even";
            }
            
            printf("   <tr class=\"%s\">
               <td><input type=\"checkbox\" name=\"friendList[]\" value=\"%s\" /></td>
               <td class=\"friend-name\">
                %s
               </td>
               <td class=\"friend-login\" title=\"%s\">%s</td>
              
           </tr>", $oddeven, $f['id'], $f['username'], $f['last_offline'], $f['last_offline'], $f['id']);
            
          }
          
    ?>
          
        </tbody>
    </table>
    <a class="select-all" id="friends-select-all" href="#">Sélectionner tous</a> |
    <a class="deselect-all" href=#" id="friends-deselect-all">Désélectionner tous</a>
</form>


<div class="friend-del"><a class="new-button red-button cancel-icon" href="#" id="delete-friends"><b><span></span>Supprimer les amis choisis</b><i></i></a></div>

        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
  L10N.put("friendmanagement.tooltip.deletefriends", "Are you sure you want to delete these selected friends?\n<div class=\"friendmanagement-small-icons friendmanagement-save friendmanagement-tip-delete\">\n    <a class=\"friends-delete-button\" id=\"delete-friends-button\">Delete<\/a>\n<\/div>\n<div class=\"friendmanagement-small-icons friendmanagement-remove friendmanagement-tip-cancel\">\n    <a id=\"cancel-delete-friends\">Cancel<\/a>\n<\/div>\n\n");
  L10N.put("friendmanagement.tooltip.deletefriend", "Are you sure you want to delete this friend?\n<div class=\"friendmanagement-small-icons friendmanagement-save friendmanagement-tip-delete\">\n    <a id=\"delete-friend-%friend_id%\">Delete<\/a>\n<\/div>\n<div class=\"friendmanagement-small-icons friendmanagement-remove friendmanagement-tip-cancel\">\n    <a id=\"remove-friend-can-%friend_id%\">Cancel<\/a>\n<\/div>");
  L10N.put("friendmanagement.tooltip.deletecategory", "Are you sure you want to delete this category?\n<div class=\"friendmanagement-small-icons friendmanagement-save friendmanagement-tip-delete\">\n    <a class=\"delete-category-button\" id=\"delete-category-%category_id%\">Delete<\/a>\n<\/div>\n<div class=\"friendmanagement-small-icons friendmanagement-remove friendmanagement-tip-cancel\">\n    <a id=\"cancel-cat-delete-%category_id%\">Cancel<\/a>\n<\/div>");
  new FriendManagement({ currentCategoryId: 0, pageListLimit: 30, pageNumber: 1});
</script>

</div>
    </div>
                <script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
             
</div>
<!--[if lt IE 7]>
<script type="text/javascript">
Pngfix.doPngImageFix();
</script>
<![endif]-->
</div>

<!-- FOOTER -->
<?php include("../templates/footer.php"); ?>
<!-- FIN FOOTER -->

</body>
</html>