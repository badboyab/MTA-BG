<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("../init.php");
include("../includes/files/register.php");
include("../includes/files/session.disconnect.php");

$pagename = "Mes données";
$pageid = "settings";

if($user['facebook'] >= 1) {
Redirect("".Settings('Url')."/profile?tab=2");
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>

<link rel="shortcut icon" href="<?php echo Settings('Url_Images'); ?>/v2/favicon.ico?<?php echo $update; ?>" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/common.css?<?php echo $update; ?>" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>/static/js/libs2.js?<?php echo $update; ?>" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/visual.js?<?php echo $update; ?>" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/libs.js?<?php echo $update; ?>" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/common.js?<?php echo $update; ?>" type="text/javascript"></script>
<script src="<?php echo Settings('Url_Images'); ?>/static/js/fullcontent.js?<?php echo $update; ?>" type="text/javascript"></script>
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/lightweightmepage.css?<?php echo $update; ?>" type="text/css" />

<script src="<?php echo Settings('Url_Images'); ?>/static/js/lightweightmepage.js?<?php echo $update; ?>" type="text/javascript"></script>

<script src="<?php echo Settings('Url_Images'); ?>/static/js/settings.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>/static/styles/settings.css" type="text/css" />

<?php include("./templates/meta.php"); ?>

<!--[if IE 8]>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>static/styles/ie8.css" type="text/css" />
<![endif]-->
<!--[if lt IE 8]>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>static/styles/ie.css" type="text/css" />
<![endif]-->
<!--[if lt IE 7]>
<link rel="stylesheet" href="<?php echo Settings('Url_Images'); ?>static/styles/ie6.css" type="text/css" />
<script src="<?php echo Settings('Url_Images'); ?>static/js/pngfix.js" type="text/javascript"></script>
<script type="text/javascript">
try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
</script>

<style type="text/css">
body { behavior: url(/js/csshover.htc); }
</style>
<![endif]-->
</head>

<body id="home" class=" ">

<?php include("../templates/header.php"); ?>

<div id="container">
    <div id="content" style="position: relative" class="clearfix">
    <div>

<div class="content">
<div class="habblet-container" style="float:left; width:210px;">
<div class="cbb settings">

<h2 class="title">Mes Préférences</h2>
<div class="box-content">
            <div id="settingsNavigation">
            <ul>

                <li ><a href="<?php echo Settings('Url'); ?>/profile?tab=2">Mission</a>
                </li>

                    <li
                        class="selected">Email: Changement et Activation
                    </li>

                    <li
                      ><a href="<?php echo Settings('Url'); ?>/profile/password?tab=4">Mot de passe</a>
                    </li>


                <li ><a href="<?php echo Settings('Url'); ?>/profile/friendsmanagement?tab=6">Gestion des amis</a>
                </li>

                <li>
                    <a href="<?php echo Settings('Url'); ?>/identity/settings">Paramètres de connexion</a>
                </li>
            </ul>
            </div>
</div></div>
</div>
    <div class="habblet-container" style="float:left; width: 560px;">
        <div class="cbb clearfix settings">
            <h2 class="title">Change et active ton email</h2>

            <div class="box-content">


                <p>Tu t'es connecté avec ton compte <?php echo Settings('Name'); ?> ID. Pour changer d'adresse email va dans tes préférences. Clique sur le lien ci-dessous pour procéder à ce changement.</p>

                <p>
                    <a href="<?php echo Settings('Url'); ?>/identity/email">Changer l'email de ce compte <?php echo Settings('Nickname'); ?> ID</a>
                </p>
            </div>
        </div>
    </div>
</div>
</div>
    </div>
                        
                <div class="habblet-container ">        
    
                        <div class="ad-container">

</div>

                        
                    
                </div>
                <script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
             
</div>
<!--[if lt IE 7]>
<script type="text/javascript">
Pngfix.doPngImageFix();
</script>
<![endif]-->
</div>

<!-- FOOTER -->
<?php include("../templates/footer.php"); ?>
<!-- FIN FOOTER -->

</body>
</html>