<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
    
$pagename = "Les staffs secondaire";
$pageid = "otherstaff";
 $menu_id="7"
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo Settings('Name'); ?>: <?php echo $pagename; ?></title>
 <link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/gallery/css/global.css?1461255333">
    <link rel="stylesheet" type="text/css" href="<?php echo Settings('Url'); ?>/gallery/css/staffs.css?1461255333">
    <link rel="shortcut icon" href="./favicon.ico">

    <meta name="twitter:title" content="Adov: Entre dans un hôtel où tout est gratuit, fais-toi plein d'amis et deviens célèbre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="Rétro Habbo">
    <meta property="og:site_name" content="Habbo Hôtel"/>
    <meta property="og:title" content="Habbo: Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, réseau social, gratuit, communautée, avatar, chat, connectée, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécuritée, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>
 <style type="text/css">
    #box p{
        font-size: 12px;
    }</style>
</head>
<body>
    <?php include("./templates/header.php"); ?>	<div id="content" class="page">
		<div id="left" class="column5">
			<div id="box">	
				<div class="titre" style="background-color: #4F196E;">Pubeurs Pro</div>
				<!-- // adm --><?php
$sql = mysql_query("SELECT * FROM users WHERE rank = '4'");
while($s = mysql_fetch_array($sql)) { 
$date1 = date('d F Y', $s['last_offline']); 
$date1 = str_replace("Monday", "Lundi", $date1);
$date1 = str_replace("Tuesday", "Mardi", $date1);
$date1 = str_replace("Wednesday", "Mercredi", $date1);
$date1 = str_replace("Thursday", "Jeudi", $date1);
$date1 = str_replace("Friday", "Vendredi", $date1);
$date1 = str_replace("Saturday", "Samedi", $date1);
$date1 = str_replace("Sunday", "Dimanche", $date1);
$date1 = str_replace("January", "janv.", $date1);
$date1 = str_replace("February", "fév.", $date1);
$date1 = str_replace("March", "mars", $date1);
$date1 = str_replace("April", "avr.", $date1);
$date1 = str_replace("May", "mai", $date1);
$date1 = str_replace("June", "juin", $date1);
$date1 = str_replace("July", "juil.", $date1);
$date1 = str_replace("August", "août", $date1);
$date1 = str_replace("September", "sept.", $date1);
$date1 = str_replace("October", "oct.", $date1);
$date1 = str_replace("November", "nov.", $date1);
$date1 = str_replace("December", "déc.", $date1);
?>
								<div id="staff">
					<div class="avatar" style="background-image:url(<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $s['look'] ?>&direction=2&head_direction=3&gesture=sml&size=big&img_format=gif);">
					</div>
					<div class="about">
						<span class="pseudo"><?php echo $s['username'] ; ?></span>
						<span class="mission">Mission: <?php if(!empty($s['motto'])) { echo utf8_encode(stripslashes($s['motto'])); } ?></span>
						
<?php if ($s['online'] == 0) { ?>
												<div class="sprites" id="image_2965450689662248_gif"></div>
												<?php } elseif ($s['online'] == 1) { ?>
												<div class="sprites2" id="image_23754860064946115_gif"></div><?php } ?>
												<img src="/swf/c_images/album1584/NT248.gif" style="margin-top: -50px;
    					margin-left: 260px;
    					position: absolute;
    					box-shadow: inset 0px 0px 3px rgb(206, 208, 214);
    					border-radius: 26px;">
					</div>
				</div><?php } ?>
							</div>
						
			<div class="clear"></div>			
			<div id="box">	
				<div class="titre" style="background-color: #4ab501;">Graphistes</div>
				<!-- // psp -->
								<!-- // adm --><?php
$sql = mysql_query("SELECT * FROM users WHERE rank = '5'");
while($s = mysql_fetch_array($sql)) { 
$date1 = date('d F Y', $s['last_offline']); 
$date1 = str_replace("Monday", "Lundi", $date1);
$date1 = str_replace("Tuesday", "Mardi", $date1);
$date1 = str_replace("Wednesday", "Mercredi", $date1);
$date1 = str_replace("Thursday", "Jeudi", $date1);
$date1 = str_replace("Friday", "Vendredi", $date1);
$date1 = str_replace("Saturday", "Samedi", $date1);
$date1 = str_replace("Sunday", "Dimanche", $date1);
$date1 = str_replace("January", "janv.", $date1);
$date1 = str_replace("February", "fév.", $date1);
$date1 = str_replace("March", "mars", $date1);
$date1 = str_replace("April", "avr.", $date1);
$date1 = str_replace("May", "mai", $date1);
$date1 = str_replace("June", "juin", $date1);
$date1 = str_replace("July", "juil.", $date1);
$date1 = str_replace("August", "août", $date1);
$date1 = str_replace("September", "sept.", $date1);
$date1 = str_replace("October", "oct.", $date1);
$date1 = str_replace("November", "nov.", $date1);
$date1 = str_replace("December", "déc.", $date1);
?>
								<div id="staff">
					<div class="avatar" style="background-image:url(<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $s['look'] ?>&direction=2&head_direction=3&gesture=sml&size=big&img_format=gif);">
					</div>
					<div class="about">
						<span class="pseudo"><?php echo $s['username'] ; ?></span>
						<span class="mission">Mission: <?php if(!empty($s['motto'])) { echo utf8_encode(stripslashes($s['motto'])); } ?></span>
						
<?php if ($s['online'] == 0) { ?>
												<div class="sprites" id="image_2965450689662248_gif"></div>
												<?php } elseif ($s['online'] == 1) { ?>
												<div class="sprites2" id="image_23754860064946115_gif"></div><?php } ?>
												<img src="/swf/c_images/album1584/NT248.gif" style="margin-top: -50px;
    					margin-left: 260px;
    					position: absolute;
    					box-shadow: inset 0px 0px 3px rgb(206, 208, 214);
    					border-radius: 26px;">
					</div>
				</div><?php } ?>
						
							</div>
			<div class="clear"></div>
			<div id="box">	
				<div class="titre" style="background-color: #FFC16E;">Guides</div>
				<!-- // adm --><?php
$sql = mysql_query("SELECT * FROM users WHERE rank = '3'");
while($s = mysql_fetch_array($sql)) { 
$date1 = date('d F Y', $s['last_offline']); 
$date1 = str_replace("Monday", "Lundi", $date1);
$date1 = str_replace("Tuesday", "Mardi", $date1);
$date1 = str_replace("Wednesday", "Mercredi", $date1);
$date1 = str_replace("Thursday", "Jeudi", $date1);
$date1 = str_replace("Friday", "Vendredi", $date1);
$date1 = str_replace("Saturday", "Samedi", $date1);
$date1 = str_replace("Sunday", "Dimanche", $date1);
$date1 = str_replace("January", "janv.", $date1);
$date1 = str_replace("February", "fév.", $date1);
$date1 = str_replace("March", "mars", $date1);
$date1 = str_replace("April", "avr.", $date1);
$date1 = str_replace("May", "mai", $date1);
$date1 = str_replace("June", "juin", $date1);
$date1 = str_replace("July", "juil.", $date1);
$date1 = str_replace("August", "août", $date1);
$date1 = str_replace("September", "sept.", $date1);
$date1 = str_replace("October", "oct.", $date1);
$date1 = str_replace("November", "nov.", $date1);
$date1 = str_replace("December", "déc.", $date1);
?>
								<div id="staff">
					<div class="avatar" style="background-image:url(<?php echo Settings('Avatarimage'); ?>avatarimage?figure=<?php echo $s['look'] ?>&direction=2&head_direction=3&gesture=sml&size=big&img_format=gif);">
					</div>
					<div class="about">
						<span class="pseudo"><?php echo $s['username'] ; ?></span>
						<span class="mission">Mission: <?php if(!empty($s['motto'])) { echo utf8_encode(stripslashes($s['motto'])); } ?></span>
						<br><br>
<?php if ($s['online'] == 0) { ?>
												<div class="sprites" id="image_2965450689662248_gif"></div>
												<?php } elseif ($s['online'] == 1) { ?>
												<div class="sprites2" id="image_23754860064946115_gif"></div><?php } ?>
												<img src="/swf/c_images/album1584/NT248.gif" style="margin-top: -50px;
    					margin-left: 260px;
    					position: absolute;
    					box-shadow: inset 0px 0px 3px rgb(206, 208, 214);
    					border-radius: 26px;">
					</div>
				</div><?php } ?>
							</div>
						
			<div class="clear"></div>
		</div>
		<div id="right" class="column4">
			<div id="box">
				<div class="titre" id="bleu">L'équipe</div>
				<p>
                    <b>"Qui sont ces personnes?"</b> <br > Les <b>animateurs sponsorisés</b> sont des personnes travaillant pour les animateurs, il créer des jeux et sont sponsorisés en priorité par les animateurs. Ils ont également le droit à une formation pour devenir animateur et donc obtienne plus de chance lors des futurs recrutements d'animateurs.
                    <br >Les <b>graphistes</b> sont des personnes travaillant pour Habdo, ces personnes réalise des logos, des badges et pleins d'autres choses. Il apporte une touche de design à Habdo. <br >Les <b>guides</b> sont une équipe de joueurs ayant un rôle très précis et essentiel à l'hôtel. 
					Ils sont très présents dans celui-ci afin guider les joueurs, répondre aux questions et accueillir les nouveaux. 
					Ils sont les bras droits des modérateurs et accordent tous leurs temps aux connectés. 
					Grâce à leurs "Foire aux Questions" régulières dans le Centre d'Aide, ils permettent à la communauté de se réunir pour récolter de nombreuses informations.
                </p>
			</div>
			</div>

	<div class="clear"></div>
<?php include("./templates/footer.php"); ?>	</div>
</body>
</html>