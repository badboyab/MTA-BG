<?php
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|                Développement de RetroPHP par Tyler                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include("./init.php");
include("./includes/files/register.php");
include("./includes/files/session.disconnect.php");
    
$pagename = "Convertisseur";
$pageid = "convertisseur";
$menu_id="14"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo Settings('Name'); ?>: <?php echo $user['username']; ?></title>
    <link rel="stylesheet" type="text/css" href="gallery/css/global.css?1461255333">
	<link rel="stylesheet" type="text/css" href="./gallery/css/convert.css?1450716853">
	<link rel="stylesheet" type="text/css" href="./gallery/css/shop.css?1450716853">
    <link rel="shortcut icon" href="./favicon.ico">

    <meta name="twitter:title" content="Adov: Entre dans un hôtel où tout est gratuit, fais-toi plein d'amis et deviens célèbre!"/>
    <meta name="twitter:description" content="Habbo - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="identifier-url" content="http://adov.fr/"/>
    <meta name="category" content="Rétro Habbo">
    <meta property="og:site_name" content="Habbo Hôtel"/>
    <meta property="og:title" content="Habbo: Crée ton avatar, décore ton appart, chatte et fais-toi plein d'amis."/>
    <meta property="og:url" content="http://adov.fr/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta property="og:locale" content="fr_FR"/>
    <meta name="description" content="Adov - fais-toi plein d'amis et deviens célèbre en séjournant GRATUITEMENT dans l'un des plus grand rétro de France!"/>
    <meta name="keywords" content="adov, habdo, habbo, virtuel, monde, réseau social, gratuit, communautée, avatar, chat, connectée, adolescence, jeu de rôle, rejoindre, social, groupes, forums, sécuritée, jouer, jeux, amis, rares, ados, jeunes, collector, collectionner, créer, connecter, meuble, mobilier, animaux, déco, design, appart, décorer, partager, badges, musique, chat vip, fun, sortir, mmo, mmorpg, jeu massivement multijoueur, habbi, habbiworld, habbodreams, jabbo, habbo hotel, habbo gratuit, habbo credit"/>
</head>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Habbo: Convertisseur</title>
	<link rel="stylesheet" type="text/css" href="./gallery/css/global.css?1450716853">
	<link rel="stylesheet" type="text/css" href="./gallery/css/convert.css?1450716853">
	<link rel="stylesheet" type="text/css" href="./gallery/css/shop.css?1450716853">
    <link rel="shortcut icon" href="favicon.ico">
	<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
	<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
	<script src="http:///gallery/js.js?1450716853"></script>


</head>
<body>
<?php include("./templates/header.php"); ?>
	<div id="content" class="page">
							<div id="Convertisseur">
			<div id="form">
				<div id="wrap">
					<div id="overlay">
						<div id="msg">
								Les Habbo Points sont la monnaie de l'h&ocirc;tel. Avec eux, tu peux t'acheter des rares ou des badges au "Habbo Shop" sur l'hotel!
							</div>
						<div id="container">
							
							<div id="titreshop">Choisis les offres</div>
							<div id="contenushop">
								<div>
									<form method="post" action="?convert=1">
										<input type="submit" value="100 Habbo Points - 200 jetons">
									</form>
									<form method="post" action="?convert=2">
										<input type="submit" value="50 Habbo Points - 100 jetons">
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<div class="clear"></div>

	<footer>
	<div id="leftfooter">
		<div class="hotelcopy"></div>
	</div>
	<div id="rightfooter">
	<p class="right">
	<span style="font-size:12px;">&copy; Copyright - <span class="dev"><?PHP echo $sitename; ?></span> 2014-2015</span>
	<br>
	<?PHP echo $sitename; ?> est un projet ind&eacute;pendant, à but non lucratif. 
	<br> 
	Nous ne sommes pas approuv&eacute;, affili&eacute;s, ou offertes par Sulake Corporation LTD.
        <br> 
        Une reproduction du cms de Hab** by Homega
	</p>
	</div>
</footer>
	</div>
</body>
</html>