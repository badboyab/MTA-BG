<?php


	
require_once 'required.php';
die(number_format($core->getServerStat('active_players')));
?>