<?php


											  
                                          

	require_once "required.php";

	
	$tpl->assign('loginError', null);
	$tpl->assign('title', 'Se faire des amis, s\'amuser, se faire connaitre.');
	
	if ($users->isLogged()) {
		header ("Location: /me");
		exit;
	}
	if (isset($_POST["credentials_username"]) && isset($_POST["credentials_password"])) {
		$u = $db->real_escape_string($_POST["credentials_username"]);
		$p = $users->userHash($_POST["credentials_password"], $u);

		if ($users->validCredentials($u, $p)) {
			$_SESSION["Username"] = $users->userVar($u, 'username');
			$_SESSION["HashedPassword"] = $p;
			header ("Location: " . WWW . "/me");
			exit;
		}
		else {
			$tpl->assign('LoginError', 'Invalid username or password.');
		}
	}
	
	// Initialize HTML Output
	$tpl->draw('index-top');
	$tpl->draw('index');
	$tpl->draw('footer');
?>