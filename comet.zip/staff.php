<?php


	
	require_once "required.php";
	
	if(!$users->isLogged()) {
		header ("Location: " . WWW . "/");
		exit;
	}
	
	define('StaffPageSelected', true);
	define('CommunitySelected', true);
	
	$tpl->assign('pagetitle', "Staff");
	
	$tpl->draw('cms-head');
	$tpl->draw('cms-generictop');
	$tpl->draw('com-nav');
	$tpl->draw('staff');
	$tpl->draw('bottom');
	$tpl->draw('footer');
	
?>