<?php

	class LanguageManager {
	
		public $MaintenanceBigText = "Maintenance break!";
		public $MaintenanceSmallText = "Sorry! Test Hotel is being worked on at the moment.";
		public $MaintenanceSecondaryText = "We'll be open soon. We promise.";
		
	}
	
?>