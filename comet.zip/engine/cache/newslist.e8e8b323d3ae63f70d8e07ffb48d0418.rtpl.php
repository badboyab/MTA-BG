<?php if(!class_exists('raintpl')){exit;}?><div id="container">
	<div id="content" style="position: relative" class="clearfix">
    <div>


<div class="habblet-container " style="float:left; width:210px;">		
	<div class="cbb clearfix orange "> 
		<h2 class="title">Articles</h2> 
			<div id="article-archive"> 
 				<h2>50 derniers articles</h2> 
					<ul>
						<?php echo lightcms::drawNewsList(_id); ?>
					</ul>
			</div> 
		</div>
</div> 
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>