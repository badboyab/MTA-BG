<?php if(!class_exists('raintpl')){exit;}?></div>
</div>
</div>
</div>
</div>
</div>
</div>
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>