<?php if(!class_exists('raintpl')){exit;}?><div id="container">
	<div id="content" style="position: relative" class="clearfix">
    <div>

<div class="content">
<div class="habblet-container" style="float:left; width:210px;">
<div class="cbb settings">

<h2 class="title">Mot de passe</h2>
<div class="box-content">
            <div id="settingsNavigation">
            <ul>
				<?php if( selected == 'pass-settings' ){ ?>
					<li class="selected">Mot de passe</li>
				<?php }else{ ?>
					<li class=""><a href='<?php echo $www;?>/profile/password'>Paramètres du mot de passe</a></li>
				<?php } ?>
			</ul>
            </div>
</div></div>
</div>
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>