<?php if(!class_exists('raintpl')){exit;}?><div id="footer"> 
	<p class="footer-links"></p>
	<p class="copyright">Propulsé par <a href='http://habboworld.fr'>Habboworld CMS</a> by <a href='http://habboworld.fr/user/Mirlyn'>Mirlyn</a> <br />
	Copyright &copy; 2016 - 2017 <?php echo $sitename;?>, Tous droits réservés.</p>
</div>
