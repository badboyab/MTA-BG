<?php if(!class_exists('raintpl')){exit;}?><div class="habblet-container"> 
	<div class="cbb clearfix red"> 
		<h2 class="title">Pack VIP</h2> 
		<div class="box-content"> 
			Pour devenir VIP sur Habboworld, il te suffit de payer 50 diamants.
		</div>
	</div>
</div>

<div class="habblet-container"> 
	<div class="cbb clearfix blue"> 
		<h2 class="title">Mobis Rares</h2> 
		<div class="box-content"> 
			Les mobis rares arrivent très bientôt dans la boutique!
		</div>
	</div>
</div>

<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>