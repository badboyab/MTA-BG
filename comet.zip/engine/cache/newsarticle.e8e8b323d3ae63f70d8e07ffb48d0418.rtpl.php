<?php if(!class_exists('raintpl')){exit;}?><div class="habblet-container " style="float:left; width:550px;"> 
<div class="cbb clearfix notitle "> 


<div id="article-wrapper"> 

<h2><?php echo $mainTitle;?></h2> 

<div class="article-meta"> 
 
<?php echo $postedDate;?>
 
</div> 

 
<p class="summary"> 

<?php echo $newsSummary;?>

</p> 
 

<div class="article-body"> 
<?php echo $newsArticle;?>
</div> 

<script type="text/javascript" language="Javascript"> 
document.observe("dom:loaded", function() { 
$$('.article-images a').each(function(a) { 
Event.observe(a, 'click', function(e) { 
Event.stop(e); 
Overlay.lightbox(a.href, "Image is loading"); 
}); 
}); 

$$('a.article-177').each(function(a) { 
a.replace(a.innerHTML); 
}); 
}); 
</script> 
 

</div> 

</div> 
</div> 

<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>