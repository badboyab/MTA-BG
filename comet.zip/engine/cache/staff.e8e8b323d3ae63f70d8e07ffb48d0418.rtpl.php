<?php if(!class_exists('raintpl')){exit;}?><div id="container">
	<div id="content" style="position: relative" class="clearfix">

		<div id="column2" class="column">
		
			<div class="habblet-container"> 
				<div class="cbb clearfix red"> 
					<h2 class="title">Fondateurs</h2> 
					<div class="box-content"> 
						<div style="align:left;">
							<?php echo lightcms::drawStaffPageForRank('7'); ?>
						</div>
					</div>
				</div> 
			</div>
			
			<div class="habblet-container"> 
				<div class="cbb clearfix red"> 
					<h2 class="title">Managers</h2> 
					<div class="box-content"> 
						<div style="align:left;">
							<?php echo lightcms::drawStaffPageForRank('4'); ?>
						</div>
					</div>
				</div> 
			</div>
		</div>

		<div id="column2" class="column">

		<div class="habblet-container"> 
			<div class="cbb clearfix red"> 
				<h2 class="title">Administrateurs</h2> 
				<div class="box-content"> 
					<div style="align:left;">
						<?php echo lightcms::drawStaffPageForRank('6'); ?>
					</div>
				</div>
			</div> 
		</div>

		</div>

		<div id="column2" class="column">

		<div class="habblet-container"> 
			<div class="cbb clearfix red"> 
				<h2 class="title">Modérateurs</h2> 
				<div class="box-content"> 
					<div style="align:left;">
						<?php echo lightcms::drawStaffPageForRank('5'); ?>
					</div>
				</div>
			</div> 
		</div>

		</div>
		
		<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
	</div>
</div>