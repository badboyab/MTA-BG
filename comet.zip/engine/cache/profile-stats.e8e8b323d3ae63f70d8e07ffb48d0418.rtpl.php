<?php if(!class_exists('raintpl')){exit;}?><div class="habblet-container"> 
<div class="cbb clearfix red"> 
 
<h2 class="title">Mes statistiques</h2> 
<div class="box-content">
	<img src='https://habboworld.fr/swf/habbo-imaging/avatarimage?figure=<?php echo $look;?>&gesture=sml&size=m' align='left'> 
	<div style="align:left;">
			<?php echo $online_status;?> <b><?php echo $username;?></b> <br /> 
			<i><?php echo $motto;?></i><br /> <br />
			
			Nombre de Credits: <?php echo $credits;?> <br />
			Nombre de Pixels: <?php echo $pixels;?> <br />
			Nombre d'amis: <?php echo $friends;?> <br />
			Registered: <?php echo $registered;?>
	</div>
</div> 

</div> 
</div>
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>