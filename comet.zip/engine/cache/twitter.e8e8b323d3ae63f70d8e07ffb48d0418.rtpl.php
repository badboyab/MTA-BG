<?php if(!class_exists('raintpl')){exit;}?>			<div class="habblet-container"> 
				<div class="cbb clearfix red"> 
					<h2 class="title">Twitter Habboworld</h2> 
					<div class="box-content"> 
						<div style="align:left;">
							<a class="twitter-timeline"
							  data-widget-id="600720083413962752"
							  data-tweet-limit="2"
							  href="https://twitter.com/habboworldFR1"
							  data-screen-name="HabboworldFR1">Tweets par @HabboworldFR1</a>
						</div>
					</div>
				</div> 
			</div>
			<script type='text/javascript'>
			$(document).ready(function(){
			  $(".tweet").tweet({
				username: "<?php echo $twitteraccount;?>",
				count: 4
			  });
			});
			</script>
			<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
			<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>