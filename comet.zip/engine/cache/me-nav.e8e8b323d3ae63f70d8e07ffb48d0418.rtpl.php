<?php if(!class_exists('raintpl')){exit;}?><div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
	<ul>
		<?php if( defined('MeTabSelected') ){ ?>
			<li class="selected">
				Accueil
			</li>
		<?php }else{ ?>
		<li class="">
			<a href="<?php echo $www;?>/me">Accueil</a>
		<?php } ?>
		
		<?php if( defined('ProfileTabSelected') ){ ?>
		<li class="selected">
			Mettre à jour mon mot de passe
		</li>
		<?php }else{ ?>
		</li>
    		<li class="">
				<a href="<?php echo $www;?>/profile">Paramètres du compte</a>
    		</li>
		<?php } ?>
		
		<?php if( defined('UserProfileTabSelected') ){ ?>
		<li class="selected last">
			Mon profil
		</li>
		<?php }else{ ?>
		</li>
    		<li class=" last">
				<a href="<?php echo $www;?>/user/<?php echo $username;?>">Mon profil</a> (Non lu: <?php echo lightcms::getUnreadCount(USER_ID); ?>)
    		</li>
		<?php } ?>
	</ul>
    </div>
</div>