<?php if(!class_exists('raintpl')){exit;}?><html xmlns="https://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="https://opengraphprotocol.org/schema/" xmlns:fb="https://www.facebook.com/2008/fbml">
<head>

<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><?php echo $sitename;?> - <?php echo $pagetitle;?></title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>

<link rel="shortcut icon" href="<?php echo $www;?>/images/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="<?php echo $www;?>/images/web-gallery/static/styles/common.css" type="text/css" />
<script src="<?php echo $www;?>/images/web-gallery/static/js/libs2.js" type="text/javascript"></script>
<script src="<?php echo $www;?>/images/web-gallery/static/js/visual.js" type="text/javascript"></script>
<script src="<?php echo $www;?>/images/web-gallery/static/js/libs.js" type="text/javascript"></script>
<script src="<?php echo $www;?>/images/web-gallery/static/js/common.js" type="text/javascript"></script>
<script src="<?php echo $www;?>/images/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>
<script src="<?php echo $www;?>/images/web-gallery/static/js/minimail.js" type="text/javascript"></script>
<script src="<?php echo $www;?>/images/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo $www;?>/images/web-gallery/styles/style.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $www;?>/images/web-gallery/styles/buttons.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $www;?>/images/web-gallery/styles/boxes.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $www;?>/images/web-gallery/styles/tooltips.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $www;?>/images/web-gallery/static/styles/lightweightmepage.css" type="text/css" />
<script src="<?php echo $www;?>/images/web-gallery/static/js/lightweightmepage.js" type="text/javascript"></script>

<!--[if IE 8]>
<link rel="stylesheet" href="<?php echo $www;?>/images/web-gallery/static/styles/ie8.css" type="text/css" />
<![endif]-->
<!--[if lt IE 8]>
<link rel="stylesheet" href="<?php echo $www;?>/images/web-gallery/static/styles/ie.css" type="text/css" />
<![endif]-->
<!--[if lt IE 7]>
<link rel="stylesheet" href="<?php echo $www;?>/images/web-gallery/static/styles/ie6.css" type="text/css" />
<script src="<?php echo $www;?>/images/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
<script type="text/javascript">
try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
</script>

<style type="text/css">
body { behavior: url(/images/csshover.htc); }
</style>
<![endif]-->

<meta name="build" content="Zap Hotel" />
</head>