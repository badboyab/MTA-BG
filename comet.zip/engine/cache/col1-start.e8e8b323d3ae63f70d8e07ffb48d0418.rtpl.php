<?php if(!class_exists('raintpl')){exit;}?><div id="container">
<div id="content" style="position: relative" class="clearfix">
<div id="column1" class="column">