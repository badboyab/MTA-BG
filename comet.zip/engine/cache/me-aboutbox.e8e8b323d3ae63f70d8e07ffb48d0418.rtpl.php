<?php if(!class_exists('raintpl')){exit;}?><div id="container">
	<div id="content" style="position: relative" class="clearfix">

    <div id="wide-personal-info">

    <div id="habbo-plate">
            <a href="<?php echo $www;?>/profile">
            <img alt="<?php echo $Username;?>" src="https://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $Look;?>&gesture=sml&size=m"/>
        </a>
    </div>

    <div id="name-box" class="info-box">
        <div class="label">Pseudo:</div>
        <div class="content"><?php echo $Username;?></div>
    </div>
    <div id="motto-box" class="info-box">
        <div class="label">Mission:</div>
        <div class="content"><?php echo $Motto;?> - <a href='<?php echo $www;?>/profile/basic_settings'>Modifier mot de passe</a></div>
    </div>
    <div id="last-logged-in-box" class="info-box">
        <div class="label">Solde du compte</div>
        <div class="content"> <?php echo $Credits;?> Crédits & <?php echo $Pixels;?> Pixels</div>
    </div>

<div class="enter-hotel-btn">
    <div class="open enter-btn">
            <a href="<?php echo $www;?>/client" target="eaac8f36e6e5ed7892d37b2ea32c4108c6719407" onclick="HabboClient.openOrFocus(this); return false;">Entrer sur <?php echo $sitename;?><i></i></a>
        <b></b>
    </div>
</div>

</div>
