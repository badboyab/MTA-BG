<?php if(!class_exists('raintpl')){exit;}?><?php if( maintenance == 1 ){ ?>
	<div style='color:red; font-size:15px;'><?php echo $sitename;?> est actuellement en maintenance.</div>
<?php } ?>
<style type="text/css">
body { background-image: url('<?php echo $www;?>/images/bg.png') !important; }
h1 a { height: 52px !important; width: 200px !important; background-image: url('<?php echo $www;?>/images/logo.png') !important; }
</style>

<body id="home" class=" ">
<div id="overlay"></div>


<div id="header-container">
	<div id="header" class="clearfix">
		<h1><a href="<?php echo $www;?>/"></a></h1>


  <div id="subnavi"> 
			<div id="subnavi-user"> 
							<ul>
					<li id="myfriends"><a href="#"><span></span></a><span class="r"></span></li> 
					<li id="mygroups"><a href="#"><span></span></a><span class="r"></span></li> 
					<li id="myrooms"><a href="#"><span></span></a><span class="r"></span></li> 
				</ul> 
						</div> 
			<div id="subnavi-search"> 
                <div id="subnavi-search-upper"> 
                <ul id="subnavi-search-links"> 
                    <li><a href="http://habboworld.fr" target="habbohelp" onclick="openOrFocusHelp(this); return false">Aide</a></li> 
					<li><a href="<?php echo $www;?>/account/signout" class="userlink" id="signout">Déconnexion</a></li> 
				</ul> 
                </div> 
            </div> 

    <div id="to-hotel">
                <a href="<?php echo $www;?>/client" class="new-button green-button" target="_blank"><b>Entrer sur <?php echo $sitename;?></b><i></i></a>
    </div>
</div>

<ul id="navi">
	<?php if( defined('MeSelected') ){ ?>
   	<li class="selected">
			<strong>
				<?php echo $Username;?>
			</strong>
			<span></span>
		</li>
	<?php }else{ ?>
		<li>
			<a href="/me"><?php echo $Username;?></a>
			<span></span>
		</li>
	<?php } ?>
	
	<?php if( defined('CommunitySelected') ){ ?>
   	<li class="selected">
			<strong>
				Communauté
			</strong>
			<span></span>
		</li>
	<?php }else{ ?>
		<li>
			<a href="/community">Communauté</a>
			<span></span>
		</li>
	<?php } ?>
	<?php if( defined('VipSelected') ){ ?>
   	<li class="selected">
			<strong>
				Boutique VIP
			</strong>
			<span></span>
		</li>
	<?php }else{ ?>
		<li>
			<a href="/buyvip">Boutique VIP</a>
			<span></span>
		</li>
	<?php } ?>
		<?php if( USER_RANK >= 6 ){ ?>
			<?php if( defined('HkSelected') ){ ?>
			<li class="selected">
				<strong>Housekeeping</strong>
				<span></span>
			<?php }else{ ?>
			<li>
				<a href="<?php echo $www;?>/admin/index.php?_page=dashboard" target="_blank">Administration</a>
				<span></span>
			</li>
			<?php } ?>
		<?php } ?>
</ul>

        <div id="habbos-online"><div class="rounded"><span><?php echo $users_online;?></span></div></div>
	</div>
</div>