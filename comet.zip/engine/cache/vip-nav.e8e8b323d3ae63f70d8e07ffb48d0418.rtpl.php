<?php if(!class_exists('raintpl')){exit;}?><div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
	<ul>
		<?php if( defined('VipTabSelected') ){ ?>
			<li class="selected last">
				Boutique VIP
			</li>
		<?php }else{ ?>
		<li class="last">
			<a href="<?php echo $www;?>/vip">Boutique VIP Habboworld</a>
		<?php } ?>
	</ul>
    </div>
</div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">