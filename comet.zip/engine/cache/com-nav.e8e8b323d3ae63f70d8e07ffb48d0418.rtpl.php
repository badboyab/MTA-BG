<?php if(!class_exists('raintpl')){exit;}?><div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
	<ul>
		<?php if( defined('CommunityTabSelected') ){ ?>
		<li class="selected">
			Communauté
		</li>
		<?php }else{ ?>
		<li class="">
			<a href='<?php echo $www;?>/community'>Communauté</a>
		</li>
		<?php } ?>	
		<?php if( defined('ArticleTabSelected') ){ ?>
		<li class="selected">
			 Mes articles
		</li>
		<?php }else{ ?>
		<li class="">
		<a href='<?php echo $www;?>/articles'>Mes articles</a>
		</li>
		<?php } ?>
		<?php if( defined('StaffPageSelected') ){ ?>
		<li class="selected last">
			 Staffs
		</li>
		<?php }else{ ?>
		<li class="last">
		<a href='<?php echo $www;?>/staff'>L'équipe des Staffs</a>
		</li>
		<?php } ?>
	</ul>
    </div>
</div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">