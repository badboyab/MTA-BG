<?php if(!class_exists('raintpl')){exit;}?><div class="habblet-container" style="float:left; width: 560px;"> 
<div class="cbb clearfix settings"> 
 
<h2 class="title">Modifier votre <?php echo $shortname;?> mot de passe</h2> 
<div class="box-content"> 
	<div style="align:left;">
		Bienvenue sur la page de modification de votre mot de passe. Pour changer de mot de passe, suivre les différentes étapes.
		<br /> <br />
		<?php echo $errorSpace;?> <?php echo $successSpace;?>
		<form method='post'>
			<strong>Ancien mot de passe</strong> <br />
			<input type='password' maxlength='32' name='CurrentPass'> <br />
			<br />
			<strong>Nouveau mot de passe</strong> <br />
			<input type='password' maxlength='32' name='NewPass'> <br />
			<br />
			<strong>Entrer une nouvelle fois votre nouveau mot de passe</strong> <br />
			<input type='password' maxlength='32' name='VerifyPass'> <br />
			<br />
			<input type='submit' name='UpdatePassword' value='Mettre à jour'>
		</form>
	</div>
</div> 

</div> 
</div> 
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>