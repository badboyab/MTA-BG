<?php if(!class_exists('raintpl')){exit;}?><div class="habblet-container"> 
<div class="cbb clearfix green"> 
 
<h2 class="title">Badges</h2> 
<div class="box-content"> 
	<?php echo lightcms::displayUserBadges(_pageId); ?>
</div> 

</div> 
</div>
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>