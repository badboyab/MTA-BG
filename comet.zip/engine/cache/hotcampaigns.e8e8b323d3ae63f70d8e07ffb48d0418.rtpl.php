<?php if(!class_exists('raintpl')){exit;}?><div class="habblet-container ">		
<div class="cbb clearfix blue "> 

<h2 class="title">Mes actualités</h2> 

<div id="hotcampaigns-habblet-list-container"> 

<ul id="hotcampaigns-habblet-list"> 
<?php echo lightcms::getHotCampaigns(); ?>
</ul>

</div>
</div>
</div>
