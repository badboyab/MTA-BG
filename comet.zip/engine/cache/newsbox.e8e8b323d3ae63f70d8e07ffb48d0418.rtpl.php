<?php if(!class_exists('raintpl')){exit;}?><div class="habblet-container news-promo">		
	<div class="cbb clearfix notitle "> 				
		<div id="newspromo"> 
		
        <div id="topstories"> 
		<?php echo lightcms::getMainStories('3'); ?>
		</div>
        <ul class="widelist"> 		
		<?php echo lightcms::getSubStories(); ?>
            <li class="last"><a href="/articles">Plus d'articles &raquo;</a></li>            
        </ul>
</div> 

<script type="text/javascript"> 
	document.observe("dom:loaded", function() { NewsPromo.init(); });
</script> 
	</div>
<div class="habblet-container ">			
	</div>
				</div> 
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>