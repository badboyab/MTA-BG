<?php if(!class_exists('raintpl')){exit;}?><div class="habblet-container"> 
<div class="cbb clearfix white"> 
 
<h2 class="title">A propos de la boutique VIP d'Habboworld</h2> 
<div class="box-content"> 
	<div style="align:left;">
	C'est ici que vous pouvez acheter votre abonnement VIP. <b>Pour devenir VIP sur Habboworld, il te suffit de payer 50 diamants.</b>.
	</div>
</div> 

</div> 
</div>
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>