<?php



	require_once "required.php";
	
	if(!$users->isLogged()) {
		header ("Location: " . WWW . "/");
		exit;
	}
		
	define('MeSelected', true);
	define('ProfileTabSelected', true);
	//define('points', $users->userVar(USERNAME, 'points'));
	
	$tpl->assign('pagetitle', 'Account settings');
	$tpl->assign('fr_checkvalues', null);
	$tpl->assign('trd_checkvalues', null);
	$tpl->assign('errorSpace', null);
	$tpl->assign('successSpace', null);
	$tpl->assign('Username', USERNAME);
	//$tpl->assign('Points', points);
	$tpl->assign('username', USERNAME);
	
	$tpl->draw('cms-head');
	$tpl->draw('cms-generictop');
	$tpl->draw('me-nav');
	
	$_proPage = 'pass-settings';
	define('selected', $_proPage);
	
	if(selected == 'pass-settings') {
		if(isset($_POST["UpdatePassword"])) {
			$currPass = $users->userVar(USERNAME, 'password');
			$entPass = $users->userHash($_POST["CurrentPass"], USERNAME);
			if($entPass == $currPass) {
				$newPass = $users->userHash($_POST["NewPass"], USERNAME);
				$verPass = $users->userHash($_POST["VerifyPass"], USERNAME);
				if($newPass == $verPass) {
					$db->real_query("UPDATE `players` SET `password` = '" . $newPass . "' WHERE `username` = '" . USERNAME . "'");
					$_SESSION["Username"] = USERNAME;
					$_SESSION["HashedPassword"] = $newPass;
					$tpl->assign('successSpace', $light->successMessage('Your password has been successfully changed.'));
				}
				else {
					$tpl->assign('errorSpace', $light->errorMessage('Your new passwords do not match.'));
				}
			}
			else {
				$tpl->assign('errorSpace', $light->errorMessage('Your current password is incorrect.'));
			}
		}
	}
	
	$tpl->draw('col1-start');
	$tpl->draw('profile-nav');
	$tpl->draw('col-end');
	$tpl->draw('col2-start');
	$tpl->draw(selected);
	$tpl->draw('col-end');
	$tpl->draw('bottom');
	$tpl->draw('footer');
	
?>