<?php


	
	require_once "required.php";
	
	if(!$users->isLogged()) {
		header ("Location: " . WWW . "/");
	}
	
	define('CommunitySelected', true);
	define('CommunityTabSelected', true);
	
	$tpl->assign('pagetitle', 'Community');
	
	$tpl->draw('cms-head');
	$tpl->draw('cms-generictop');
	$tpl->draw('com-nav');
	$tpl->draw('col1-start');
	$tpl->draw('randomhabbos');
	$tpl->draw('twitter');
	$tpl->draw('col-end');
	$tpl->draw('col2-start');
	$tpl->draw('newsbox');
	$tpl->draw('col-end');
	$tpl->draw('bottom');
	$tpl->draw('footer');
	
?>
	