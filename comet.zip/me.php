<?php


	
	require_once "required.php";
	
	if(!$users->isLogged()) {
		header ("Location: " . WWW . "/");
		exit;
	}
	
	define('MeSelected', true);
	define('MeTabSelected', true);
	
	$tpl->assign('Credits', number_format($users->userVar(USERNAME, 'credits')));
	$tpl->assign('Pixels', number_format($users->userVar(USERNAME, 'activity_points')));
	$tpl->assign('Look', $users->userVar(USERNAME, 'figure'));
	$tpl->assign('Motto', $users->userVar(USERNAME, 'motto'));
	$tpl->assign('username', USERNAME);
	$tpl->assign('pagetitle', 'Home');
	
	$tpl->draw('cms-head');
	$tpl->draw('cms-generictop');

	$tpl->draw('me-nav');
	$tpl->draw('me-aboutbox');
	
	$tpl->draw('col1-start');
	$tpl->draw('hotcampaigns');
	$tpl->draw('twitter');
	$tpl->draw('col-end');
	$tpl->draw('col2-start');
	$tpl->draw('newsbox');
	$tpl->draw('col-end');

	$tpl->draw('bottom');
	$tpl->draw('footer');
	
?>