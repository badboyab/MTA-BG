<?php



	require_once "required.php";
	
	if(!$users->isLogged()) {
		header ('Location: ' . WWW . '/');
		exit;
	}
	
	define('VipTabSelected', true);
	define('VipSelected', true);
	
	$tpl->assign('pagetitle', 'VIP Shop');
	
	$tpl->draw('cms-head');
	$tpl->draw('cms-generictop');
	$tpl->draw('vip-nav');
	
	$tpl->draw('col1-start');
	$tpl->draw('vip-aboutdeals');
	$tpl->draw('col-end');
	$tpl->draw('col2-start');
	$tpl->draw('vip-buy');
	$tpl->draw('col-end');
	
	$tpl->draw('footer');

?>