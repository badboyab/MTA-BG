<?php



	require_once "required.php";
	
	unset($_SESSION["Username"]);
	unset($_SESSION["HashedPassword"]);
	header ("Location: " . WWW . "/");
	exit;

?>