<?php


	
	require_once "required.php";
	
	if(!$users->isLogged()) {
		header ("Location: " . WWW . "/");
	}
	else if(isset($_GET["e"])) {
		$e = $db->real_escape_string($_GET["e"]);
		if($e == "flash_client_error") {
			echo "<font face='verdana> <center> <b>" . $light->site_name . " - Client Error</b><hr>";
			if($light->flash_client_dump) {
				foreach($_POST as $key => $val) {
					echo $key . "=" . $val . " . <br />";
				}
			}
		}
		exit;
	}
	else if($light->pin_enabled == true && !isset($_SESSION["Pincode_Passed"]) && $users->userVar(USERNAME, 'rank') >= 6) {
		header ("Location: " . WWW . "/client_denied");
	}
	
	/*$allowed = array('jonteh', 'gosan', 'corey', 'moogly', 'pyramids', 'kid');
	if(!in_array(strtolower(USERNAME), $allowed)) exit;*/
	
	$sso = $users->genSSO();
	
	$db->real_query("UPDATE players SET last_ip = '" . $_SERVER["REMOTE_ADDR"] . "', auth_ticket = '" . $sso . "' WHERE id = '" . USER_ID . "'");
	
	$tpl->assign('connection_info_host', $light->connection_info_host);	
	$tpl->assign('connection_info_port', $light->connection_info_port);
	$tpl->assign('variables', $light->variables);
	$tpl->assign('texts', $light->texts);
	$tpl->assign('override_texts', $light->override_texts);
	$tpl->assign('productdata', $light->productdata);
	$tpl->assign('furnidata', $light->furnidata);
	$tpl->assign('baseurl', $light->baseurl);
	$tpl->assign('habbo_swf', $light->habbo_swf);
	$tpl->assign('loadingtext', $light->loadingtext);
	$tpl->assign('sso', $sso);
	$tpl->draw('client');
	
?>