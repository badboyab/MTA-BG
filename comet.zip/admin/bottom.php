			<div class="Footer">
				<div class="LeftText">Copyright &copy; 2017 - 2018 Habboworld Hotel.</div>
				<div class="RightText">Réalisé par Mirlyn</div>
			</div>
			</div>
		</div>
	</body>
</html>