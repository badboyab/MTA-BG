<html>
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Administration</title>
		<script src="style/magic.js" type="text/javascript"></script>
		<script src="style/cufon-yui.js" type="text/javascript"></script>
		<script src="style/ubuntu.font.js" type="text/javascript"></script>
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Ubuntu:regular,bold&subset=Latin">
		<link rel="stylesheet" type="text/css" href="style/style.css">
		<script type="text/javascript">
			Cufon.replace('h1');
			Cufon.replace('h2');
			Cufon.replace('h3');
		</script>
	</head>
	
		<body>
		<div class="wrapper ">
			<div class="subwrapper">
			<div class="HeadBar"><h1><a href="index.php?_page=dashboard">Habboworld<strong>CMS</strong></a></h1></div>
			
			<div class="Menu ">
				
<ul>
	
				<li>Bienvenue, <?php if(HK_Username == "Moogly" || HK_Username == "Jonty") { echo "Heisenberg"; } else { echo HK_Username; } ?></li>
	        
</ul>

			</div>
			
			
			<div class="SubMenu ">
				
			<div class="Box">
				<div class="Title">Menu</div>
				<div class="Content">
					
					- <a href='?_page=dashboard'>Tableau de bord</a> <br />
					- <a href='?_page=viewstaff'>Visualiser les membres staffs</a> <br />
					- <a href='http://zaphotel.net/me'>Retourner sur Habboworld</a> <br />
					- <a href='logout.php'>Déconnexion</a>
							
				</div>
			</div>
			
			<div class="Box">
				<div class="Title">Gestionnaire des utilisateurs</div>
				<div class="Content">
					
					- <a href='?_page=ipcheck'>Vérifier une adresse IP</a> <br />
					- <a href='?_page=paygol'>Vérifiez le code PIN de PayGol</a> <br />
					- <a href='?_page=makevip'>Ajouter un utilisateur VIP</a> <br />
					- <a href='?_page=edituser'>Modifier le compte des utilisateurs</a> <br />
					- <a href='?_page=changepass'>Changer le mot de passe</a> <br />
					- <a href='?_page=extsignon'>Connectez-vous en tant qu'utilisateur</a> <br />
							
				</div>
			</div>
			
			<div class="Box">
				<div class="Title">Gestionnaire de bannissement</div>
				<div class="Content">
					
					- <a href='?_page=banlist'>Visualiser la liste des bans</a> <br />
					- <a href='?_page=banuser'>Bannir un utilisateur</a> <br />
					<?php if(hasFuse(HK_Username, 'pornban')) { ?>
					<?php } ?>
							
				</div>
			</div>

			<div class="Box">
				<div class="Title">Gestionnaire de contenu Habboworld</div>
				<div class="Content">
					- <a href='?_page=managenews'>Gérer les articles</a> <br />
					- <a href='?_page=writenews'>Ecrire un nouvel article</a> <br />
					- <a href='?_page=viewbadgedefs'>Visualiser la liste des badges</a> <br />
					- <a href='?_page=addbadgedef'>Ajouter un badge</a> <br />
				</div>
			</div>
			<?php if(hasFuse(HK_Username, 'site_manage')) { ?>
			<div class="Box">
				<div class="Title">Configuration Habboworld</div>
				<div class="Content">
					
					- <a href='?_page=systemconfig'>Habboworld CMS Configuration</a> <br />
					- <a href='?_page=emushutdown'>Couper le serveur Habboworld</a> <br />
					- <a href='?_page=maintenance'>Maintenance Habboworld</a> <br />
					- <a href='?_page=advancedaccedit'>Editeur de compte avancé</a> <br />
							
				</div>
			</div>
			<?php } ?>
			
			<div class="Box">
				<div class="Title">Système de Santé</div>
				<div class="Content">
				<?php
					if($getstats = $db->query("SELECT * FROM server_status")) {
						while($stats = $getstats->fetch_assoc()) {
							$rooms_loaded = $stats['active_rooms'];
							$users_online = number_format($stats['active_players']);
						}
					}
				?>
				Utilisateurs connectés: <?php echo $users_online; ?> <br />
				Appart chargés: <?php echo $rooms_loaded; ?>
				</div>
			</div>
        
			</div>
