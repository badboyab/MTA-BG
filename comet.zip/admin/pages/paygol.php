<?php if(!defined('In_ZapHK')) { exit; } ?>

<div class="MainContentBox">
	<div class="Box">
		<div class="Title">Check PayGol PIN Code</div>
		<div class="Content" align="left;">
			Has a user confronted you about a PayGol PIN? Confirm if it is legitimate here. Get the users cellphone number and post it here. <br /> <br />
			<iframe src="http://www.paygol.com/plugins/view_transactions?key=9ee4fb3c-a54b-1030-8ee3-912607b268f1&language=en" width="400" height="250" frameborder="0" scrolling="no"> </iframe>
			<br />
		</div>
	</div>
</div>