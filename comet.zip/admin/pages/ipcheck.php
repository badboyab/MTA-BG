<?php if(!defined('In_ZapHK')) { exit; } ?>

<div class="MainContentBox">
	<div class="Box">
		<div class="Title">Vérifier l'adresse IP d'un utilisateur</div>
		<div class="Content" align="left;">
		Vous pouvez vérifier les comptes utilisateurs ici si vous avez un soupçon ou un doute concernant leur activités au sein de l'hôtel ou bien s'ils cachent quelque chose. Il est également impératif d'obtenir l'adresse IP de l'utilisateur pour le bannir définitivement si besoin. <br />
		<br />
		<form method='post'>
			Pseudo <br />
				<input type='text' name='username_check'> <br />
			<br />
			Adresse IP <br />
				<input type='text' name='ipaddress_check'> <br />
			<br />
			<input type='submit' value='Check IP/Username'>				
		</form>
		<?php
			if(isset($_POST["username_check"]) && empty($_POST["ipaddress_check"])) {
				$username = $db->real_escape_string($_POST["username_check"]);
				if($getinfo = $db->query("SELECT last_ip, rank FROM players WHERE username = '" . $username . "'")) {
					while($drow = $getinfo->fetch_assoc()) {
						$last_ip = $drow['last_ip'];
						$rank = $drow['rank'];
					}
					if($rank >= HK_Rank && $username != HK_Username) {
						$output = "<br /> <br />You are not permitted to view that users IP address or IP address history.";
					}
					else if($searchfor = $db->query("SELECT username,rank,email,last_ip,online,last_online FROM players WHERE last_ip = '" . $last_ip . "'")) {
						$output = "<br />
								<table>
									<tr>
										<td>Username</td>
										<td>Rank</td>
										<td>E-mail</td>
										<td>Last IP used</td>
										<td>Online status</td>
										<td>Last online</td>
									</tr>";
						while($urow = $searchfor->fetch_assoc()) {
							$output .= "<tr>";
							$output .= "<td>" . $urow['username'] . "</td>";
							$output .= "<td>" . $urow['rank'] . "</td>";
							$output .= "<td>" . $urow['email'] . "</td>";
							$output .= "<td>" . $urow['last_ip'] . "</td>";
							if($urow['online'] == "1") {
								$output .= "<td style='color:green'>Online</td>";
							}
							else {
								$output .= "<td style='color:red'>Offline</td>";
							}
							$output .= "<td>" . date('d/M/y', $urow['last_online']) . "</td>";
							$output .= "<tr>";
							
						}
						$output .= "</table>";
						
						
					}
					echo $output;
				}
			}
			else if(isset($_POST["ipaddress_check"])) {
				$ipchecked = $db->real_escape_string($_POST["ipaddress_check"]);
				if($search = $db->query("SELECT username,rank,email,last_ip,online,last_online FROM players WHERE last_ip = '" . $ipchecked . "'")) {
					$output = "<br />
									<table>
									<tr>
										<td>Username</td>
										<td>Rank</td>
										<td>E-mail</td>
										<td>Last IP used</td>
										<td>Online status</td>
										<td>Last online</td>
									</tr>";
					while($irow = $search->fetch_assoc()) {
						if($irow['rank'] >= HK_Rank && $irow['username'] != HK_Username) {
							$output = "<br /> <br />You are not permitted to view that users IP address or IP address history.";
						}
						else {
							$output .= "<tr>";
							$output .= "<td>" . $irow['username'] . "</td>";
							$output .= "<td>" . $irow['rank'] . "</td>";
							$output .= "<td>" . $irow['email'] . "</td>";
							$output .= "<td>" . $irow['last_ip'] . "</td>";
							if($irow['online'] == "1") {
								$output .= "<td style='color:green'>Online</td>";
							}
							else {
								$output .= "<td style='color:red'>Offline</td>";
							}
							$output .= "<td>" . date('d/M/y', $irow['last_online']) . "</td>";
							$output .= "</tr>";
						}
					}
					$output .= "</table>";
					echo $output;
				}
			}
				
		?>	
		</div>
	</div>
</div>