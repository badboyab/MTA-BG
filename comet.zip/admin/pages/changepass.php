<?php if(!defined('In_ZapHK')) { exit; } if(!hasFuse(HK_Username, 'adv_edit')) { exit; } ?>

<div class="MainContentBox">
	<div class="Box">
		<div class="Title">Modifier le mot de passe d'un utilisateur</div>
		<div class="Content" align="left;">
			Vous pouvez modifier le mot de passe d'un utilisateur ici. En cas d'urgence, merci de bien vouloir vous adresser si besoin aux membres staffs avant de réaliser cette manipulation.
			<br />
			<br />
			<form method='post'>
				Pseudo <br /> <input type='text' name='username'> <br /><br />
				Mot de passe <br /> <input type='text' name='password'> <br /><br />
				<input type='submit' value='Change password'>
			</form>
			
			<?php
			if(isset($_POST["username"]) && isset($_POST["password"])) {
				$username = filter($_POST["username"]);
				$password = filter($_POST["password"]);
				$combined = sha1(md5($password) . strtolower($username));
				if($users->userVar($username, 'rank') > HK_Rank) {
					echo "You cannot change this users password.";
				}
				else {
					$db->real_query("UPDATE players SET password = '" . $password . "' WHERE username = '" . $username . "'");
					echo $username . "'s password has been set to " . $password;
				}
			}
			?>
		</div>
	</div>
</div>