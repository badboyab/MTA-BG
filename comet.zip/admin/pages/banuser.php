<?php if(!defined('In_ZapHK')) { exit; } $modified = false; ?>

<div class="MainContentBox">
	<div class="Box">
		<div class="Title">Bannir un utilisateur</div>
		<div class="Content" align="left;">
			C'est ici que vous pouvez chosiir de bannir un utilisateur de l'hôtel en indiquant la durée et le motif du bannissement. <br /><br />
			
			Pre-defined: <br />
			<form method='post'>
				<select name='predefinedSeconds'>
					<option value='94608000'>3 ans (Permanent)</option>
					<option value='63072000'>2 ans</option>
					<option value='31536000'>1 an</option>
					<option value='15724800'>6 mois</option>
					<option value='7862400'>3 mois</option>
					<option value='2419200'>4 semaines</option>
					<option value='1209600'>2 semaines</option>
					<option value='604800'>1 semaine</option>
					<option value='259200'>3 jours</option>
					<option value='86400'>24 heures</option>
					<option value='43200'>12 heures</option>
					<option value='7200'>2 heures</option>
					<option value='601'>10 Minutes (avertissement)</option>
				</select>
				<br />
				<br />
				ou en secondes: <br />
				<input type='text' name='manualSeconds'> <br />
				<br />
				<br />
				Type ban: <br />
				<select name='banType'>
					<option value='ip'>Adresse IP</option>
					<option value='user'>Pseudo</option>
				</select>
				<br />
				<br />
				Pseudo/IP: <br />
				<input type='text' name='valueToBan'> <br />
				<br />
				Raison: <br />
				<input type='text' name='reason'> <br />
				<br /> <br />
				<input type='submit' value='Ban user' name='banSubmit'>
			</form>
			
			<?php
				if(isset($_POST["valueToBan"]) && isset($_POST["banSubmit"])) {
					if(!isset($_POST["manualSeconds"])) {
						$seconds = $_POST["predefinedSeconds"];
					}
					else if(isset($_POST["manualSeconds"]) && $_POST["manualSeconds"] < 94608001) {
						if(is_numeric($_POST["manualSeconds"])) {
							$seconds = $_POST["manualSeconds"];
						}
					}
					if($_POST["banType"] == "ip") {
						$params = 'sisissi';
					}
					else {
						$params = 'sssissi';
					}
						
					$bannedBy = HK_Username;
					$currentDate = date('d/m/Y H:i');
					$banTime = time() + $seconds;
					$banType = $db->real_escape_string($_POST["banType"]);
					$reason = $db->real_escape_string($_POST["reason"]);
					$userToBan = $db->real_escape_string($_POST["valueToBan"]);
						
					$db->real_query("INSERT INTO bans (bantype,value,reason,expire,added_by,added_date,appeal_state) VALUES ('" . $banType . "', '" . $userToBan . "', '" . $reason . "', '" . $banTime . "', '" . $bannedBy . "', '" . $currentDate . "', '0')");
						
					echo $_POST["valueToBan"] . " banned for " . $seconds . ".";
				}
			?>
		</div>
	</div>
</div>