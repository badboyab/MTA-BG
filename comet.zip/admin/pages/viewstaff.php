<?php if(!defined('In_ZapHK')) { exit; } ?>

<div class="MainContentBox">
	<div class="Box">
		<div class="Title">L'équipe des staffs de l'hôtel</div>
		<div class="Content" align="left;">
		
		<table>
		
		<tr>
			<td>Pseudo</td>
			<td>Rank actuel</td>
		</tr>
		<?php
			if($getstaff = $db->query("SELECT username,rank FROM players WHERE rank >= 6 ORDER BY rank DESC")) {
				while($staff = $getstaff->fetch_assoc()) {
					echo "<tr>
							<td>" . $staff['username'] . "</td>
							<td>" . $staff['rank'] . "</td>
						</tr>";
				}
			}
		?>
		</table>
		
		</div>
	</div>
</div>