<?php if(!defined('In_ZapHK')) { exit; } ?>

<div class="MainContentBox">
	<div class="Box">
		<div class="Title">Oups, page non trouvée !</div>
		<div class="Content" align="left;">
		Si une page manque à l'hôtel, merci de bien vouloir vous adresser aux techniciens de l'hôtel.
		</div>
	</div>
</div>