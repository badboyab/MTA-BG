<?php if(!defined('In_ZapHK')) { exit; } ?>

<div class="MainContentBox">
	<div class="Box">
		<div class="Title">Administration</div>
		<div class="Content" align="left;">
			Bienvenue sur la nouvelle administration d'Habboworld. C'est ici que vous pouvez réaliser les changements de l'hôtel. <br />
			L'accès à l'administration est exclusivement réservés aux administrateurs de l'hôtel.
		</div>
	</div>
</div>
