<?php

	if(!defined('In_ZapHK')) { exit; }
	if(isLogged()) {
		header ("Location: index.php?_page=dashboard");
		exit;
	}
	
	if(isset($_POST["Username"]) && isset($_POST["Password"])) {
		if(isAllowed($_POST["Username"], $_POST["Password"])) {
			$_SESSION["HK_Username"] = $db->real_escape_string($_POST["Username"]);
			$_SESSION["HK_HashedPass"] = hashPass($_POST["Password"], $_POST["Username"]);
			$_SESSION["Username"] = $_SESSION["HK_Username"];
			$_SESSION["HashedPassword"] = $_SESSION["HK_HashedPass"];
			
			header ("Location: index.php?_page=dashboard");
			exit;
		}
		else {
			die('Incorrect login.');
		}
	}

?>

Connexion à l'administration. <br />
<form method='post'>
	Pseudo: <input type='text' name='Username'> <br />
	Mot de passe: <input type='password' name='Password'> <br />
	<input type='submit' value='Log in'>
</form>