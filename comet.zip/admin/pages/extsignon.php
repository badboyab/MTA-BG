<?php if(!defined('In_ZapHK')) { exit; } ?>

<div class="MainContentBox">
	<div class="Box">
		<div class="Title">Connexion en tant qu'utilisateur</div>
		<div class="Content" align="left;">
			La connexion à un compte utilisateur peut être utile dans les situations où vous devez voir leur inventaire ou si leur compte est défectueux. <br />
			Ce système remplacera la session de votre site Web avec les informations d'identification de votre compte et vous déconnectera du site Web, mais pas du service d'entretien.. <br />
			<br />
			<form method='post'>
			Utilisateur connecté en tant que: <br />
			<input type='text' name='usernameext'> <br />
			<br />
			<input type='submit' value='Log in'>
			</form>
			<?php
			if(isset($_POST["usernameext"])) {
				$name = filter($_POST["usernameext"]);
				$pass = $users->userVar($name, 'password');
				$rank = $users->userVar($name, 'rank');
				if($rank < HK_Rank) {
					$_SESSION["Username"] = $name;
					$_SESSION["HashedPassword"] = $pass;
					echo "<br /><br />Successfully logged in as " . $name . " - click <a href='" . $light->site_url . "'/me' target='_blank'>here</a> to continue.";
				}
				else {
					echo "<br /><br />You are not allowed to log in as this user.";
				}
			}
			?>			
		</div>
	</div>
</div>
