<?php

	require_once "admin_required.php";
	require_once "pages/login.php";
	
?>