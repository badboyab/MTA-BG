<?php

ini_set('error_reporting', E_ALL);

session_start();
echo sha1(md5('lol!@#') . 'ryan');


if(isset($_GET['more_secret']))
{
	if($_GET['more_secret'] != 'n00b')
		exit;
	
	require_once "required.php";

	$badges = array("HC5",
					"TC1",
					"TC2",
					"TC3",
					"BTB",
					"SNW",
					"GLA",
					"GLB",
					"GLC",
					"GLD",
					"GLE",
					"GLF",
					"DU1",
					"DU2",
					"DU3",
					"GM1",
					"GM2",
					"GM3",
					"WHY",
					"AU1",
					"AU2",
					"AU3",
					"DS0",
					"DS1",
					"DS2",
					"DS3",
					"DS4",
					"DS5",
					"DS6",
					"DS7",
					"DSX",
					"CA4",
					"DEJ",
					"DEO"
					);
				
	
	foreach($badges as $badge)
	{
		$db->real_query("INSERT INTO badge_shop VALUES ('" . $badge . "', '10000')");
	}
}

if(isset($_GET['super_secret']))
{
	if($_GET['super_secret'] != 'fluff')
		exit;
	
	require_once "required.php";
	
	$getPages = $db->query("select * from catalog_pages where page_strings_2 like \"%%boon%%\"");

	while($data = $getPages->fetch_assoc())
	{
		$strings = $data['page_strings_2'];
		$strings = str_replace('Habboon', 'Zap', $strings);
			
		$db->query("UPDATE catalog_pages SET page_strings_2 = '" . $db->real_escape_string($strings) . "' WHERE id = " . $data['id']);
		echo $strings . "<br /><br />";
	}	
}

?>