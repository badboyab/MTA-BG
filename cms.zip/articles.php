<?php


require_once("engine/core.cms.php");

if(Loged == FALSE)
{
	header("Location: /");
	exit;
}
if(mysql_num_rows($chb) > 0) 
{
    header("Location: banned");
	exit;
}
if(MANTENIMIENTO == '1' && $myrow['rank'] < $Holo['maxrank']) 
{
    header("Location: maintenance");
	exit;
}

if(isset($_POST['comments'])) {

	$comment = $_POST['comments'];
	
	$checkuser = mysql_query("SELECT * FROM cms_comments_news WHERE added_by = '". $myrow['username'] ."' AND notice_id = '". $_GET['n'] ."'");

	if(empty($comment)) {
		$error = '<div id="error">Ne pas laisser le champ vide</div><br />';
	} 
	elseif(mysql_num_rows($checkuser) > 0) {
	    $error = '<div id="error">Un commentaire de nouvelles</div><br />';
	}
	else
	{
        mysql_query("INSERT INTO cms_comments_news (comentario, notice_id, added_by, added_date) VALUES ('". filtro($comment) ."', '". $_GET['n'] ."', '". $myrow['username'] ."', '". $date_full ."')");
        header("Location: /articles.php?n=". $_GET['n'] ."#comments");
	}
}

$do = $_GET['do'];
$key = $_GET['key'];
if($do == "dele"){
	$check = mysql_query("SELECT * FROM cms_comments_news WHERE id = '". $key ."' LIMIT 1");
	$check_user = mysql_fetch_assoc($check);
	if(mysql_num_rows($check) > 0 && $check_user['added_by'] == $myrow['username']){
		mysql_query("DELETE FROM cms_comments_news WHERE id = '". $key ."' LIMIT 1");
		header("Location: articles.php?n=". $_GET['n'] ."#comments");
	} else {
		$error = '<div id="error">Le commentaire ne peut pas être supprimé</div><br />';
	}
}
?>

<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link rel="shortcut icon" href="<?php echo $Holo['url']; ?>/favicon.ico" type="image/vnd.microsoft.icon" />
        <link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Maven+Pro' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Pinyon+Script' rel='stylesheet' type='text/css'>
        <script type="text/javascript" src="http://code.jquery.com/jquery-2.1.0.min.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo $Holo['url']; ?>/assets/css/general.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo $Holo['url']; ?>/assets/fonts/style.css" />

            <title><?php echo $Holo['name']; ?> > Articles</title>

    </head>
<body>
    
    
    <?php include_once("templates/header.php"); ?>

    
		
            <?php include("templates/add_articles_list.php"); ?>
			<?php include("templates/add_article.php"); ?>
			<?php include("templates/add_comments_news.php"); ?>
		


	
	
	<div class="space"></div>
	
    	<?php echo $Holo['footer']; ?>

</body>
</html>