<?php
require_once("../engine/core.cms.php");
require_once("../engine/hk_session.php");

if(Loged == false) { 
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(UserH == false) {
    header("Location: " . $Holo['url'] ."/".$Holo['panel']."");
	exit;
}
if($myrow['rank'] < $Holo['minhkr']) {
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(mysql_num_rows($chb) > 0) {
    header("Location: " . $Holo['url'] . "/banned");
	exit;
}
?>

<html>
    <head>
	<title>Administration de <?php echo $myrow['username']; ?></title>
<link rel="icon" type="image/png" href="<?php echo $Holo['url']; ?>/favicon.gif" />
      
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    </head>
	<style>
	body{
		background-color: #0B4C5F;
	}
	</style>
	
	
		
<body>

<?php include 'menu.php'; ?>

<div class="container">

	  <div class="row">
	  
      <a href="?log=cms">
	  <div class="col s12 m6">
        <div class="card-panel orange">
          <span class="white-text">
			<h5>Panneau de contrôle</h5>
			Les actions des autres staff dans le panel
          </span>
        </div>
      </div>
	  </a>
	  
	  <a href="?log=client">
	  <div class="col s12 m6">
        <div class="card-panel orange">
          <span class="white-text">
			<h5>Suivi client</h5>
			Les commandes utilisé au sein de l hotel
          </span>
        </div>
      </div>
	  </a>
      

      </div>
<?php
if($_GET['log'] == 'cms') {
?>
	        <div class="row">
        <div class="col s12 m12">
          <div class="card blue-white darken-1">
            <div class="card-content white-text">
              <p>

    
        <table width="870" border="1">
            <tr><td width="150"><b>Action</b></td><td width="150"><b>Message</b></td><td width="150"><b>Pseudo</b></td><td width="150"><b>Rank</b></td><td width="150"><b>Horaires</b></td></tr>
        </table>

        <?php
        if(isset($_POST['borrar']))
        {
            $borrarlogs = mysql_query("TRUNCATE TABLE stafflogs");
            if($borrarlogs) {
                echo '<!-- Logs borrados -->';
            } else {
                echo '<!-- Logs no borrados -->';
            }
        }
        $stafflogs = mysql_query("SELECT * FROM stafflogs ORDER BY id DESC LIMIT 300");
        while($logs = mysql_fetch_assoc($stafflogs)) {
            $user = mysql_query("SELECT id, username FROM users WHERE id ='". $logs['userid'] ."'");
            $id = mysql_fetch_assoc($user);
            $rango = mysql_query("SELECT * FROM ranks WHERE id ='". $logs['note'] ."'");
            $rank = mysql_fetch_assoc($rango);
?> 
    <table width="870" border="1">
        <tr>
            <td width="150"><?php echo $logs['action']; ?></td>
            <td width="150"><?php echo $logs['message']; ?></td>
            <td width="150"><?php echo $id['username']; ?></td>
            <td width="150"><?php echo $rank['name']; ?></td>
            <td width="150"><?php echo $logs['timestamp']; ?></td>
        </tr>
    </table>
<?php } ?>

			  </p>
            </div>
          </div>
        </div>
      </div>
<?php
} if($_GET['log'] == 'client') { 
?>
	        <div class="row">
        <div class="col s12 m12">
          <div class="card blue-white darken-1">
            <div class="card-content white-text">
              <p>

    
        <table width="870" border="1">
            <tr><td width="150"><b>Pseudo du staff</b></td><td width="150"><b>Message</b></td><td width="150"><b>Horaires</b></td></tr>
        </table>

        <?php 
        if(isset($_POST['borrar']))
        {
            $borrarlogs = mysql_query("TRUNCATE TABLE server_stafflogs");
            if($borrarlogs) {
                echo '<br /><div id="ok">Los logs se borraron correctamente</div>';
            } else {
                echo '<br /><div id="error">Los logs no se pudieron borrar</div>';
            }
        }
        $logs = mysql_query("SELECT * FROM logs_client_staff ORDER BY id DESC LIMIT 300");
        while($client = mysql_fetch_assoc($logs))
        {
			$client_u = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id = '". $client['user_id'] ."'"));
			
?>
    <table width="870" border="1">
        <tr>
            <td width="150"><?php echo $client_u['username']; ?></td>
            <td width="150"><?php echo $client['data_string']; ?></td>
            <td width="150"><?php echo $client['timestamp']; ?></td>
        </tr>
    </table>
<?php } ?>

			  
			  </p>
            </div>
          </div>
        </div>
      </div>
<?php } ?>
	     
</div>

</body>
</html>