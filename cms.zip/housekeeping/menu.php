  <head>
    <meta charset="UTF-8">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,300,600,700' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
<link rel="stylesheet" href="css/menu.css?2">
  </head>

  <body>

    <div class="vertical-nav narrow hover" style="position: fixed;">
	<div class="branding">
<div class="symbol" style="font-family: pacifico;font-size: 30;color: #fff;margin-right: 25px;">H</div>
      <div class="text">
        <title>logo-text</title>
				<div id="apps-switch">
					<span href="#" class="button">
						<div class="icon">
							<i class="material-icons">apps</i>
						</div>
					</span>
				</div>
      </div>
    </div>
	<div class="primary-nav">
		<div class="slide one navigation active">
			<div class="nav-top">   
				<div class="nav-list">
					<a href="accueil.php" class="nav-item active">
						<div class="icon">
							<i class="material-icons">home</i>
						</div>
						<div class="text">
							Accueil
						</div>
					</a> 
					<a href="edit.php" class="nav-item">
						<div class="icon">
							<i class="material-icons">today</i>
						</div>
						<div class="text">
							Modifier utilisateurs
						</div>
					</a>
					<a href="news.php" class="nav-item">
						<div class="icon">
							<i class="material-icons">today</i>
						</div>
						<div class="text">
							News
						</div>
					</a>

				<?php if($myrow['rank'] >= $Holo['maxrank']) { ?>	
				    <a href="rank.php" class="nav-item">
						<div class="icon">
							<i class="material-icons">work</i>
						</div>
						<div class="text">
							Rank
						</div>
					</a>
					<a href="shop.php" class="nav-item">
						<div class="icon">
							<i class="material-icons">bookmark</i>
						</div>
						<div class="text">
							Boutique
						</div>
					</a>			
					<a href="bans.php" class="nav-item">
						<div class="icon">
							<i class="material-icons">bookmark</i>
						</div>
						<div class="text">
							Joueurs bannis
						</div>
					</a><?php } ?>

				</div>
			</div>
			<div class="nav-bottom">
				<div class="nav-list">
					<a href="logs.php" class="nav-item">
						<div class="icon">
							<i class="material-icons">notifications</i>
						</div>
						<div class="text">
							Logs
						</div>
					</a>
					<a href="statistiques.php" class="nav-item">
						<div class="icon">
							<i class="material-icons">settings</i>
						</div>
						<div class="text">
							Statistiques
						</div>
					</a>
					<a href="logout.php" class="nav-item">
						<div class="icon">
							<i class="material-icons">work</i>
						</div>
						<div class="text">
							Quitter la session
						</div>
					</a>
				</div>
			</div>
		</div>
		<div class="slide two apps inactive">
		</div>
	</div>
	
	<div class="profile">
      <div class="avatar">
        <img src="g.png" alt="You" />
      </div>
      <div class="details">
        <div class="name"><?php echo $Holo['name']; ?> Hotel</div>
        <div class="company">gatita</div>
      </div>
    </div>
</div>
<div class="top-bar">
  <div class="left">
    <div class="page-title">
     Housekeeping de <?php echo $Holo['name']; ?>
    </div>
  </div>
  <div class="right">
    <div class="apps">
      <a href="#" class="nav-item">

      </a>
    </div>
  </div>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cherne.net/brian/resources/jquery.hoverIntent.minified.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js'></script>

        <script src="js/menu.js"></script>

    
    
    
  </body><br>

  <script type="text/javascript">
document.oncontextmenu = function(){return false;}
</script>