<?php
require_once("../engine/core.cms.php");
require_once("../engine/hk_session.php");

if(Loged == false) { 
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(UserH == false) {
    header("Location: " . $Holo['url'] ."/".$Holo['panel']."");
	exit;
}
if($myrow['rank'] < $Holo['minhkr']) {
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(mysql_num_rows($chb) > 0) {
    header("Location: " . $Holo['url'] . "/banned");
	exit;
}
?>

<html>
    <head>
	<title>Administration de <?php echo $myrow['username']; ?></title>
<link rel="icon" type="image/png" href="<?php echo $Holo['url']; ?>/favicon.gif" />
      
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css?22"  media="screen,projection"/>

      
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    </head>
	<style>
	body{
		background-color: #0B4C5F;
	}
	</style>
	
	
		
<body>

<?php include 'menu.php'; ?>




<div class="container">
			  <div class="row">

      
        <div class="col s12 m12">
          <div class="card blue-white darken-1">
            <div class="card-content black-text">
              <span class="card-title" style="color: #0B4C5F;">Administration</span>
              <p>
Comment ça va <?php echo $myrow['username']; ?>?<br /><br />
Vous êtes dans le panneau d'administration de <b><?php echo $Holo['name']; ?></b>, ici vous pouvez trouver différents outils
qui sont à gérer l'hôtel, ces outils peuvent maintenant utiliser, mais avec beaucoup de<b> responsabilité</b> et beaucoup de <b>maturité</b> , chaque
outil d'édition des éléments très importants de l'hôtel, si vous ne font pas bon usage de cette ou fait usage affectant l'hôtel, vous pouvez
recevoir un <b>pénalité</b> de l'équipe de direction de l'hôtel, j'espère avoir été clair.<br><br>
<?php 
	$registrados = mysql_query("SELECT COUNT(*) aantalleden FROM users") or die (mysql_error());
	$r = mysql_fetch_assoc($registrados);	
	
	$baneados = mysql_query("SELECT COUNT(*) aantalleden FROM bans") or die (mysql_error());
	$b = mysql_fetch_assoc($baneados);	
	
	$noticias = mysql_query("SELECT COUNT(*) aantalleden FROM cms_news") or die (mysql_error());
	$n = mysql_fetch_assoc($noticias);	
?>
      <table class="striped" style="width: 100%;">
        <thead>
          <tr>
              <th data-field="id">Utilisateurs enregistrés</th>
              <th data-field="name">Utilisateurs bannis</th>
              <th data-field="price">Nombre de news</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td><?php echo $r['aantalleden']; ?></td>
            <td><?php echo $b['aantalleden']; ?></td>
            <td><?php echo $n['aantalleden']; ?></td>
          </tr>
        </tbody>
      </table>
			  </p>
			 
			  
			  
			  
            </div>
          </div>
        </div>
      

      </div>
	  <?php if($myrow['rank'] >= $Holo['maxrank']) { ?>
<div class="card blue-white darken-1">
            <div class="card-content black-text">
     <div id="box">
<?php
if(isset($_POST['motivo']))
{
$Motivo = $_POST['motivo'];

if(empty($Motivo))
{
echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">
		  Vous devez mettre une raison pour laquelle vous mettez l hotel en maintenance
          </span>
        </div>
      </div>';
} else {
mysql_query("UPDATE cms_mantenimiento SET mantenimiento = '1', motivo = '". $Motivo ."'");
mysql_query("INSERT INTO stafflogs (action, message, note, userid, timestamp) VALUES ('Maintenance.', 'Activo mantenimiento.', '". $myrow['rank'] ."', '". $myrow['id'] ."', '". $date_full ."')");
echo '<div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">
		  L hotel est en maintenance
          </span>
        </div>
      </div>';
}
}
if(isset($_POST['quitar']))
{
mysql_query("UPDATE cms_mantenimiento SET mantenimiento = '0', motivo = ''");
mysql_query("INSERT INTO stafflogs (action, message, note, userid, timestamp) VALUES ('Maintenance.', 'Desactivo mantenimiento.', '". $myrow['rank'] ."', '". $myrow['id'] ."', '". $date_full ."')");
echo '<div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">
		  L hotel est en fonctionnement
          </span>
        </div>
      </div>';
}
?>
<center>
<?php 
$sqlputo = mysql_query("SELECT * FROM cms_mantenimiento");
$putito = mysql_fetch_assoc($sqlputo);
if($putito['mantenimiento'] == '0') {
?>
<form action="" method="post">
<h4>Pourquoi mettre l'hôtel en maintenance</h4>
<textarea name="motivo" style="width: 500px; height: 200px;"></textarea><br><br>
<button class="btn waves-effect waves-light" type="submit">Appliquer la maintenance.
    <i class="mdi-content-send right"></i>
  </button>
</form></center>
<?php
} else {
?><br>
<form action="" method="post">
<button class="btn waves-effect waves-light" type="submit" name="quitar">Retirer la maintenance.
    <i class="mdi-content-send right"></i>
  </button>
<?php } ?><?php } ?>
</div>

      </div> </div>
	  
	
	  
</div>

</body>
</html>