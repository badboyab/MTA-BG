<?php
require_once("../engine/core.cms.php");
require_once("../engine/hk_session.php");

unset($_SESSION['HUsername']);
unset($_SESSION['HPassword']);

header("Location: index.php");
?>