<?php
require_once("../engine/core.cms.php");
require_once("../engine/hk_session.php");

if(Loged == false) { 
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(UserH == false) {
    header("Location: " . $Holo['url'] ."/".$Holo['panel']."");
	exit;
}
if($myrow['rank'] < $Holo['minhkr']) {
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(mysql_num_rows($chb) > 0) {
    header("Location: " . $Holo['url'] . "/banned");
	exit;
}
if($myrow['rank'] < $Holo['maxrank']) {
    header("Location: " .$Holo['url'] ."/" .$Holo['panel'] ."");
	exit;
}
?>

<html>
    <head>
	<title>Administration de <?php echo $myrow['username']; ?></title>
<link rel="icon" type="image/png" href="<?php echo $Holo['url']; ?>/favicon.gif" />
      
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    </head>
	<style>
.boxing {
  background-color: #fff;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
  box-shadow: 0px 0px 2px rgba(0,0,0,0.05);
  border: 1px solid rgba(0,0,0,0.2);
  border-bottom: 2px solid rgba(0,0,0,0.2);
  margin-bottom: 15px;}
  padding: 20px;
</style>
	
	
		
<body>

<?php include 'menu.php'; ?>

<div class="container">

			  <div class="row">			  <div class="boxing">

<?php
$do = $_GET['do'];
$key = $_GET['key'];
if($do == "dele"){
	$check = mysql_query("SELECT id FROM cms_badges WHERE id = '". $key ."' LIMIT 1");
	if(mysql_num_rows($check) > 0){
		mysql_query("DELETE FROM cms_badges WHERE id = '". $key ."' LIMIT 1");
		echo '<div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">Badge supprimé avec succès.</span>
        </div>
      </div>';
	} else {
		echo '<div class="card-panel red"><font color="#FFFFFFF">Le badge ne peut être supprimer.</font></div>';
	}
}

if(isset($_POST['placa']) && isset($_POST['costo']) && isset($_POST['limite'])) {

	$p = $_POST['placa'];

	$ch_badge = mysql_query("SELECT badge_id FROM cms_badges WHERE badge_id = '". $p ."'");
	$ch_limi = mysql_query("SELECT * FROM cms_badges");

	if(empty($p) || empty($_POST['costo']) || empty($_POST['limite'])) {
		echo '<div class="card-panel red"><font color="#FFFFFFF">Ne pas laisser des espaces vides</font></div>';
	} elseif(mysql_num_rows($ch_badge) > 0) {
		echo '<div class="card-panel red"><font color="#FFFFFFF">Ce badgee est déjà en vente</font></div>';
	} elseif(mysql_num_rows($ch_limit) > 10) {
		echo '<div class="card-panel red"><font color="#FFFFFFF">10 badges maximum, supprimez-en !</font></div>';
	} else {
		mysql_query("INSERT INTO cms_badges (badge_id, cost, b_limit, added_by, added_date) VALUES ('". $p ."', '". $_POST['costo'] ."', '". $_POST['limite'] ."', '". $myrow['username'] ."', '". $date_full ."')");
		mysql_query("INSERT INTO stafflogs (action, message, note, userid, timestamp) VALUES ('Tienda', 'Puso la placa $p', '". $myrow['rank'] ."', '". $myrow['id'] ."', '". $date_full ."')");
		echo '<div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">
		  Placa metida exitosamente
          </span>
        </div>
      </div>'; 
	}
}
?>

<style>
input[type="text"] {
	width: 190px;
	margin-right: 10px;
}
</style>
<center>
<h1>Ajouter badge</h1>

<form action="" method="post">
<input type="text" name="placa" placeholder="ID Badge" /><input type="text" name="costo" placeholder="Prix" /><input type="text" name="limite" placeholder="Limite" />
<button class="btn waves-effect waves-light" type="submit">Ajouter badge
    <i class="mdi-content-send right"></i>
  </button>
</form>
</font>
<br />

<h2>Badge dans la boutique</h2></font>



      <table class="centered">
  
        <thead>
		
          <tr>
		  
              <th data-field="id">ID</th>
              <th data-field="placa">Badge</th>
              <th data-field="costo">Prix</th>
			  <th data-field="limit">Limite</th>
			  <th data-field="subida">autheur</th>
			  <th data-field="option">Options</th>
<?php
$getbans = mysql_query("SELECT * FROM cms_badges ORDER BY id DESC");
while($getb = mysql_fetch_assoc($getbans)){
?>	          </tr>
        </thead>

        <tbody>
          <tr>
            <td><?php echo $getb['id']; ?></td>
            <td><?php echo $getb['badge_id']; ?></td>
			<td><?php echo $getb['cost']; ?></td>
			<td><?php echo $getb['b_limit']; ?></td>
			<td><?php echo $getb['added_by']; ?></td>
			<td><a href="tienda.php?do=dele&key=<?php echo $getb['id']; ?>" class="btn-floating btn-large waves-effect waves-light red"><i class="mdi-action-delete"></i></a></td>
          </tr>
<?php } ?>		  
        </tbody>
      
	  </table>


			  
			  </p>
            </div>            </div>

          </div>

	  </center>
	       
	  

</body>
</html>