<?php
require_once("../engine/core.cms.php");
require_once("../engine/hk_session.php");

if(Loged == false) { 
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(UserH == false) {
    header("Location: " . $Holo['url'] ."/".$Holo['panel']."");
	exit;
}
if($myrow['rank'] < $Holo['minhkr']) {
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(mysql_num_rows($chb) > 0) {
    header("Location: " . $Holo['url'] . "/banned");
	exit;
}
?>

<html>
    <head>
	<title>Administration de <?php echo $myrow['username']; ?></title>
<link rel="icon" type="image/png" href="<?php echo $Holo['url']; ?>/favicon.gif" />
      
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css?22"  media="screen,projection"/>

     
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    </head>
	<style>
	body{
	body{
		background-color: #0B4C5F;
	}
	</style>
	
	
		
<body>

<?php include 'menu.php'; ?>




<div class="container">

			  <div class="row">

      
        <div class="col s12 m12">
          <div class="card blue-white darken-1">
            <div class="card-content black-text">
              <span class="card-title" style="color: #3D85A6 !important;">Gestion des joueurs</span>
              <p>

<center>
<form name="buscar" action="" method="get">
    <input placeholder="Rechercher un utilisateurs" type="text" value="<?php echo $_GET['frase']; ?>" name="frase" />
	  <button class="btn waves-effect waves-light" type="submit" name="buscar" value="Buscar">Rechercher
    <i class="mdi-content-send right"></i>
  </button>
</form>


</center>

<center>



   <table class="centered">
        <thead>
          <tr>
              <th data-field="nombre">Pseudo</th>
              <th data-field="ip">IP</th>
			  <th data-field="options">Options</th>
          </tr>   <?php

if(isset($_GET['buscar']) && $_GET['buscar'] == 'Buscar'){
    $frase = addslashes($_GET['frase']);

    $sqlBuscar = mysql_query("SELECT id, username, ip_reg,
                            MATCH (username, mail)
                            AGAINST ('$frase' IN BOOLEAN MODE) AS username
                            FROM users WHERE MATCH (username, mail)
                            AGAINST ('$frase' IN BOOLEAN MODE)
                            ORDER BY username DESC LIMIT 1")
                            or die(mysql_error());
    $totalRows = mysql_num_rows($sqlBuscar);

	
    if(!empty($totalRows)){
        echo stripslashes("<br /><p><center><h2>Resultats</h2></center></p>");
		mysql_query("INSERT INTO stafflogs (action, message, note, userid, timestamp) VALUES ('Usuarios.', 'Busco al usuario $frase.', '". $myrow['rank'] ."', '". $myrow['id'] ."', '". $date_full ."')");
        
        while($row = mysql_fetch_array($sqlBuscar)){
		    $ipusers = mysql_query("SELECT * FROM users WHERE ip_reg = '". $row['ip_reg'] ."'");
            while($users = mysql_fetch_assoc($ipusers)) {		
?>
        </thead>

        <tbody>
          <tr>
		  
            <td><?php echo $users['username']; ?></td>
			<td><a href="http://whois.domaintools.com/<?php echo $row['ip_reg']; ?>" target="_blank"><?php echo $row['ip_reg']; ?></a></td>
            <td><a href="edit.php?action=<?php echo $users['id']; ?>" class="btn-floating btn-large waves-effect waves-light red"><i class="mdi-editor-mode-edit"></i></a></td>
          <?php
            }
        }
    }

    elseif(empty($_GET['frase'])){
        echo "<br /><center>Vous devez entrer un mot ou une phrase.</center>";
    }

    elseif($totalRows == 0){
        echo stripslashes("<br /><center>Votre recherche n'a pas trouvé de résultats pour <strong>$frase</strong></center>");
    }
}
?> </tr>
        </tbody>
      </table>

<i>(Les multi-comptes sont interdis ou risque de sanction!)</i>


</center>


			  </p>
            </div>
          </div>
        </div>
      

      </div>
	  
	  <div class="row">
    
      <div class="col s12 m12">
        <div class="card-panel white">
          <span class="black-text">
		  

<?php
if(isset($_GET['action']))
{
	if(!empty($_GET['action']))
	{

		$id_user = mysql_real_escape_string($_GET['action']);
	    $query_user = mysql_query("SELECT * FROM users WHERE id = '". $id_user ."'");
	    if(mysql_num_rows($query_user) > 0)
	    {

	    	while($perfil = mysql_fetch_assoc($query_user))
	    	{

	    	$referidos = mysql_query("SELECT COUNT(*) aantalleden FROM users_referidos WHERE usuario = '". $perfil['username'] ."'") or die (mysql_error());
            $r = mysql_fetch_assoc($referidos);
			
			if(isset($_POST['editar']))
			{
					mysql_query("UPDATE users SET mail = '". $_POST['email'] ."', credits = '". $_POST['creditos'] ."', activity_points = '". $_POST['activity_points'] ."', motto = '". $_POST['mision'] ."' WHERE id = '". $perfil['id'] ."'");
			        mysql_query("INSERT INTO stafflogs (action, message, note, userid, timestamp) VALUES ('Usuarios', 'Edito a ". $perfil['username'] ."', '". $myrow['rank'] ."', '". $myrow['id'] ."', '". $date_full ."')");
			        echo '<div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">Haz editado el perfil correctamente.</span>
        </div>
      </div>';
			}
?>

<h3><center style="color: #3D85A6 !important;">Modifier joueur <b><i><?php echo $perfil['username']; ?></b></i></center></h3>



<form action="" method="post">

      <table class="striped centered">
        <thead>
        </thead>

        <tbody>
          <tr>
            <td>Pseudo</td>
            <td><input type="text" value="<?php echo $perfil['username']; ?>" disabled="true" /></td>
          </tr>
          <tr>
            <td>Mission</td>
            <td><input type="text" name="mision" value="<?php echo $perfil['motto']; ?>" /></td>
          </tr>
          <tr>
            <td>ID</td>
            <td><input type="text" value="<?php echo $perfil['id']; ?>" disabled="true" /></td>
          </tr>
          <tr>
            <td>E-mail</td>
            <td><input type="text" value="<?php echo $perfil['mail']; ?>" name="email" /></td>
          </tr>
          <tr>
            <td>Rank</td>
            <td><input type="text" value="<?php echo $perfil['rank']; ?>" disabled="true" /></td>
          </tr>
          <tr>
            <td>IP</td>
            <td><input type="text" value="<?php echo $perfil['ip_reg']; ?>" disabled="true" /></td>
          </tr>	
          <tr>
            <td>Crédits</td>
            <td><input type="text" name="creditos" value="<?php echo $perfil['credits']; ?>" /></td>
          </tr>
          <tr>
            <td>Duckets</td>
            <td><input type="text" name="duckets" value="<?php echo $perfil['activity_points']; ?>" /></td>
          </tr>		
          <tr>
            <td>Reference</td>
            <td><input type="text" value="<?php echo $r['aantalleden']; ?>" disabled="true" /></td>
       </tr>   <tr>
            <td><img src="<?php echo $Holo['url']; ?>/assets/images/<?php if($perfil['online'] == '1') { echo 'online'; } else { echo 'offline'; } ?>.gif" /></td>
            <td>
				  <button class="btn waves-effect waves-light" type="submit" name="editar" value="Editar">Enregistrer les modifications
    <i class="mdi-content-send right"></i>
  </button>
			
			</td>
          </tr>
        </tbody>
      </table>
</form>

<?php
	    	}
	    }
	    else
	    {
	    	echo '<center>Le profil que vous cherchez n existe pas.</center>';
	    }
	}
	else 
	{
		echo '<center>Vous devez choisir un profil.</center>';
    }
}
else
{
	echo '<center>Vous devez choisir un profil.</center>';
}
?>

		  
          </span>
        </div>
      </div>
    </div>
	  
	  
</div>

</body>
</html>