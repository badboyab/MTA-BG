<?php
require_once("../engine/core.cms.php");
require_once("../engine/hk_session.php");

if(Loged == false) { 
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(UserH == true) {
    header("Location: " . $Holo['url'] ."/".$Holo['panel']."/accueil.php");
	exit;
}
if($myrow['rank'] < $Holo['minhkr']) {
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(mysql_num_rows($chb) > 0) {
    header("Location: " . $Holo['url'] . "/banned");
	exit;
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="icon" type="image/png" href="<?php echo $Holo['url']; ?>/favicon.gif" />
	<title><?php echo $Holo['name']; ?> - Administration</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css?3442"></head>

  <body>
<center><br><br>
  							<?php echo $msg; ?>
</center>

    <section class="container">
		    <article class="half">
			        <h1>Housekeeping</h1>
			        <div class="tabs">
				            <span class="tab signin active">Commencer la session</span>
			        </div>
			        <div class="content">
				            <div class="signin-cont cont">
				                    <form action="" method="post">
						                    <input type="text" name='HUsername' class="inpt" required="required" placeholder="Pseudo">
						                    <label for="email">Pseudo</label>
						                    <input type="password" name='HPassword' class="inpt" required="required" placeholder="Mot de passe">
                						    <label for="password">Mot de passe</label>
						                    <input type="checkbox" id="remember" class="checkbox" checked>
						                    <label for="remember">Sauvegarder session</label>
						                    <div class="submit-wrap">
							                        <input type="submit" name="action" value="Entrer" class="submit">
							                        <a href="/" class="more">Quitter la session</a>
						                    </div>
        					        </form>
    				        </div>
			        </div>
		    </article>
		    <div class="half bg"></div>
	</section>

<div class="credits"><?php echo $Holo['name']; ?> Housekeeping</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="js/index.js"></script>

    
    
    
</body>
</html>
