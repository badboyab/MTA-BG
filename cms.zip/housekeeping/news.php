<?php
require_once("../engine/core.cms.php");
require_once("../engine/hk_session.php");

if(Loged == false) { 
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(UserH == false) {
    header("Location: " . $Holo['url'] ."/".$Holo['panel']."");
	exit;
}
if($myrow['rank'] < $Holo['minhkr']) {
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(mysql_num_rows($chb) > 0) {
    header("Location: " . $Holo['url'] . "/banned");
	exit;
}
?>

<html>
    <head>
	<title>Administration de <?php echo $myrow['username']; ?></title>
	<link rel="icon" type="image/png" href="<?php echo $Holo['url']; ?>/favicon.ico" />
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js" type="text/javascript"></script>
	<script src="ckeditor/ckeditor.js"></script>
      
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    </head>
	<style>
	body{
		background-color: #0B4C5F;
	}
	</style>
	
	
		
<body>

<?php include 'menu.php'; ?>

<div class="container">

			  <div class="row">

      
        <div class="col s12 m12">
          <div class="card blue-white darken-1">
            <div class="card-content black-text">
              <span class="card-title" style="color: #0B4C5F;">News</span>
              

<?php 
if(isset($_POST['añadir'])) //  
{ 
    $titulo = mysql_real_escape_string($_POST['titulo']); 
    $texto_corto = mysql_real_escape_string($_POST['texto_corto']);    
	$Image = mysql_real_escape_string($_POST['topstory']);
	$texto = mysql_real_escape_string($_POST['texto']);
    if(!empty($titulo) && !empty($texto_corto) && !empty($imagen) && !empty($texto))  
    { 
        $query_NuevaNoticia = mysql_query("INSERT INTO cms_news SET title = '".$titulo."', image = '". $Image ."' , shortstory = '".$texto_corto."', longstory = '". str_replace("<br />","\n",stripslashes($texto)) ."', date = '". time() . "', author = '". $myrow['username'] ."'");  
		mysql_query("INSERT INTO stafflogs SET action = 'Noticias', message = 'Hizo la noticia $titulo', note = '". $myrow['rank'] ."', userid = '". $myrow['id'] ."', timestamp = '". $date_full ."'");
  
        if($query_NuevaNoticia) 
        { 
            echo '<div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">La news a été ajouté correctement</span>
        </div>
      </div>'; // je 
        } 
        else 
        { 
            echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">La news a eu un probleme</span>
        </div>
      </div>'; // 
        } 
    } 
    else 
    { 
        echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">Vous ne pouvez pas laisser les champs vides, remplissez-les.</span>
        </div>
      </div>'; //  
    } 
} 
  
?>

<script languaje="javascript" type="text/javascript">

function mostrarCapa(id){
	document.getElementById(id).style.display="block";
}

function ocultarCapa(id){
	document.getElementById(id).style.display="none";
}
</script>

<div id="comentariocompleto" style="display:none">

<a class="waves-effect waves-light btn" href="javascript:void(0);" onclick="ocultarCapa('comentariocompleto');mostrarCapa('comentarioCorto')"><i class="mdi-content-reply left"></i>Retour</a>

<form action="" method="post">  
<div id="modificar_noticia">
	
	<br><h6>Titre</h6><input placeholder="Titre" name="titulo" type="text" /><br>
	<br><h6>Description</h6><input placeholder="Description" name="texto_corto" type="text" /><br>
	<br><h6>Contenue de l'affiche</h6><textarea name="texto" id="editor1" rows="10" cols="80"></textarea>
            <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'texto' );
            </script><br>
	
	<br><br><tr><td>Image de la news</td><td>
	<select name="topstory">
	<option value="/assets/images/promos/1.png">Image 1</option>
	<option value="/assets/images/promos/2.png">Image 2</option>
	<option value="/assets/images/promos/3.png">Image 3</option>
	<option value="/assets/images/promos/4.png">Image 4</option>
	<option value="/assets/images/promos/5.png">Image 5</option>
	<option value="/assets/images/promos/6.png">Image 6</option>
	<option value="/assets/images/promos/7.png">Image 7</option>
	<option value="/assets/images/promos/8.png">Image 8</option>
	<option value="/assets/images/promos/9.png">Image 9</option>
	<option value="/assets/images/promos/10.png">Image 10</option>
	<option value="/assets/images/promos/11.png">Image 11</option>
	<option value="/assets/images/promos/12.png">Image 12</option>
	<option value="/assets/images/promos/13.png">Image 13</option>
	<option value="/assets/images/promos/14.png">Image 14</option>
	<option value="/assets/images/promos/15.png">Image 15</option>
	<option value="/assets/images/promos/16.png">Image 16</option>
	<option value="/assets/images/promos/17.png">Image 17</option>
	<option value="/assets/images/promos/18.png">Image 18</option>
	<option value="/assets/images/promos/19.png">Image 19</option>
	<option value="/assets/images/promos/20.png">Image 20</option>
	<option value="/assets/images/promos/21.png">Image 21</option>
	<option value="/assets/images/promos/22.png">Image 22</option>
	<option value="/assets/images/promos/23.png">Image 23</option>
	<option value="/assets/images/promos/24.png">Image 24</option>
	<option value="/assets/images/promos/25.png">Image 25</option>
	<option value="/assets/images/promos/26.png">Image 26</option>
	<option value="/assets/images/promos/27.png">Image 27</option>
	<option value="/assets/images/promos/28.png">Image 28</option>
	<option value="/assets/images/promos/29.png">Image 29</option>
	<option value="/assets/images/promos/30.png">Image 30</option>
	<option value="/assets/images/promos/31.png">Image 31</option>
	<option value="/assets/images/promos/32.png">Image 32</option>
	<option value="/assets/images/promos/33.png">Image 33</option>
	<option value="/assets/images/promos/34.png">Image 34</option>
	<option value="/assets/images/promos/35.png">Image 35</option>
	<option value="/assets/images/promos/36.png">Image 36</option>
	<option value="/assets/images/promos/37.png">Image 37</option>
	<option value="/assets/images/promos/38.png">Image 38</option>
	<option value="/assets/images/promos/39.png">Image 39</option>
	<option value="/assets/images/promos/40.png">Image 40</option>
	</select></td></tr>
    <br>
	<center>
  <button class="btn waves-effect waves-light" type="submit" name="añadir">Ajouter
    <i class="mdi-navigation-check right"></i>
  </button>	
	</center>
	</div>
</form>
</div>
<div id="comentarioCorto" style="display:block"><a class="waves-effect waves-light btn" href="javascript:void(0);" onclick="ocultarCapa('comentarioCorto');mostrarCapa('comentariocompleto')"><i class="mdi-content-add left"></i>Crée une news</a></div><br>

	

	<?php
	$do = $_GET['do'];
	$key = $_GET['key'];
	if($do == "dele"){
		$check = mysql_query("SELECT id FROM cms_news WHERE id = '". $key ."' LIMIT 1");
		if(mysql_num_rows($check) > 0){
			mysql_query("DELETE FROM cms_news WHERE id = '". $key ."' LIMIT 1");
			mysql_query("INSERT INTO stafflogs SET action = 'Noticias', message = 'Borro una noticia', note = '". $myrow['rank'] ."', userid = '". $myrow['id'] ."', timestamp = '". $date_full ."'");
			echo '<div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">News supprimé correctement.</span>
        </div>
      </div>';
		} else {
			echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">La news n a pas été effacé.</span>
        </div>
      </div>';
		}
	}

	if(isset($_POST['modificar'])) // 
	{ 
		$tituloM = mysql_real_escape_string($_POST['tituloM']);
		$idM = (int) mysql_real_escape_string($_POST['idM']); 
		$texto_cortoM = mysql_real_escape_string($_POST['texto_cortoM']);   //  
		$imagenM = mysql_real_escape_string($_POST['topstoryM']);
		$textoM = mysql_real_escape_string($_POST['textoM']);
	  
		$query_modificar = mysql_query("UPDATE cms_news SET title = '".$tituloM."', image = '". $imagenM ."', shortstory = '". $texto_cortoM ."', longstory = '". str_replace("<br />","\n",stripslashes($textoM)) ."', date = '". time() ."', author ='". $myrow['username'] ."' WHERE id = '".$idM."'"); // Ejecutamos la consulta para actualizar el registro en la base de datos 
		mysql_query("INSERT INTO stafflogs (action, message, note, userid, timestamp) VALUES ('Noticias', 'Modifico la noticia $tituloM', '". $myrow['rank']."', '". $myrow['id'] ."', '". $date_full ."')");  
	  
		if($query_modificar) 
		{ 
			echo '<div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">La news a été modifiées correctement, appuyez sur <a href="'. $Holo['link'] .'/articles.php?n='. $idM .'">ajouter</a> pour voir....</span>
        </div>
      </div>'; // 
		} 
		else 
		{ 
			echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">La news n a pas été modifié.</span>
        </div>
      </div>'; 
		} 
	}

	if(isset($_GET['noticia'])) 
	{ 
		$id_noticia = (int) mysql_real_escape_string($_GET['noticia']); // 
		$query_NoticiaCompleta = mysql_query("SELECT * FROM cms_news WHERE id = '".$id_noticia."' LIMIT 1"); 
		$columna_MostrarNoticia = mysql_fetch_assoc($query_NoticiaCompleta); 
		echo '
		<div id="modificar_noticia">	
  		<form action="" method="post"> <!-- Nous créons la forme, en utilisant la balise form dont l attribut action = "" indiquer où la forme traitée --> 
			<h3>Modifiée l appel de la news: '. $columna_MostrarNoticia['title'] .'</h3>
			<table>
			<tr><td>Titre de la news:</td><td><input name="tituloM" type="text" value="'.$columna_MostrarNoticia['title'].'" /></td></tr>
			<tr><td>Description</td><td><input name="texto_cortoM" type="text" value="'. $columna_MostrarNoticia['shortstory'].'" /></td></tr>
			<tr><td>Contenue de la news</td><td><textarea name="textoM" id="textoM" rows="10" cols="80">'. $columna_MostrarNoticia['longstory'] .'</textarea>
						<script>
					
					CKEDITOR.replace( "textoM" );
				</script></td></tr> 
	  
			<input type="hidden" name="idM" value="'.$columna_MostrarNoticia['id'].'" /> <!-- Nous créons un champ de texte caché pour passer l identifiant des nouvelles --> 
			<br>
			<tr><td>Image:</td><td><select name="topstoryM">
		<option value="'. $columna_MostrarNoticia['image'] .'">Image actuel</option>	
		<option value="/assets/images/promos/1.png">Image 1</option>
		<option value="/assets/images/promos/2.png">Image 2</option>
		<option value="/assets/images/promos/3.png">Image 3</option>
		<option value="/assets/images/promos/4.png">Image 4</option>
		<option value="/assets/images/promos/5.png">Image 5</option>
		<option value="/assets/images/promos/6.png">Image 6</option>
		<option value="/assets/images/promos/7.png">Image 7</option>
		<option value="/assets/images/promos/8.png">Image 8</option>
		<option value="/assets/images/promos/9.png">Image 9</option>
		<option value="/assets/images/promos/10.png">Image 10</option>
		<option value="/assets/images/promos/11.png">Image 11</option>
		<option value="/assets/images/promos/12.png">Image 12</option>
		<option value="/assets/images/promos/13.png">Image 13</option>
		<option value="/assets/images/promos/14.png">Image 14</option>
		<option value="/assets/images/promos/15.png">Image 15</option>
		<option value="/assets/images/promos/16.png">Image 16</option>
		<option value="/assets/images/promos/17.png">Image 17</option>
		<option value="/assets/images/promos/18.png">Image 18</option>
		<option value="/assets/images/promos/19.png">Image 19</option>
		<option value="/assets/images/promos/20.png">Image 20</option>
		<option value="/assets/images/promos/21.png">Image 21</option>
		<option value="/assets/images/promos/22.png">Image 22</option>
		<option value="/assets/images/promos/23.png">Image 23</option>
		<option value="/assets/images/promos/24.png">Image 24</option>
		<option value="/assets/images/promos/25.png">Image 25</option>
		<option value="/assets/images/promos/26.png">Image 26</option>
		<option value="/assets/images/promos/27.png">Image 27</option>
		<option value="/assets/images/promos/28.png">Image 28</option>
		<option value="/assets/images/promos/29.png">Image 29</option>
		<option value="/assets/images/promos/30.png">Image 30</option>
		<option value="/assets/images/promos/31.png">Image 31</option>
		<option value="/assets/images/promos/32.png">Image 32</option>
		<option value="/assets/images/promos/33.png">Image 33</option>
		<option value="/assets/images/promos/34.png">Image 34</option>
		<option value="/assets/images/promos/35.png">Image 35</option>
		<option value="/assets/images/promos/36.png">Image 36</option>
		<option value="/assets/images/promos/37.png">Image 37</option>
		<option value="/assets/images/promos/38.png">Image 38</option>
		<option value="/assets/images/promos/39.png">Image 39</option>
		<option value="/assets/images/promos/40.png">Image 40</option>
		</select></td></tr></table>
		<br />
		<center>
			<input class="btn waves-effect waves-light" type="button" value="Quitter" name="Back2" onclick="history.back()" />
			<input class="btn waves-effect waves-light" type="submit" name="modificar" value="Modifier" />
		</center>	
		</form>
		</div>
		'; 
	} else {  
	$noticias = mysql_query("SELECT * FROM cms_news ORDER BY id DESC");
	while($columnas = mysql_fetch_assoc($noticias)) {
	?>    


<?php } } ?>  <table class="striped centered" style="width: 100%;">
        <thead>
          <tr>
              <th data-field="id">Titre</th>
              <th data-field="price">Autheur</th>
			  <th data-field="price">Options</th>
          </tr>
        </thead>

        <tbody>	<?php
	$noticias = mysql_query("SELECT * FROM cms_news ORDER BY id DESC");
	while($columnas = mysql_fetch_assoc($noticias)) {
	?>
          <tr>
            <td><?php echo $columnas['title']; ?></td>
            <td><?php echo $columnas['author']; ?></td>
			<td><a href="news.php?do=dele&key=<?php echo $columnas['id']; ?>" class="btn-floating btn-large waves-effect waves-light red"><i class="mdi-action-delete"></i></a> <a href="news.php?noticia=<?php echo $columnas['id']; ?>" title="Editer" class="btn-floating btn-large waves-effect waves-light red"><i class="mdi-image-edit"></i></a></td>
          </tr>
	<?php } ?>
        </tbody>
	
      </table>
            </div>
          </div>
        </div>
      

      </div>
	 
	  
</div>

</body>
</html>