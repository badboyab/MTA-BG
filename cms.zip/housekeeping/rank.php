<?php
require_once("../engine/core.cms.php");
require_once("../engine/hk_session.php");

if(Loged == false) { 
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(UserH == false) {
    header("Location: " . $Holo['url'] ."/".$Holo['panel']."");
	exit;
}
if($myrow['rank'] < $Holo['minhkr']) {
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(mysql_num_rows($chb) > 0) {
    header("Location: " . $Holo['url'] . "/banned");
	exit;
}
if($myrow['rank'] < $Holo['maxrank']) {
    header("Location: " .$Holo['url'] ."/" .$Holo['panel'] ."");
	exit;
}
?>

<html>
    <head>
	<title>Administration de <?php echo $myrow['username']; ?></title>
<link rel="icon" type="image/png" href="<?php echo $Holo['url']; ?>/favicon.gif" />
      
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css?3"  media="screen,projection"/>

      
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    </head>
	<style>
	body{
		background-color: #0B4C5F;
	}
	</style>
	
	
		
<body>

<?php include 'menu.php'; ?>

<div class="container">

			  <div class="row">
      
        <div class="col s12 m12">
          <div class="card blue-white darken-1">
            <div class="card-content black-text">
              <span class="card-title" style="color: #0B4C5F;">Administration de rank</span>
              <p>
<?php 
$getrank = mysql_query("SELECT * FROM ranks ORDER BY id ASC");

if(isset($_POST['dar']))
{
$Rango = $_POST['rango'];
$Miembro = $_POST['miembro'];
$Fallo = false;

$Geturank = mysql_query("SELECT * FROM users WHERE username = '". $Miembro ."'");

if(empty($Rango) || empty($Miembro))
{
	echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">
		  Ne pas laisser les champs vides
          </span>
        </div>
      </div>';
	$Fallo = true;
}
elseif(mysql_num_rows($Geturank) == 0)
{
	echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">
		  L utilisateurs que vous cherchez n existe pas
          </span>
        </div>
      </div>';
	$Fallo = true;
}
elseif($myrow['username'] == $Miembro)
{
	echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">
		  Vous ne pouvez pas
          </span>
        </div>
      </div>';
	$Fallo = true;
}
elseif($Miembro == 'Totix')
{
    echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">
		  Vous ne pouvez pas prendre ce rank
          </span>
        </div>
      </div>';
	$Fallo = true;
}
elseif($Fallo == false)
{
	mysql_query("UPDATE users SET rank = '". $Rango ."' WHERE username = '". $Miembro ."' LIMIT 1");
    mysql_query("INSERT INTO stafflogs (action, message, note, userid, timestamp) VALUES ('Housekeeping', 'Dió rango a $Miembro', '". $myrow['rank'] ."', '". $myrow['id'] ."', '". $date_full ."')");
    echo '<div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">
		  Vous avez donné un rank a <b>'. $Miembro .'</b> 
          </span>
        </div>
      </div>';
}
}
?>

<center>
<form action="" method="post">
	<input type="text" name="miembro" placeholder="Pseudo" /><br />
	<select name="rango">
		<?php while($rangos = mysql_fetch_assoc($getrank)) { ?>
		<option value="<?php echo $rangos['id']; ?>"><?php echo $rangos['name']; ?></option>
		<?php } ?>
	</select><br />
	<button class="btn waves-effect waves-light" type="submit" name="dar">Donner rank
    <i class="mdi-content-send right"></i>
  </button>
</form>
</center>

<br />

<center><h2>Les joueurs ranks</h2></center>

<table class="centered">
  
        <thead>
		
          <tr>
		  
              <th data-field="user">Pseudo</th>
              <th data-field="rank">Rank</th>
              <th data-field="email">E-mail</th>
			  <th data-field="conexion">Connexion</th>
<?php 
$rango = mysql_query("SELECT * FROM ranks WHERE id >= 2 ORDER BY id DESC");
while($rank = mysql_fetch_assoc($rango)) {

$users = mysql_query("SELECT * FROM users WHERE rank = '". $rank['id'] ."'");
while($staffs = mysql_fetch_assoc($users))
{
?>	          </tr>
        </thead>

        <tbody>
          <tr>
            <td><?php echo $staffs['username']; ?></td>
            <td><?php echo $rank['name'] ?></td>
            <td><?php echo $staffs['mail']; ?></td>
			<td><img src="<?php echo $web['link']; ?>/assets/images/<?php if($staffs['online'] == '1') { echo 'online'; } else { echo 'offline'; } ?>.gif" /></td>
          </tr>
<?php }  } ?>	  
        </tbody>
      
	  </table><br><br><br><br><br><br><br><br>
			  </p>
            </div>
          </div>
        </div>
      

      </div>
	  
	  
	    
</div>

</body>
</html>