<?php
require_once("../engine/core.cms.php");
require_once("../engine/hk_session.php");

if(Loged == false) { 
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(UserH == false) {
    header("Location: " . $Holo['url'] ."/".$Holo['panel']."");
	exit;
}
if($myrow['rank'] < $Holo['minhkr']) {
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(mysql_num_rows($chb) > 0) {
    header("Location: " . $Holo['url'] . "/banned");
	exit;
}
?>

<html>
    <head>
	<title>Administracion de <?php echo $myrow['username']; ?></title>
<link rel="icon" type="image/png" href="<?php echo $Holo['url']; ?>/favicon.gif" />
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css?22"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    </head>
	<style>
	body{
		background-color: #0B4C5F;
	}
	</style>
	
	
		
<body>

<?php include 'menu.php'; ?>


<?php 
	$registrados = mysql_query("SELECT COUNT(*) aantalleden FROM users") or die (mysql_error());
	$r = mysql_fetch_assoc($registrados);	
	
	$baneados = mysql_query("SELECT COUNT(*) aantalleden FROM bans") or die (mysql_error());
	$b = mysql_fetch_assoc($baneados);	
	
	$noticias = mysql_query("SELECT COUNT(*) aantalleden FROM cms_news") or die (mysql_error());
	$n = mysql_fetch_assoc($noticias);	
?>

<div class="container">
			  <div class="row">
                            <div class="col s12 m6 l3" style="width: 400px;">
                                <div class="card">
                                    <div class="card-content  green white-text"><center>
                                        <p class="card-stats-title"><h5>Usuarios registrados</h5></p>
                                        <h4 class="card-stats-number"><?php echo $r['aantalleden']; ?> Usuarios</h4>
                                        </p></center>
                                    </div>
                                    <div class="card-action  green darken-2">
                                        <div id="clients-bar"><canvas width="290" height="25" style="display: inline-block; width: 290px; height: 25px; vertical-align: top;"></canvas></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6 l3" style="width: 400px;">
                                <div class="card">
                                      <div class="card-content  purple white-text"><center>
                                        <p class="card-stats-title"><h5>Usuarios baneados</h5></p>
                                        <h4 class="card-stats-number"><?php echo $b['aantalleden']; ?> Baneados</h4>
                                        </p></center>
                                    </div>
                                    <div class="card-action purple darken-2">
                                        <div id="sales-compositebar"><canvas width="286" height="25" style="display: inline-block; width: 286px; height: 25px; vertical-align: top;"></canvas></div>

                                    </div>
                                </div>
                            </div>                            
                            <div class="col s12 m6 l3" style="width: 400px;">
                                <div class="card">
				<div class="card-content  blue-grey white-text"><center>
                                        <p class="card-stats-title"><h5>Noticias creadas</h5></p>
                                        <h4 class="card-stats-number"><?php echo $n['aantalleden']; ?> Noticias</h4>
                                        </p></center>
                                    </div>
                                    <div class="card-action blue-grey darken-2">
                                        <div id="profit-tristate"><canvas width="290" height="25" style="display: inline-block; width: 290px; height: 25px; vertical-align: top;"></canvas></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6 l3" style="width: 400px;">
                                <div class="card">
				<div class="card-content  deep-purple white-text"><center>
                                        <p class="card-stats-title"><h5>Usuarios conectados</h5></p>
                                        <h4 class="card-stats-number"><?php echo $UsersOnline; ?> Conectados</h4>
                                        </p></center>
                                    </div>
                                    <div class="card-action  deep-purple darken-2">
                                        <div id="invoice-line"><canvas width="223" height="25" style="display: inline-block; width: 223px; height: 25px; vertical-align: top;"></canvas></div>
                                    </div>
                                </div>
                            </div>                            
                        </div>

      </div>

</body>
</html>