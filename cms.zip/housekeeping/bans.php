<?php
require_once("../engine/core.cms.php");
require_once("../engine/hk_session.php");

if(Loged == false) { 
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(UserH == false) {
    header("Location: " . $Holo['url'] ."/".$Holo['panel']."");
	exit;
}
if($myrow['rank'] < $Holo['minhkr']) {
    header("Location: " . $Holo['url'] ."");
	exit;
}
if(mysql_num_rows($chb) > 0) {
    header("Location: " . $Holo['url'] . "/banned");
	exit;
}
if($myrow['rank'] < $Holo['maxrank']) {
    header("Location: " .$Holo['url'] ."/" .$Holo['panel'] ."");
	exit;
}
?>

<html>
    <head>
	<title>Administration de <?php echo $myrow['username']; ?></title>
<link rel="icon" type="image/png" href="<?php echo $Holo['url']; ?>/favicon.gif" />
      
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    </head>
	<style>
	body{
		background-color: #0B4C5F;
	}
	</style>
	
	
		
<body>

<?php include 'menu.php'; ?>

<div class="container">

			  <div class="row">
<?php
$do = $_GET['do'];
$key = $_GET['key'];
if($do == "dele"){
	$check = mysql_query("SELECT id FROM bans WHERE id = '". $key ."' LIMIT 1");
	if(mysql_num_rows($check) > 0){
		mysql_query("DELETE FROM bans WHERE id = '". $key ."' LIMIT 1");
		echo '      <div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">
		  Ban supprimé correctement
          </span>
        </div>
      </div>';
	} else {
		echo '      <div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">
		  Erreur ban non supprimé
          </span>
        </div>
      </div>';
	}
}

if(isset($_POST['nombre']) && isset($_POST['dura']) && isset($_POST['razon']))
{
$N = $_POST['nombre'];
$D = $_POST['dura'];
$RA = $_POST['razon'];

$Chku = mysql_query("SELECT * FROM bans WHERE value = '". $N ."'");
$Chkuu = mysql_query("SELECT * FROM users WHERE username = '". $N ."'");

if(empty($N) || empty($D) || empty($RA))
{
echo '      <div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">
		  Vous devez remplir tous les champs
          </span>
        </div>
      </div>';
}
elseif(mysql_num_rows($Chku) > 0)
{
echo '      <div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">
		  L utilisateur est déjà bannis
          </span>
        </div>
      </div>';
}
elseif(mysql_num_rows($Chkuu) == 0)
{
echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">
		  Le joueurs n existe pas
          </span>
        </div>
      </div>';
}
elseif($N == $myrow['username'])
{
echo '<div class="col s12 m12">
        <div class="card-panel red">
          <span class="white-text">
		  Vous ne pouvez pas vous bannir
          </span>
        </div>
      </div>';
}
else
{
mysql_query("INSERT INTO bans SET bantype = 'user', value = '". $N ."', reason = '". $RA ."', expire = '". time() ."' + '". $D ."', added_by = '". $myrow['username'] ."', added_date = '". $date_full ."'");
mysql_query("INSERT INTO stafflogs (action, message, note, userid, timestamp) VALUES ('Bans', 'Baneo a $N', '". $myrow['rank'] ."', '". $myrow['id'] ."', '". $date_full ."')");
echo '<div class="col s12 m12">
        <div class="card-panel green">
          <span class="white-text">
		  Vous avez bannis<b>'. $N .' avec succès.</b> 
          </span>
        </div>
      </div>';
}
}
?>
      
        <div class="col s12 m12">
          <div class="card red-white darken-1">
            <div class="card-content black-text">
              <span class="card-title" style="color: #0B4C5F;">Gestiion des bans</span>
              <p>

<form action="" method="post">
<table>
<tr>
<td>Pseudo: </td><td><input type="text" name="nombre" placeholder="Pseudo" /></td>
</tr>
<tr>
<td>Temp: </td>
<td><script type="text/javascript">
function banPreset(val)
{
	document.getElementById('dura').value = val;
}
</script>

      <div class="input-control span2">
<input type="text" name="dura" size='50' id="dura" style="margin-top: 10px;" value=""> (secondes)<br /><br>
      </div>
<small>
<a href="#" onclick="banPreset(3600);">1 heure,</a>
<a href="#" onclick="banPreset(7200);">2 heures,</a>
<a href="#" onclick="banPreset(10800);">3 heures,</a> 
<a href="#" onclick="banPreset(14400);">4 heures,</a>
<a href="#" onclick="banPreset(43200);">12 heures,<br><br></a> 
<a href="#" onclick="banPreset(86400);">1 jour,</a> 
<a href="#" onclick="banPreset(259200);">3 jours,<br><br></a> 
<a href="#" onclick="banPreset(604800);">1 semaine,</a> 
<a href="#" onclick="banPreset(1209600);">2 semaines,<br><br></a> 
<a href="#" onclick="banPreset(2592000);">1 moi,</a> 
<a href="#" onclick="banPreset(7776000);">3 mois,<br><br></a> 
<a href="#" onclick="banPreset(1314000);">1 an,</a> 
<a href="#" onclick="banPreset(2628000);">2 ans,</a> 
<a href="#" onclick="banPreset(360000000);"> 10 ans</a></small></td>
</tr>
<tr>
<td>Raison: </td><td><textarea name="razon" placeholder="Raison valide obligatoire" style="width: 300px; height: 100px;"></textarea></td>
</tr>
<tr>
<td></td><td>

  <button class="btn waves-effect waves-light" type="submit">Bannir
    <i class="mdi-content-send right"></i>
  </button>

</td>
</tr>
</table>
</form>
<br>

<center><h2>Joueurs bannis</h2></center>



      <table class="centered">
  
        <thead>
		
          <tr>
		  
              <th data-field="ban">Pseudo</th>
              <th data-field="reason">Raison</th>
              <th data-field="expire">Expire</th>
			  <th data-field="banned">autheur</th>
			  <th data-field="day">jour</th>
			  <th data-field="option">Options</th>
<?php
$getbans = mysql_query("SELECT * FROM bans ORDER BY id DESC");
while($getb = mysql_fetch_assoc($getbans)){
?>	          </tr>
        </thead>

        <tbody>
          <tr>
            <td><?php echo $getb['value']; ?></td>
            <td><?php echo $getb['reason']; ?></td>
            <td><?php echo date('d/m/Y - H:i:s', $getb['expire']); ?></td>
			<td><?php echo $getb['added_by']; ?></td>
			<td><?php echo $getb['added_date']; ?></td>
			<td><a href="bans.php?do=dele&key=<?php echo $getb['id']; ?>" class="btn-floating btn-large waves-effect waves-light red"><i class="mdi-action-delete"></i></a></td>
          </tr>
<?php } ?>		  
        </tbody>
      
	  </table>


			  
			  </p>
            </div>
          </div>
        </div>
      

      </div>
	  
	  
	       
	  
</div>

</body>
</html>