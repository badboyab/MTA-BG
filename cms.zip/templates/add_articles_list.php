<div id="web_main">
   <div id="main">


        <div style="clear:both; height:20px;"></div>
        <div class="ab_title"><font><font>- News</font></font></div>

                <div style="width: 300px;float: left;">
                <div id="ul_box">

					<h3 style="color:#8c8c8c;">Dernieres nouvelles</h3>
					<?php 
$getnews = mysql_query("SELECT * FROM cms_news ORDER BY id DESC LIMIT 30");
while($list = mysql_fetch_assoc($getnews))
{
?>
					<li class="newslist"><a href="/articles/<?php echo $list['id']; ?>"><?php echo $list['title']; ?>»</a></li>
					<?php } ?>

                    <div style="height:10px;"></div>                   

                </div>
				</div>




