<?php 
  
if(isset($_GET['n'])) 
{ 
    if(!empty($_GET['n'])) // 
    { 
        $id_noticia = (int) mysql_real_escape_string($_GET['n']); 
        $query_noticias = mysql_query("SELECT * FROM cms_news WHERE id = '".$id_noticia."' LIMIT 1"); 

    	$looksn = mysql_query("SELECT look FROM users WHERE username = '{$columna['author']}'");
        $looknew = mysql_fetch_assoc($looksn);
		
        if(mysql_num_rows($query_noticias) > 0) // 
        { 
            $columna = mysql_fetch_assoc($query_noticias);
			
                echo ' 
                <div style="width: 650px;float: right;">
				<div id="ul_box">
               <b><FONT SIZE=5>'.$columna['title'].'</FONT></b><br>
                       <FONT SIZE=2>'.$columna['shortstory'].'</FONT>
<hr>					   
                        '.$columna['longstory'].'
						
                        <hr>
                            <td><i><br /><div style="float:left; width:64px; height:43px; background:url('.$Holo['avatar'] . $looknew['look'].'&amp;size=b&amp;direction=3&amp;head_direction=3&amp;gesture=sml) center -16px;"></div>
<u>Ecris le '. date('d/m/Y - H:i:s', $columna['date']) .' <br>Par <b>'.$columna['author'].'</b></u></i></td>
                    </table> 
					</div>
					<br>
                ';  
		
		}
        else 
        { 
            echo '<div style="width: 650px;float: right;">
				<div id="ul_box">
                <center><h2>Selectionne une news</h2></center>
				      La news que tu a chosisi nexiste pas.
					  <hr>
<td><i><br /><div style="float:left; width:64px; height:45px; background:url('.$Holo['avatar'] . $looknew['look'].'&amp;size=b&amp;direction=3&amp;head_direction=3&amp;gesture=sml) center -16px;"></div>
<u>Ecris le '. date('d/m/Y - H:i:s', $columna['date']) .' <br>Par <b>'.$columna['author'].'</b></u></i></td>
                    </table> 
					</div>				';  
        } 
    } 
    else 
    { 
        echo '<div style="width: 650px;float: right;">
				<div id="ul_box">
                <center><h2>
				    Vous devez sélectionner une nouvelles</h2></center>
			  </div></div>'; 
    } 
} 
else 
{ 
        echo '<div style="width: 650px;float: right;">
				<div id="ul_box">
                <center><h2>Selectionne une news</h2></center>
			  
		        Selectionne une news.
	          </div></div>
        ';  
} 
?>