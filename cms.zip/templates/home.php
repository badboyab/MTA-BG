<html style="height: 100%;"><head>
		<title><?php echo $Holo['name']; ?> • <?php echo $myrow['username']; ?></title>
<div id="web_main">
	<div id="main">
		<div class="ab_title">
			<font>- Votre page d'accueil</font>
		</div>
		<div id="user_infobox">
			<div style="float:left; width:450px;">
			<div class="userinfos" data-img="<?php echo $myrow['portada']; ?>" style="background-size: auto !important; background-image: url(&quot;<?php echo $myrow['portada']; ?>&quot;);">
					<div class="user_avatar">
						<div style="margin-bottom: 14px;width:64px;height:110px;margin-left:auto;position:relative;margin-right:auto;background:url(<?php echo $Holo['avatar'] . $myrow['look']; ?>&amp;size=b&amp;direction=3&amp;head_direction=3&amp;gesture=sml);"></div>
					</div>
					<div style="float:right;width:315px;margin-top: 35px;">
						
						<div class="playername">
							Bienvenue <strong><?php echo $myrow['username']; ?></strong>!
						</div>
						<div class="usercredits">
							<div class="CreditIcon"></div>
							<div class="cmenge"><?php echo $myrow['credits']; ?></div>
							<div style="clear:both;"></div>
						</div>
						<div class="usercredits">
							<div class="DucketIcon"></div>
							<div class="cmenge"><?php echo $myrow['activity_points']; ?></div>
							<div style="clear:both;"></div>
						</div>
						<div class="usercredits">
							<div class="DiamondIcon"></div>
							<div class="cmenge"><?php echo $myrow['vip_points']; ?></div>
							<div style="clear:both;"></div>
						</div>
						<div class="usercredits">
							<div class="GotwIcon"></div>
							<div class="cmenge">0</div>
							<div style="clear:both;"></div>
						</div>
						<div class="usermission">
							<div class="MottoIcon"></div>
							<div class="mission"><?php echo $myrow['motto']; ?></div>
							<div style="clear:both;"></div>
						</div>
					</div>
				</div>
			</div>

	        <div style="float:right; width:510px;">
				<div class="tb_box">
					<div class="title">
						Des cadeaux touts les jours !
					</div>
               Chaque utilisateur reçoit un cadeau quotidiennement		<br><br>
					<strong>Vous pouvez gagner toutes sortes de différentes Rares dedans!</strong>
					<img style="float:right; margin-right:40px; margin-top:25px;" src="<?php echo $Holo['url']; ?>/assets/images/QBJD65i.png">
					<br><br>
					<a href="#" onclick="window.open('#', 'newwindow', 'width=300, height=250'); return false;">
						<button style=";width: 150px;height: 40px;cursor: pointer;" class="tb_bonus" value="">Ouvrir !</button>
					</a>
					<div style="clear:both;"></div>
				</div>
			</div>
			
			<div style="clear:both;"></div>
			
		</div>
		
        <div style="clear:both; height:20px;"></div>
		<div class="ab_title">
			- Quoi de neuf ?
		</div>


		<div style="float: left; width: 600px;display: block;">
			<div class="carousel">
				
				<div class="carousel-inner">
					
						
							
							
							<?php 
		  $promos = mysql_query("SELECT * FROM cms_news ORDER BY id DESC LIMIT 3");
		  while($promo = mysql_fetch_assoc($promos)) {
		  ?>
							<div style="background: url(<?php echo $promo['image']; ?>);" class="item active">
								<p><?php echo $promo['title']; ?><br>
									<font size="2" color="white"><?php echo $promo['shortstory']; ?></font>
									<a href="<?php echo $Holo['url']; ?>/articles.php?n=<?php echo $promo['id']; ?>" id="NewsLinkMore">
									<button style="cursor: pointer; width: 140px;height: 40px;margin-top: -24px;float: right;" class="tb_bonus" value="">Lire plus..</button>
									</a>
								</p>
							</div>
								  <?php } ?>			
		    </div>
		</div>
</div>
		   		
	    <div style="width: 350px;float: right;">
			<div id="ul_box">
				<div class="container">

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v2.6";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-page" data-href="<?php echo $Holo['fb']; ?>" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="<?php echo $Holo['fb']; ?>"><a href="<?php echo $Holo['fb']; ?>">HabboFR</a></blockquote></div></div>
</div></div>
						    </div>				
	   
	   <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			 	    <div style="width: 600px;float: left;">
            <div id="ul_box">
				<div id="title">
					Système de référence !
				</div>
				<script type="text/javascript">
					function select_all(obj) {
						var text_val = eval(obj);
						text_val.focus();
						text_val.select();
						document.execCommand('copy');
						alert('"<?php echo $Holo['url']; ?>/profil.php?p=<?php echo $myrow['id']; ?>" Copier.');
					}
				</script>
				<p>
					 <strong><?php echo $Holo['name']; ?></strong> Nous récompenserons les utilisateurs qui invite leurs amis sur <?php echo $Holo['name']; ?>. <br>
					Pour chaque ami que vous invitez gagner 1 point de référence et un petit diamant haut vers le haut. <br><br>
					<strong><font color="red">Note:</font> Ces points accumulent, plus les utilisateurs sont invités, plus les récompenses sont obtenues.</strong>
				</p>
				<input type="text" onclick="select_all(this)" value="<?php echo $Holo['url']; ?>/profil.php?p=<?php echo $myrow['id']; ?>" style="width:100%;" readonly=""><br>
				<p>
					Vous avez un total de : <strong><?php echo $r['aantalleden']; ?></strong> parainage.
				</p>
				<div style="height:10px;"></div>
			</div> 
		</div>
					 	<hr>    <div style="width: 600px;float: left;">

            <div id="ul_box">
				<div id="title">
					Recherche d'utilisateur
				</div>
				
				<div class="container">
    
	<form action="" method="POST" name="search_form" id="search_form">
		<input type="text" name="search" id="search" style="width: 336px;" placeholder="Recherche d'utilisateurs" />
	</form>
	<br />

	<div id="resultado"></div>    
	
</div>
				<div style="height:10px;"></div>
			</div> 
		</div>
	</div>
</div>

<iframe frameborder="0" class="goog-te-menu-frame skiptranslate" style="visibility: visible; box-sizing: content-box; width: 935px; height: 263px; display: none;"></iframe></body></html>