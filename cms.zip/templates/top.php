<div id="web_main">
   <div id="main">
					<div style="float: left; width: 310px;display: block;padding-right: 15px;">
					
						<div id="ul_box">
						    <div id="title">TOP Credits</div>
						     <?php
    $sql_creditos = mysql_query("SELECT * FROM users WHERE rank < 7  ORDER BY credits DESC LIMIT 5");

    while($credit = mysql_fetch_assoc($sql_creditos)) 
    {
    ?>
							<div id="ul_box">
						    <div class="box_of1">
                            <div style="float:left; margin-bottom:-5px; width:33px; height:35px; background:url(<?php echo $Holo['avatar'] . $credit['look']; ?>&amp;size=s&amp;direction=3&amp;head_direction=3&amp;gesture=sml) center -13px;"></div>
                            <div style="float:left; width:220px; margin-left:10px;"><a href="<?php echo $Holo['url'] . '/perfil/' . $credit['username']; ?>"><b><?php echo $credit['username']; ?></b></a> <br> <?php echo $credit['credits']; ?> Créditos</div>
                            <div style="clear:both;"></div>
                            </div>
					        </div>
							
    <?php } ?>

							</div>
						
					    <div style="height:15px;"></div>
						
												
					</div>
						
					<div style="float: left; width: 310px;display: block;padding-right: 15px;">
					
						<div id="ul_box">
						    <div id="title">TOP Diamants</div>
						    <?php
    $sql_diamantes = mysql_query("SELECT * FROM users WHERE rank < 7  ORDER BY vip_points DESC LIMIT 5");

    while($diamantes = mysql_fetch_assoc($sql_diamantes)) 
    {
    ?>
							<div id="ul_box">
						    <div class="box_of1">
                            <div style="float:left; margin-bottom:-5px; width:33px; height:35px; background:url(<?php echo $Holo['avatar'] . $diamantes['look']; ?>&amp;size=s&amp;direction=3&amp;head_direction=3&amp;gesture=sml) center -13px;"></div>
                            <div style="float:left; width:220px; margin-left:10px;"><a href="<?php echo $Holo['url'] . '/perfil/' . $diamantes['username']; ?>"><b><?php echo $diamantes['username']; ?></b></a> <br> <?php echo $diamantes['vip_points']; ?> Diamantes</div>
                            <div style="clear:both;"></div>
                            </div>
					        </div>
							
    <?php } ?>


							</div>
						
					    <div style="height:15px;"></div>
						
					</div>
					
					<div style="float: left; width: 310px;display: block;">
					
						<div id="ul_box">
						    <div id="title">TOP Duckets</div>
						     <?php
    $sql_pixels = mysql_query("SELECT * FROM users WHERE rank < 7  ORDER BY activity_points DESC LIMIT 5");

    while($pixels = mysql_fetch_assoc($sql_pixels)) 
    {
    ?>
							<div id="ul_box">
						    <div class="box_of1">
                            <div style="float:left; margin-bottom:-5px; width:33px; height:35px; background:url(<?php echo $Holo['avatar'] . $pixels['look']; ?>&amp;size=s&amp;direction=3&amp;head_direction=3&amp;gesture=sml) center -13px;"></div>
                            <div style="float:left; width:220px; margin-left:10px;"><a href="<?php echo $Holo['url'] . '/perfil/' . $pixels['username']; ?>"><b><?php echo $pixels['username']; ?></b></a> <br> <?php echo $pixels['activity_points']; ?> Duckets</div>
                            <div style="clear:both;"></div>
                            </div>
					        </div>
							
    <?php } ?>


							</div>


							</div>
						
					    <div style="height:15px;"></div>
						
					</div>
					
    </div>
</div>