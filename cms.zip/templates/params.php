<style>
input[type="text"], input[type="password"], input[type="email"] {
width: 605px;"
}
</style>
<?php
// Cambiar misión
if(isset($_POST['mision']))
{
    $m = filtro($_POST['mision']);

    if(empty($m))
    {
        $aerror = '<div id="error">Ne pas laissez le champs vide</div>';
    }
    else
    {
        mysql_query("UPDATE users SET motto = '". $m ."' WHERE id = '". $myrow['id'] ."'");
        echo '<script type="text/javascript"> window.location="params.php"; </script>';
    }
}

if(isset($_POST['email_a']) && isset($_POST['email_n']) && isset($_POST['email_nr']))
{
    $EA = filtro($_POST['email_a']);
    $EN = filtro($_POST['email_n']);
    $ENR = filtro($_POST['email_nr']);

    $Checkmail = mysql_query("SELECT * FROM users WHERE mail = '". $EN ."'");

    if(empty($EA) || empty($EN) || empty($ENR))
    {
        $aerror = '<div id="error">Les champs sont vides</div>';
    }
    elseif(mysql_num_rows($Checkmail) > 0) 
    {
        $aerror = '<div id="error">L e-mail que vous avez choisis existe déjà, mettez un autre.</div>';
    }
    elseif($EN != $ENR)
    {
        $aerror = '<div id="error">Les e-mails sont differents, réessayez.</div>';
    }
    elseif($EA != $myrow['mail'])
    {
        $aerror = '<div id="error">L email est incorrect.</div>';
    }
    else
    {
        mysql_query("UPDATE users SET mail = '". $EN ."' WHERE id = '". $myrow['id'] ."'");
        $aok = '<div id="ok">Vous avez changé d email correctement</div>';
    }
}
if(isset($_POST['fb']))
{
    $FB = filtro($_POST['fb']);

    mysql_query("UPDATE users SET fb = '". $FB ."' WHERE id = '". $myrow['id'] ."'");
    $aok = '<div id="ok">Facebook ajouté avec succès</div>';
}
if(isset($_POST['ws']))
{
    $ws = filtro($_POST['ws']);

    mysql_query("UPDATE users SET ws = '". $ws ."' WHERE id = '". $myrow['id'] ."'");
    $aok = '<div id="ok">WhatsApp ajouté avec succès</div>';
}
if(isset($_POST['yt']))
{
    $yt = filtro($_POST['yt']);

    mysql_query("UPDATE users SET yt = '". $yt ."' WHERE id = '". $myrow['id'] ."'");
    $aok = '<div id="ok">YouTube ajouté avec succès</div>';
}
if(isset($_POST['sc']))
{
    $sc = filtro($_POST['sc']);

    mysql_query("UPDATE users SET sc = '". $sc ."' WHERE id = '". $myrow['id'] ."'");
    $aok = '<div id="ok">SnapChat ajouté avec succèse</div>';
}
if(isset($_POST['skype']))
{
    $skype = filtro($_POST['skype']);

    mysql_query("UPDATE users SET skype = '". $skype ."' WHERE id = '". $myrow['id'] ."'");
    $aok = '<div id="ok">Skype ajouté avec succès</div>';
}
if(isset($_POST['ig']))
{
    $ig = filtro($_POST['ig']);

    mysql_query("UPDATE users SET ig = '". $ig ."' WHERE id = '". $myrow['id'] ."'");
    $aok = '<div id="ok">Instagram ajouté avec succès</div>';
}
if(isset($_POST['youtube']))
{
    $youtube = filtro($_POST['youtube']);

    mysql_query("UPDATE users SET youtube = '". $youtube ."' WHERE id = '". $myrow['id'] ."'");
    $aok = '<div id="ok">Vídeo de YouTube ajouté avec succès</div>';
}
if(isset($_POST['about']))
{
    $about = filtro($_POST['about']);

    mysql_query("UPDATE users SET about = '". $about ."' WHERE id = '". $myrow['id'] ."'");
    $aok = '<div id="ok">Information ajouté correctement</div>';
}
if(isset($_POST['twitter']))
{
    $TW = filtro($_POST['twitter']);

    mysql_query("UPDATE users SET twitter = '". $TW ."' WHERE id = '". $myrow['id'] ."'");
    $aok = '<div id="ok">Twitter ajouté correctement</div>';
}
if(isset($_POST['portada']))
{
    $portada = filtro($_POST['portada']);

    mysql_query("UPDATE users SET portada = '". $portada ."' WHERE id = '". $myrow['id'] ."'");
    $aok = '<div id="ok">Profil modifier correctement</div>';
}

if(isset($_POST['Pass']) && isset($_POST['NPass']) && isset($_POST['RNPass']))
{
    $Pass = filtro($_POST['Pass']);
    $NPass = filtro($_POST['NPass']);
    $RNPass = filtro($_POST['RNPass']);

    $Checkpass = mysql_query("SELECT * FROM users WHERE id = '". $myrow['id'] ."'");
    $passss = mysql_fetch_assoc($Checkpass);

    if(empty($Pass) || empty($NPass) || empty($RNPass))
    {
        $aerror = '<div id="error">Ne pas laisser les champs vides</div>';
    }
    elseif($NPass != $RNPass)
    {
        $aerror = '<div id="error">Les mots de passe ne coincide pas.</div>';
    }
    elseif(md5($Pass) != $passss['password'])
    {
        $aerror = '<div id="error">L ancien mot de passe est incorrect</div>';
    }
    else
    {
        mysql_query("UPDATE users SET password = '". md5($NPass) ."' WHERE id = '". $myrow['id'] ."'");
        echo "<script type=\"text/javascript\">alert('Votre mot de passe est à jour, vous allez devoir vous reconnecter.');</script>";
        session_destroy();
        echo header("Location: /");
    }
}
?>

<?php echo $aerror . $aok; ?>

<br />
<div style="clear:both;"></div>
	</div>
</div><div id="web_main">
	<div id="main"><div style="clear:both; height:20px;"></div>
		<div class="ab_title">
			- Configuration de mon compte
		</div>
		<div style="width: 300px;float: left;">
			<div id="ul_box">
				<div id="title">Menu</div>
				<li style="padding: 10px;text-decoration: none;list-style-type: none;">
					<a href="/params">Profil</a>
				</li>
				<li style="padding: 10px;text-decoration: none;list-style-type: none;">
					<a href="/params/email">E-mail</a>
				</li>
				<li style="padding: 10px;text-decoration: none;list-style-type: none;">
					<a href="/params/pass">Mot de passe</a>
				</li>
				<div style="height:10px;"></div>
			</div>
		</div>

<?php
if(empty($_GET['a']) || !isset($_GET['a'])) {
?>

		
                <div style="width: 650px;float: right;">
<form action="" method="post">
                <div id="ul_box">

<div id="title">Mission</div>
<p>La mission est ce que les autres utilisateurs verront sur votre page de profil, et en cliquant sur l'utilisateur dans l'hôtel.</p>
<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="mision" value="<?php echo $myrow['motto']; ?>" id="aboutme">
<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>
                </div>
				<div id="ul_box">
<form action="" method="post">
                    <div id="title">Photo de profil (Image en 564x564 pixels)</div>
					<p>Votre photo de profil est affiché sur votre <strong>profil</strong>.</p>
					<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="portada" value="<?php echo $myrow['portada']; ?>" id="aboutme">
					
                    <div style="height:10px;"></div>

<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>

                </div><div id="ul_box">
<form action="" method="post">
                    <div id="title">Au sujet de moi</div>
					<p>Votre bio sera affiché sur votre  <strong>profil</strong>.</p>
					<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="about" value="<?php echo $myrow['about']; ?>" id="aboutme">
					
                    <div style="height:10px;"></div>
<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>
                    

                </div><div id="ul_box">
<form action="" method="post">
                    <div id="title">YouTube Video</div>
					<p>La video YouTube sera affiché sur votre <strong>profil</strong>.</p> 
					<p>http://www.youtube.com/watch?v=</p>
<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="youtube" value="<?php echo $myrow['youtube']; ?>" id="youtubevideo">
										
                    <div style="height:10px;"></div>

<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>

                </div><div id="ul_box">
<form action="" method="post">
                    <div id="title">Facebook</div>
					<p>Votre Facebook sera affiché sur votre <strong>profil</strong>.</p>
					<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="fb" value="<?php echo $myrow['fb']; ?>" id="aboutme">
					
                    <div style="height:10px;"></div>

<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>

                </div><div id="ul_box">
<form action="" method="post">
                    <div id="title">Twitter</div>
					<p>Votre Twitter sera affiché sur votre <strong>profil</strong>.</p>
					<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="twitter" value="<?php echo $myrow['twitter']; ?>" id="twitter">
					
                    <div style="height:10px;"></div>

<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>

                </div>
				<div id="ul_box">
<form action="" method="post">
                    <div id="title">WhatsApp</div>
					<p>Votre WhatsApp sera affiché sur votre <strong>profil</strong>.</p>
					<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="ws" value="<?php echo $myrow['ws']; ?>" id="instagram">
					
				                    <div style="height:10px;"></div>

<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>

                </div>
				<div id="ul_box">
<form action="" method="post">
                    <div id="title">Canal de YouTube</div>
					<p>Votre compte de YouTube sera affiché sur votre <strong>profil</strong>.</p>
					<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="yt" value="<?php echo $myrow['yt']; ?>" id="snog">
					
				                    <div style="height:10px;"></div>

<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>

                </div>
				<div id="ul_box">
<form action="" method="post">
                    <div id="title">Snapchat</div>
					<p>Votre compte de Snapchat sera affiché sur votre <strong>profil</strong>.</p>
					<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="sc" value="<?php echo $myrow['sc']; ?>" id="kik">
					
				                    <div style="height:10px;"></div>

<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>

                </div>
				<div id="ul_box">
<form action="" method="post">
                    <div id="title">Skype</div>
					<p>Votre compte de Skype sera affiché sur votre <strong>profil</strong>.</p>
					<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="skype" value="<?php echo $myrow['skype']; ?>" id="snapchat">
<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>
				</div>
				<div id="ul_box">
<form action="" method="post">

                    <div id="title">Instagram</div>
					<p>Votre compte de Instagram sera affiché sur votre <strong>profil</strong>.</p>
					<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="ig" value="<?php echo $myrow['ig']; ?>" id="skype">
					
                    <div style="height:75px;"></div>

<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>

                </div>
				</div>




    </div>
</div>
<?php } ?>
<?php
if($_GET['a'] == 'email') {
?>
 <div style="width: 650px;float: right;">
<form action="" method="post">
                <div id="ul_box">

<div id="title">Email actuel </div>
<p>Dans cette étape, mettre e-mail que vous utilisez</p>
<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="email_a" value="" id="aboutme">

<div id="title">Nouvel e-mail</div>
<p>Nouvel e-mail, valide de preference pour récuperez votre mot de passe si vous le perdez. </p>
<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="email_n" value="" id="aboutme">

<div id="title">Re-nouveau e-mail</div>
<p>Identique au nouvel e-mail</p>
<input style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="email_nr" value="" id="aboutme">

<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>
                </div>
				</div>
<?php } ?>
<?php
if($_GET['a'] == 'pass') {
?>
 <div style="width: 650px;float: right;">
<form action="" method="post">
                <div id="ul_box">

<div id="title">Mot de passe actuel </div>
<p>En este paso ponga Votre contraseña acual</p>
<input type="password" style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="Pass" value="" id="aboutme">

<div id="title">Nouveau mot de passe</div>
<p>Dans cette étape, vous devez placer votre nouveau mot de passe. Pensez-y, car avec ce mot de passe vous pouvez entré dans l'Hôtel </p>
<input type="password" style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="NPass" value="" id="aboutme">

<div id="title">Repete ton mot de passe</div>
<p>Identique au nouveau mot de passe</p>
<input type="password" style=" float: left;width: 570px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" name="RNPass" value="" id="aboutme">

<center><button style=";width: 200px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Appliquer</span></button></center><br /><br /><br /><br /><br /><br /><br />

</form>
                </div>
				</div>
<?php } ?>

		