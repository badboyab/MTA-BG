<div class="ab_title"><font><font>- Boutique</font></font></div>
 <div style="width: 595px;float: left;">
<div id="ul_box">
                    <div id="title"><img src="http://imgur.com/8F4Xdje.gif"> - Badge shop</div>

	<table>
		<td>
	        <h3>Badges récemment obtenus: </h3>
        </td>
        <td>
	<?php
	$Sql = mysql_query("SELECT * FROM user_badges WHERE user_id = '".$myrow['id']."' ORDER BY id DESC LIMIT 6");
	if(mysql_num_rows($Sql) < 1) echo "<br /><div style=\"padding-bottom:7px;\">Aucun badge</div>";
    while($row = mysql_fetch_assoc($Sql))
    {
	    echo '<img style="margin-right: 10px;" title="' . $row['badge_id'] . '" src="' . $Holo['url_badges'] . $row['badge_id'] . '.gif" />';
    }
	?>
	    </td>
	</table>


	<?php
	$shop_b = mysql_query("SELECT * FROM cms_badges ORDER BY id DESC LIMIT 10");
	while($shb = mysql_fetch_assoc($shop_b))
	{
		$user_got_b = mysql_query("SELECT user_id, badge_id FROM user_badges WHERE user_id = '". $myrow['id'] ."' AND badge_id = '". $shb['badge_id'] ."'");
	?>
    	<table>
    		<td width="90">
    			<img src="http://imgur.com/IDLhPy3.png"><img style="margin-right: 20px;" title="<?php echo $shb['badge_id'] ?>" src="<?php echo $Holo['url_badges'] . $shb['badge_id']; ?>.gif" />
    		</td>
    		<td width="190">
    			<h3>Quedan: <?php echo $shb['b_limit']; ?></h3>
    		</td>
    		<td width="220">
    			<h3><img src="http://i.imgur.com/VrQAUNd.png" /> <?php echo $shb['cost']; ?> diamant(s)</h3>
    		</td>
    		<td>
    			<?php
    			if(mysql_num_rows($user_got_b) > 0) {
    		    ?>
                <input type="button" style="background-color: #084B8A; border: 1px solid #073E71;" value="INVENTARIO" />
    		    <?php } elseif($shb['b_limit'] == 0) { ?>
                <input type="button" value="AGOTADA" />
    		    <?php } else { ?>
    			<form action="<?php echo $Holo['url']; ?>/success.php?b=<?php echo $shb['badge_id']; ?>" method="POST">
<button style=";width: 130px;height: 40px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Acheter</span></button>

    			</form>
    			<?php } ?>
    		</td>
    	</table>
	<?php } ?>


</div>
</div>
 <div style="width: 350px;float: right;">
<div id="ul_box">
                    <div id="title">Verifier en ligne</div>


    <?php 
	    if($myrow['online'] == '0') 
		{ 
	        echo '<div id="ok">Ce client peut acheter hors ligne sans soucis.</div>';
		}
		else
		{
			echo '<div id="error">Vous devez vous deconnectez pour acheter</div>';
		}
	?>

</div>
</div> <div style="height:120px;"></div>
 <div style="width: 350px;float: right;">
<div id="ul_box">
                    <div id="title">Diamants</div>

<p><h3><img src="http://i.imgur.com/VrQAUNd.png" /> Vous avez: <b><?php echo $myrow['vip_points']; ?></b> diamants. <img src="http://i.imgur.com/VrQAUNd.png" /></h3></p>
<p>C'est vrai, ce sont les diamates officielles de l'hôtel et servent à acheter des <strong>Badges</strong> spéciales, <strong>Rares</strong> spéciale, etc.</p>


</div></div>