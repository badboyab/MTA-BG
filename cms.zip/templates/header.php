		<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script>
			$(function() {
				var interval = 4000;
				var intervalF = setInterval(slide, interval);
				
				$('.control').click(function() {
					$('.active').removeClass('active');
					$('div.item:eq(' + $(this).data('goto') + ')').addClass('active');
					$('li.control:eq(' + $(this).data('goto') + ')').addClass('active');

					clearInterval(intervalF);
					intervalF = setInterval(slide, interval);
				});
			  
				function slide() {
					if ($('.active').is('.item:last-child')) {
						$('.active').removeClass('active');
						$('div.item').first().addClass('active');
						$('li.control').first().addClass('active');            
					} else {  
						$('div.active').removeClass('active').next().addClass('active'); 
						$('li.active').removeClass('active').next().addClass('active'); 
					}
				}
			});
		</script>
		
		<link href="http://fonts.googleapis.com/css?family=Ubuntu:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
		<link type="text/css" href="/public/css/YeezyHalloween.css" rel="stylesheet">
		<link rel="icon" href="favicon.ico" type="image/gif">
		
		

	<body style="position: relative; min-height: 100%; top: 0px;">
			<div id="header_top">
				<div id="start_width">
					<div id="header_logo">
						<div class="logo"></div>
						<div class="user_online">
							<b><?php echo Onlines(); ?></b> Joueur(s) en ligne
						</div>
					</div>
					<div id="header_hbg">
						<div id="header_button">
							<a href="/client" target="_blank">
										<button class="checkin_client" value="">
											Entrer
										</button>
										<?php if($myrow['rank'] >= $Holo['minhkr']) { ?><a href="<?php echo $Holo['url'];?>/housekeeping/index.php" target="_blank">
										<button class="checkin_client" value="">
											HK
										</button>
									</a><?php } ?>		
									</a>					
                                     
									</div>
					</div>
					
				</div>
			</div><div id="navigation">

	<div style="width: 1000px;margin: auto;">
		<div style="float:left;margin-left: 0px;width:600px;">
			<div style="float:left; width:64px; height:45px; background:url(<?php echo $Holo['avatar'] . $myrow['look']; ?>&amp;size=b&amp;direction=3&amp;head_direction=3&amp;gesture=sml) center -16px;"></div>
			<div class="dropdown">
				<a href="/me">
					<div class="nav_but"><?php echo $myrow['username']; ?><div class="me_p_arrowb"></div></div>
				</a>
				<div class="dropdown-content">
					<li><a href="/me">Accueil</a></li>
					<li><a href="<?php echo $Holo['url'] . '/profil/' . $myrow['username']; ?>">Mon profil</a></li>
					<li><a href="/params">Mes parametres</a></li>
				</div>
			</div>
			
			<div class="dropdown">
				<a href="/comunidad">
					<div class="nav_but">Communauté<div class="me_p_arrowb"></div></div>
				</a>
				<div class="dropdown-content">
					<li><a href="/communaute">Communauté</a></li>
					<li><a href="/equipe">Equipe</a></li>
					<li><a href="/articles/<?php echo $last_new['id']; ?>">News</a></li>
					<li><a href="/tops">Top 5</a></li>
				</div>
			</div>
			
			<div class="dropdown">
				<a href="/shop">
					<div class="nav_but">Boutique</div>
				</a>
				
			</div>
			
			<div class="dropdown">
				<a href="#">
					<div class="nav_but">Autre<div class="me_p_arrowb"></div></div>
				</a>
				<div class="dropdown-content">
				<li><a href="/chat">Chat de <?php echo $Holo['name']; ?> </a></li>
					
				</div>
			</div>
			
		</div>
		<div style="float:right;margin-right: 0px;width:300px;">
			<a href="/me.php?action=logout">
				<div class="nav_but_r">
					<div style="color: rgb(255, 255, 255);">
						Quitter
					</div>
				</div>
			</a>
					</div>
		<div style="clear:both;"></div>
	</div>
</div>









<?php if(MANTENIMIENTO == '1') { ?><a href="<?php echo $Holo['url']; ?>/mantenimiento"><div class="mant-check"><?php echo $Holo['name']; ?> est en maintenance.</div></a><?php } ?>