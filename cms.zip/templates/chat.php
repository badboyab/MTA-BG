 <div id="web_main">
   <div id="main">
   <div class="ab_title"><font><font>- Chat habbo</font></font></div>

<div style="width: 340px;float: left;">
<div style="min-height: 195px;" id="ul_box">
                    <div id="title">Rejoignez le chat</div>


        <?php echo $error . $ok; ?>
    
        <form action="" method="POST">
		<div style="float:left; width:40px; height:50px; background:url(<?php echo $Holo['avatar'] . $myrow['look']; ?>&amp;size=b&amp;direction=3&amp;head_direction=3&amp;gesture=sml) center -16px;"></div>
<textarea placeholder="Ecris ici pour commentez" style="width: 200px; height: 80px; line-height: 35px; font-size: 13px; color: rgba(0, 0, 0, 0.901961); padding: 0px 0px 0px 15px; border-radius: 5px; margin: 0px 25px 10px; border-width: 1px 1px 2px; border-style: solid; border-color: rgba(0, 0, 0, 0.2); border-image: initial; box-shadow: rgba(0, 0, 0, 0.0470588) 0px 0px 2px;" class="form-control" name="comments" rows="3" id="reden"></textarea>
<button style="float:right; width:120px; height:40px; center -16px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Envoyez</span></button>
        </form>
    </div></div>


 <div style="width: 615px;float: right;">
<div id="ul_box">
	<?php
    $sqlcomments = mysql_query("SELECT * FROM cms_comments_grupal ORDER BY id DESC LIMIT 3000");
    if(mysql_num_rows($sqlcomments) == 0) {
    		echo '<center><h2>Pas encore de discussion</h2></center>';
    	}
    while($comments_n = mysql_fetch_assoc($sqlcomments)) {
    	$sqlusersc = mysql_query("SELECT * FROM users WHERE username = '". $comments_n['added_by'] ."'");
        $usersc = mysql_fetch_assoc($sqlusersc);
	?>
	<div id="comments1">
			<div style="float:left; width:60px; height:50px; background:url(<?php echo $Holo['avatar'] . $usersc['look']; ?>&action=wav,crr=6&gesture=sml&direction=3&head_direction=3&size=m) center -16px;"></div>
        <div id="comentario">
		    <?php if($myrow['username'] == $comments_n['added_by']) { ?><form action="<?php echo $Holo['url']; ?>/chat.php?do=dele&key=<?php echo $comments_n['id']; ?>&n=<?php echo $_GET['n']; ?>" method="POST"><button type="submit"><span class="icon-trash" style="float: right;"></span></button></form><?php } ?>
            <?php echo '<a href="' . $Holo['url'] . '/perfil/' . $usersc['username'] .'" style="color: #000; text-decoration: underline;"><b>' . $usersc['username'] . '</b></a> - ' . $comments_n['added_date']; ?>
            <br />
            <font color="black"><?php echo $comments_n['comentario']; ?></font>
        </div>
    </div>
    <br />
	<?php } ?>

</div></div></div></div>
