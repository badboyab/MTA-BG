<div style="width: 650px;float: left;">
                <div id="ul_box">
									<h3 style="color:#8c8c8c;">Commentaires</h3>


        <?php echo $error . $ok; ?>
    
        <form action="" method="POST">
		<div style="float:left; width:40px; height:50px; background:url(<?php echo $Holo['avatar'] . $myrow['look']; ?>&amp;size=b&amp;direction=3&amp;head_direction=3&amp;gesture=sml) center -16px;"></div>
<textarea placeholder="Ecris ici ton commentaires" style="width: 370px; height: 50px; line-height: 35px; font-size: 13px; color: rgba(0, 0, 0, 0.901961); padding: 0px 0px 0px 15px; border-radius: 5px; margin: 0px 25px 10px; border-width: 1px 1px 2px; border-style: solid; border-color: rgba(0, 0, 0, 0.2); border-image: initial; box-shadow: rgba(0, 0, 0, 0.0470588) 0px 0px 2px;" class="form-control" name="comments" rows="3" id="reden"></textarea>
<button style="float:right; width:120px; height:40px; center -16px;" type="submit" class="tb_bonus" value=""><span style="cursor: pointer">Envoyez</span></button>
        </form>
    </div>


<div class="container">

	<?php
    $sqlcomments = mysql_query("SELECT * FROM cms_comments_news WHERE notice_id = '". $_GET['n'] ."' ORDER BY id DESC LIMIT 30");
    if(mysql_num_rows($sqlcomments) == 0) {
    		echo '<center><h2>Pas encore de commentaire sur cet article</h2></center>';
    	}
    while($comments_n = mysql_fetch_assoc($sqlcomments)) {
    	$sqlusersc = mysql_query("SELECT * FROM users WHERE username = '". $comments_n['added_by'] ."'");
        $usersc = mysql_fetch_assoc($sqlusersc);
	?>
	<div id="comments">
			<div style="float:left; width:60px; height:50px; background:url(<?php echo $Holo['avatar'] . $usersc['look']; ?>&action=wav,crr=6&gesture=sml&direction=3&head_direction=3&size=m) center -16px;"></div>
        <div id="comentario">
		    <?php if($myrow['username'] == $comments_n['added_by']) { ?><form action="<?php echo $Holo['url']; ?>/articles.php?do=dele&key=<?php echo $comments_n['id']; ?>&n=<?php echo $_GET['n']; ?>" method="POST"><button type="submit"><span class="icon-trash" style="float: right;"></span></button></form><?php } ?>
            <?php echo '<a href="' . $Holo['url'] . '/perfil/' . $usersc['username'] .'" style="color: #000; text-decoration: underline;"><b>' . $usersc['username'] . '</b></a> - ' . $comments_n['added_date']; ?>
            <br />
            <?php echo $comments_n['comentario']; ?>
        </div>
    </div>
    <br />
	<?php } ?>

</div></div></div></div></div>