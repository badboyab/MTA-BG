
<style>
#profil_box {
	position: relative;
	background: #f7f7f7;
	height: 200px;
	border: 1px solid #e7e7e7; 
	border-bottom: none;
	margin-bottom: 0px;
}
#profil_box_avatar {
	position: absolute;
	bottom: 0px;
	left: 0px;
	width: 180px;
	height: 160px;
	padding-top: 40px;
	text-align: center;
	z-index: 30;
}

#profil_box_avatar_bg {
	position: relative;
	top: 0px;
	left: 0px;
	float:left;
	margin-left: 20px;
	width: 180px;
	height: 200px;
	border-right: 1px solid #e0e0e0; 
	z-index: 20;
	background: url(http://imgur.com/sNVyJPD.png);
	overflow: hidden;
}
#profil_box_avatar_curtaint {
	position: absolute;
	top: 0px;
	left: 0px;
	width: 180px;
	height: 11px;
	z-index: 60;
	background: url(http://habbowert.de/uploads/images/system/vorhang_top.png);
}
#profil_box_avatar_curtainl {
	position: absolute;
	top: 0px;
	left: 0px;
	width: 90px;
	height: 200px;
	z-index: 50;
	background: url(http://habbowert.de/uploads/images/system/vorhang_left.png) no-repeat;
	background-position: right -22px;
}
#profil_box_avatar_curtainr {
	position: absolute;
	top: 0px;
	right: 0px;
	width: 90px;
	height: 200px;
	z-index: 50;
	background: url(http://habbowert.de/uploads/images/system/vorhang_right.png) no-repeat;
	background-position: 0px -22px;
}
#profil_box_name {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 180px;
    height: 25px;
    line-height: 25px;
    font-size: 13px!important;
    background: #fff;
    color: #12556D;
    font-weight: bold;
    text-align: center;
    z-index: 40;
}
@keyframes animate-bg-left {
    from {
        left: 0px;
    }
    to {
       left: -100px;
    }
}
@keyframes animate-bg-right {
    from {
        right: 0px;
    }
    to {
       right: -100px;
    }
}
</style>
<div id="web_main">
   <div id="main">


                <div style="clear:both; height:20px;"></div>
                <div class="ab_title"><font>- Equipe administrative</font></div>

                <div style="width: 300px;float: left;">
                				
				<div style="max-height: 210px;" id="ul_box">
                <div id="title">A propos de l'equipe</div>
				
Nous, l'équipe de l'hôtel sont responsables de la sécurité au sein de l'hôtel. Si vous rencontrez des problèmes graves ou des problèmes avec un autre joueur, vous pouvez contacter nos modérateurs à tout moment. <br><br> En plus de sécurité, nous fournissons également amusement et de divertissement autour de l'hôtel. Ceci est important parce que nous ne voulons pas que nos utilisateurs se lassent. Si aucun événement prend événement, vous pouvez organiser un événement privé dans votre propre chambre!
                </div>
				
				<div style="height:15px;"></div>
				
		        <div style="min-height: 220px;" id="ul_box">
							<?php
$rango = mysql_query("SELECT * FROM ranks ORDER BY id DESC LIMIT 1");
while($rank = mysql_fetch_assoc($rango)) {
?>

                               <div id="title">Fondateur</div>
<?php
$users = mysql_query("SELECT * FROM users WHERE rank = '". $rank['id'] ."'");
if(mysql_num_rows($users) == 0) { 
echo '<b><center>Il n as pas de '. $rank['name'] .'.</center></b><div style="height:10px;">				
				'; 
}
while($staffss = mysql_fetch_assoc($users))
{
?>                

								<a href="<?php echo $Holo['url'] . '/profil/' . $staffss['username']; ?>">
<div id="profil_box_avatar_bg" style="margin: 0px 40px;background: url(<?php echo $staffss['portada']; ?>);">
<div id="profil_box_avatar">
<img style="    -webkit-filter: drop-shadow(0 1px 0 #fff) drop-shadow(0 -1px 0 #fff) drop-shadow(1px 0 0 #fff) drop-shadow(-1px 0 0 #fff) drop-shadow(0 0 10px rgba(000,000,000,000));opacity:<?php if($staffss['online'] == '0') { echo '0.5'; } else { echo '1'; } ?>" src="<?php echo $Holo['avatar'] . $staffss['look']; ?>&amp;size=b&amp;direction=3&amp;head_direction=3&amp;gesture=sml">
</div>
<div id="profil_box_name">
<span class="profil_box_name_staff admin"><?php echo $staffss['username']; ?></span>
</div>
<div id="profil_box_name" style="
    margin-top: 175;
">

  <span class="profil_box_name_staff admin"><?php echo $staffss['username']; ?></span>
</div>
<div id="profil_box_avatar_curtaint" style="display: none;">
</div>
<div id="profil_box_avatar_curtainl" style="animation: animate-bg-left 5s normal forwards ease-in-out;;">
</div>
<div id="profil_box_avatar_curtainr" style="animation: animate-bg-right 5s normal forwards ease-in-out;;">
</div>
							   <?php } ?>
							   </div>
							   <?php } ?>

								</a>
                <div style="height:10px;"></div>
					
                </div>				
		        </div>
				
                <div style="width: 650px;float: right;">
				
					<?php
$rango = mysql_query("SELECT * FROM ranks WHERE id >= 3 AND id <= 9 ORDER BY id DESC");
while($rank = mysql_fetch_assoc($rango)) {
?>               
	            <div style="min-height: 230px;" id="ul_box">
                <div id="title"><?php echo $rank['name']; ?></div>
<?php
$users = mysql_query("SELECT * FROM users WHERE rank = '". $rank['id'] ."'");
if(mysql_num_rows($users) == 0) { 
echo '<b><center>Il n as pas de '. $rank['name'] .'.</center></b>'; 
}
while($staffs = mysql_fetch_assoc($users))
{
?>
                                    
                
									<a href="<?php echo $Holo['url'] . '/profil/' . $staffs['username']; ?>">
<div id="profil_box_avatar_bg" style="background: url(<?php echo $staffs['portada']; ?>);">
<div id="profil_box_avatar">
<img style="    -webkit-filter: drop-shadow(0 1px 0 #fff) drop-shadow(0 -1px 0 #fff) drop-shadow(1px 0 0 #fff) drop-shadow(-1px 0 0 #fff) drop-shadow(0 0 10px rgba(000,000,000,000));opacity:<?php if($staffs['online'] == '0') { echo '0.5'; } else { echo '1'; } ?>" src="<?php echo $Holo['avatar'] . $staffs['look']; ?>&amp;size=b&amp;direction=3&amp;head_direction=3&amp;gesture=sml">
</div>
<div id="profil_box_name">
<span class="profil_box_name_staff admin"><?php echo $staffs['username']; ?></span>
</div>
<div id="profil_box_name" style="
    margin-top: 175;
">

  <span class="profil_box_name_staff admin"><?php echo $staffs['username']; ?></span>
</div>
<div id="profil_box_avatar_curtaint" style="display: none;">
</div>
<div id="profil_box_avatar_curtainl" style="animation: animate-bg-left 5s normal forwards ease-in-out;;">
</div>
<div id="profil_box_avatar_curtainr" style="animation: animate-bg-right 5s normal forwards ease-in-out;;">
</div>
</div>
									</a>
				               
<?php }  ?>

									</div>

				<div style="height:15px;"></div>
				<?php }  ?>
				
				
				</div>

    </div>
</div>


		