<?php

require_once("../engine/core.cms.php");

$search = '';
if(isset($_POST['search'])) {
	$search = $_POST['search'];
}
$consulta = mysql_query("SELECT * FROM users WHERE username LIKE '%". $search ."%' ORDER BY id ASC LIMIT 5");
$fila = mysql_fetch_assoc($consulta);
$total = mysql_num_rows($consulta);

if($total > 0 && $search !='') { 
do {
?> 
<div style="float:center; width:64px; height:45px; background:url(<?php echo $Holo['avatar'] . $fila['look']; ?>&amp;size=b&amp;direction=3&amp;head_direction=3&amp;gesture=sml) center -16px;"></div>
<hr>
<a class="a-search" style="color: #000000;" href="<?php echo $Holo['url']; ?>/perfil/<?php echo $fila['username']; ?>"><font style="margin-left: 20px;"><b><?php echo str_replace($search, '<strong>'. $search .'</strong>', utf8_encode($fila['username'])); ?></b> - Voir profil</font></a>
<br />
<?php
} while($fila = mysql_fetch_assoc($consulta)); 

} elseif(empty($search)) { 
echo ''; 
} else {
echo 'Aucun résultat';
}
?>	