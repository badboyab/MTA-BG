<html style="height: 100%;"><head>
<?php
if(isset($_GET['p']))
{
	if(!empty($_GET['p']))
	{

		$name_user = mysql_real_escape_string($_GET['p']);
	    $query_user = mysql_query("SELECT * FROM users WHERE username = '". $name_user ."'");
	    if(mysql_num_rows($query_user) > 0)
	    {
	    	$perfil = mysql_fetch_assoc($query_user)
?>
<div id="web_main">
    <div id="main">
<div class="ab_title"><font><font>- Profil de <?php echo $perfil['username']; ?></font></font> <FONT SIZE=2>(<?php if($perfil['online'] == '1') { echo 'est en ligne'; } elseif($perfil['last_online'] == '0') { echo 'n est pas en ligne.'; } else { echo 'Connexion: ' . date('d/m/Y - H:i:s', $perfil['last_online']); } ?>)</FONT></div>
        <div id="user_infobox">

            <div style="float:left; width:450px;">

				<div class="userinfos" data-img="<?php echo $perfil['portada']; ?>" style="background-size: auto !important; background-image: url(&quot;<?php echo $perfil['portada']; ?>&quot;);">


                    <div class="user_avatar">

                        <div style="margin-bottom: 14px;width:64px;height:110px;margin-left:auto;position:relative;margin-right:auto;background:url(<?php echo $Holo['avatar'] . $perfil['look']; ?>&amp;size=b&amp;direction=3&amp;head_direction=3&amp;gesture=sml);"></div>
                        

                    </div>


                    <div style="float:right;width:315px;margin-top: 35px;">
                        <div class="playername">Profil de <b><?php echo $perfil['username']; ?></b>! <FONT SIZE=1>(<?php echo 'Crée le: ' . date('d/m/Y (H:i:s)', $perfil['date_created']); ?>)</font></div>

                        <div class="usercredits">
                            <div class="CreditIcon"></div>
                            <div class="cmenge"><?php echo $perfil['credits']; ?></div>
                            <div style="clear:both;"></div>
                        </div>

                        <div class="usercredits">
                            <div class="DucketIcon"></div>
                            <div class="cmenge"><?php echo $perfil['activity_points']; ?></div>
                            <div style="clear:both;"></div>
                        </div>

                        <div class="usercredits">
                            <div class="DiamondIcon"></div>
                            <div class="cmenge"><?php echo $perfil['vip_points']; ?></div>
                            <div style="clear:both;"></div>
                        </div>

                        <div class="usercredits">
                            <div class="GotwIcon"></div>
                            <div class="cmenge">0</div>
                            <div style="clear:both;"></div>
                        </div>

                        <div class="usermission">
                            <div class="MottoIcon"></div>
                            <div class="mission"><?php echo $perfil['motto']; ?></div>
                            <div style="clear:both;"></div>
                        </div>
						


                    </div>

                </div>

            </div>

            <div style="float:right; width:510px;">

                <div class="tb_box">
<div class="title">À propos de <?php echo $perfil['username']; ?></div>
                   <p style="float: left;"><?php echo $perfil['about']; ?></p><img style="float: right;" src="http://imgur.com/RhK97f5.png">

                    <div style="clear:both;"></div>
                </div>

            </div>

            <div style="clear:both;"></div>
        </div>

        <div style="clear:both; height:20px;"></div>

<div style="float: left; width: 600px;display: block;">

<iframe width="600" height="280" src="https://www.youtube.com/embed/<?php echo $perfil['youtube']; ?>" frameborder="0" allowfullscreen=""></iframe>

                </div>
                <div style="width: 360px;float: right;">

                <div id="ul_box">

                    <div id="title">Réseaux sociaux:</div>
<b><img src="/public/img/homes/fbicon.png"><font> Facebook:</font></b><font> <?php echo $perfil['fb']; ?> </font><br><br>
<b><img src="/public/img/homes/twittericon.png"><font> Twitter:</font></b><font> <?php echo $perfil['twitter']; ?> </font><br><br>
<b><img src="/public/img/homes/wsicon.png"><font> WhatsApp:</font></b><font> <?php echo $perfil['ws']; ?></font><br><br>
<b><img src="/public/img/homes/youicon.png"><font> YouTube:</font></b><font> <?php echo $perfil['yt']; ?></font><br><br>
<b><img src="/public/img/homes/snapchaticon.png"><font> Snapchat:</font></b><font> <?php echo $perfil['sc']; ?></font><br><br>
<b><img src="/public/img/homes/skypeicon.png"><font> Skype:</font></b><font> <?php echo $perfil['skype']; ?></font><br><br>
<b><img src="/public/img/homes/instagramicon.png"><font> Instagram:</font></b><font> <?php echo $perfil['ig']; ?></font>

                    <div style="height:10px;"></div>

                    

                </div></div>


    </div>
</div>

		<div style="clear:both; height:20px;"></div>
		<?php
	    }
	    else
	    {
	    	echo '<center><b>Le profil que vous cherchez n existe pas.</b></center>';
	    }
	}
	else 
	{
		echo '<center><b>Vous devez choisir un profil.</b></center>';
    }
}
else
{
	echo '<center><b>Vous devez choisir un profil.</b></center>';
}
?>
<div style="width: 595px;float: left;">
			<div id="ul_box">
				<div class="container">
<?php
if(isset($_GET['p']))
{
	if(!empty($_GET['p']))
	{

		$name_user = mysql_real_escape_string($_GET['p']);
	    $query_user = mysql_query("SELECT * FROM users WHERE username = '". $name_user ."'");
	    if(mysql_num_rows($query_user) > 0)
	    {

	    	$perfil = mysql_fetch_assoc($query_user)
?>
<div id="title"><?php if($perfil['username'] != $myrow['username']) { echo 'Rooms de ' . $perfil['username']; } else { echo 'Rooms'; } ?></div>
    <?php 
		$rooms = mysql_query("SELECT * FROM rooms WHERE owner='".$perfil['id']."' ORDER BY users_now DESC");
		if(mysql_num_rows($rooms) == 0) {
			echo 'Pas de rooms';
		}
        	while($room = mysql_fetch_assoc($rooms)) {
        		if ($room['state'] == "open") {
					$state = "; display: none;";
				} elseif ($room['state'] == "locked") {
					$state = "20px -45px";
				} elseif ($room['state'] == "password") {
					$state = "20px -61px";
				}
				if($room['group_id'] > 0) {
					$group = "
						<div class='group-icon'></div>
						";
				} else {
					$group = "";
				}
        ?>
		<div id="salas-users" style="background-position: 
		<?php
		if ($room['users_now'] == 0) {
				echo "0 0";
			} elseif ($room['users_now'] >= $room['users_max']-2) {
				echo "0 -54px";
			} elseif ($room['users_now'] >= $room['users_max']/2) {
				echo "0 -36px";
			} elseif ($room['users_now'] > 0) {
				echo "0 -18px";
			} 
        echo ';"><span class="icon-user"></span>' . $room['users_now'] . '<span class="name">' . $room['caption'] . '</span>
        <div id="stateroom" style="background-position:' . $state . '"></div>
        ' . $group .'
		</div>'; 
        	}
	    }
	    else
	    {
	    	echo '<center><b>Le profil que vous cherchez n existe pas.</b></center>';
	    }
	}
	else 
	{
		echo '<center><b>Vous devez choisir un profil.</b></center>';
    }
}
else
{
	echo '<center><b>Vous devez choisir un profil.</b></center>';
}

?>
</div>
</div>
</div>

<div style="width: 350px;float: right;">
			<div id="ul_box">
				<div class="container">
<?php
if(isset($_GET['p']))
{
	if(!empty($_GET['p']))
	{

		$name_user = mysql_real_escape_string($_GET['p']);
	    $query_user = mysql_query("SELECT * FROM users WHERE username = '". $name_user ."'");
	    if(mysql_num_rows($query_user) > 0)
	    {
	    	$perfil = mysql_fetch_assoc($query_user)
?>
<div id="title"><?php if($myrow['id'] == $perfil['id']) { echo 'Badges'; } else { echo 'Badge de ' . $perfil['username']; } ?></div>
<?php
$badges_perfil = mysql_query("SELECT * FROM user_badges WHERE user_id = '" . $perfil['id'] ."' AND badge_slot > 0 ORDER BY badge_slot ASC LIMIT 10");
if(mysql_num_rows($badges_perfil) == 0) {
	echo 'Pas de badge';
}
while($bp = mysql_fetch_assoc($badges_perfil))
{
?>

<div id="placas-perfil"><img src="<?php echo $Holo['url_badges'] . $bp['badge_id'] .'.gif'; ?>" /></div>

<?php
}

	    }
	    else
	    {
	    	echo '<center><b>Le profil que vous cherchez n existe pas.</b></center>';
	    }
	}
	else 
	{
		echo '<center><b>Vous devez choisir un profil.</b></center>';
    }
}
else
{
	echo '<center><b>Vous devez choisir un profil.</b></center>';
}
?>

</div>
</div>


			<div id="ul_box">
				<div class="container">
<?php
if(isset($_GET['p']))
{
	if(!empty($_GET['p']))
	{

		$name_user = mysql_real_escape_string($_GET['p']);
	    $query_user = mysql_query("SELECT * FROM users WHERE username = '". $name_user ."'");
	    if(mysql_num_rows($query_user) > 0)
	    {
	    	$perfil = mysql_fetch_assoc($query_user)
?>
<div id="title"><?php if($myrow['id'] == $perfil['id']) { echo 'Groupes'; } else { echo 'Groupe de ' . $perfil['username']; } ?></div>
<?php
$group_perfil = mysql_query("SELECT * FROM groups WHERE owner_id = '" . $perfil['id'] ."' ORDER BY id DESC");
if(mysql_num_rows($group_perfil) == 0) {
	echo 'Pas de groupes';
}
while($gp = mysql_fetch_assoc($group_perfil))
{
?>
<div id="placas-perfil"><center><h5><span><?php echo $gp['name']; ?>&darr;</span></h5></center><img src="http://localhost/habbo-imaging/badge/<?php echo $gp['badge'] .'.gif'; ?>" /></div>

<?php
}

	    }
	    else
	    {
	    	echo '<center><b>Le profil que vous cherchez n existe pas.</b></center>';
	    }
	}
	else 
	{
		echo '<center><b>Vous devez choisir un profil.</b></center>';
    }
}
else
{
	echo '<center><b>Vous devez choisir un profil.</b></center>';
}
?>

</div>
</div>
</div>


<iframe frameborder="0" class="goog-te-menu-frame skiptranslate" style="visibility: visible; box-sizing: content-box; width: 935px; height: 263px; display: none;"></iframe></body></html>