<div style="clear:both; height:20px;"></div>
		<div class="ab_title">
			- Communauté
		</div>


		<div style="float: left; width: 600px;display: block;">
			<div class="carousel">
				
				<div class="carousel-inner">
					
						
							
							
							<?php 
		  $promos = mysql_query("SELECT * FROM cms_news ORDER BY id DESC LIMIT 3");
		  while($promo = mysql_fetch_assoc($promos)) {
		  ?>
							<div style="background: url(<?php echo $promo['image']; ?>);" class="item active">
								<p><?php echo $promo['title']; ?><br>
									<font size="2" color="white"><?php echo $promo['shortstory']; ?></font>
									<a href="<?php echo $Holo['url']; ?>/articles.php?n=<?php echo $promo['id']; ?>" id="NewsLinkMore">
									<button style="cursor: pointer; width: 140px;height: 40px;margin-top: -24px;float: right;" class="tb_bonus" value="">Lire plus...</button>
									</a>
								</p>
							</div>
								  <?php } ?>			
		    </div>
		</div>
</div>
<div style="width: 350px;float: right;">
			<div id="ul_box">
				<div id="title">
					Rooms peuplée
				</div>
				<?php 
		  $data = mysql_query("SELECT * FROM rooms ORDER BY users_now DESC LIMIT 3");
		  while($room = mysql_fetch_assoc($data)) {
		  ?>
				  

						<li class="odd">
							<span class="clearfix enter-room-link " "="" title="" roomid="<?php echo $room['id']; ?>">
								<div class="hot-rooms">
									<div id="room-image"></div>
									<span class="room-name">
										<strong><?php echo $room['caption']; ?></strong> 
										<?php echo $room['users_now']; ?>/<?php echo $room['users_max']; ?>
									</span>   
								</div>
							</span>
						</li>
							   <?php } ?>

										<div style="height:9px;"></div>
			</div>
		</div>
<iframe frameborder="0" class="goog-te-menu-frame skiptranslate" style="visibility: visible; box-sizing: content-box; width: 935px; height: 263px; display: none;"></iframe></body></html>