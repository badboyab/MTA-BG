<?php


require_once("engine/core.cms.php");

if(Loged == FALSE)
{
	header("Location: /");
	exit;
}
if(mysql_num_rows($chb) == 0) 
{
    header("Location: " . $Holo['url'] ."");
	exit;
}

$chbe = mysql_fetch_assoc($chb);

if($chbe['expire'] <= time()) {
    mysql_query("DELETE FROM bans WHERE value = '". $myrow['username'] ."' OR value = '". $myrow['ip_last'] ."'");
    header("Location: " . $Holo['url'] ."");
    exit;
}
?>

<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link rel="shortcut icon" href="<?php echo $Holo['url']; ?>/favicon.ico" type="image/vnd.microsoft.icon" />
        <link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Maven+Pro' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Pinyon+Script' rel='stylesheet' type='text/css'>
        <script type="text/javascript" src="http://code.jquery.com/jquery-2.1.0.min.js"></script>
		<link rel="stylesheet" type="text/css" href="<?php echo $Holo['url']; ?>/assets/css/banned.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo $Holo['url']; ?>/assets/fonts/style.css" />

            <title><?php echo $Holo['name']; ?> : Has sido baneado</title>

    </head>
<body>
    <center>
        <h1>¡HAS SIDO BANEAD@ DEL HOTEL!</h1>
	</center>	
    
	<p>
	    "<?php echo $chbe['reason']; ?>"
	    <br /><br />
		Expira: <?php echo date('d/m/Y - H:i:s', $chbe['expire']); ?>
		<br />
		Banead@ por: <?php echo $chbe['added_by']; ?>
		<br />
		Te banearon el día: <?php echo $chbe['added_date']; ?>
		<br />
	</p>
	
	<div class="footer"><center><?php echo $Holo['footer']; ?></center></div>
	
</body>
</html>