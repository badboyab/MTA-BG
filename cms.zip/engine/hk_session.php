<?php
/* 
*
*                  Yeezy IV
*  Todos los derechos reservados a su respectivo dueño
* 
*          @Author: Forbi <based Totix>
*
*/

## Hacemos el login a la HK

if(isset($_POST['HUsername']) && isset($_POST['HPassword']))
{

$HU = $_POST['HUsername'];
$HP = $_POST['HPassword'];

## Seleccionamos el usuario introducido
$GetuserH = mysql_query("SELECT * FROM users WHERE username = '". $HU ."' AND password = '". md5($HP) ."'");

## Checamos que los campos del login esten llenos.
if(empty($HU) || empty($HP))
{
    $msg = '<div id="error">Los datos estan vacíos, llenalos.</div>';  // Si estan vacios, lanza error.
}
## Checamos que tenga el rango suficiente para entrar a la HK.
elseif($myrow['rank'] <= $MINHKR) 
{
    $msg = '<div id="error">No tienes el rango suficiente para entrar a la HK</div>';
}
##Checamos que el usuario exista.
elseif(mysql_num_rows($GetuserH) == 0)
{
    $msg = '<div id="error">El usuario no existe o la contraseña es incorrecta</div>'; // Si no existe, lanza error
}

## Si no hubo error, obtenemos sus datos y se loguea.
else
{
    ## Hacemos la sesion checando que el usuario exista.
	if(mysql_num_rows($GetuserH) > 0)
	{
	$_SESSION['HUsername'] = $HU;
	$_SESSION['HPassword'] = $HP;
	mysql_query("INSERT INTO stafflogs (action, message, note, userid, timestamp) VALUES ('Housekeeping', 'Entro al panel de administracion', '". $myrow['rank'] ."', '". $myrow['id'] ."', '". $date_full ."')");
	}
}
}

## Obtenemos su sesion
## Si estan definidas las variables de sesion ejecuta el resto
if(isset($_SESSION['HUsername']) && isset($_SESSION['HPassword']))
{
$HSU = $_SESSION['HUsername'];
$HSP = $_SESSION['HPassword'];

## Obtenemos el usuario

$GetUserH = mysql_query("SELECT * FROM users WHERE username = '". $HSU ."' AND password = '". md5($HSP) ."'");
if(mysql_num_rows($GetUserH) > 0)
{
   ## Nombramos sus datos
   $myrow = mysql_fetch_assoc($GetUserH);
   define("UserH", true);
}
} else {
   define("UserH", false);
}

?>