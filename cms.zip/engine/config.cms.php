﻿<?php

class Conexion {
	public function MySQL() {

		// ID de la Database
		$mysqld = array (
			'host'  =>  'localhost',
			'user'  =>  'root',
			'pass'  =>  'habbo',
			'db'    =>  'db'
			);

		// Connexion MySQL
		mysql_connect($mysqld['host'], $mysqld['user'], $mysqld['pass']) or die(mysql_error());
		mysql_select_db($mysqld['db']) or die(mysql_error());
	}
}

// Nous importons la connexion
Conexion::MySQL();

// Paramètres de votre retro
$Holo = array(

	// Lien du retro
	'url'       =>     'http://localhost',
	// Lien du client
	'client_url'=>     'http://localhost/client',
	// URL du logo habbo, format 250x90
	'logo'      =>     'http://localhost/assets/images/logo.png',
	// Dossier HK
	'panel'     =>     'housekeeping',
    // Nom du retro
	'name'      =>     'Habbo',
    // Mission a linscription
    'mision'    =>     'Nouveau sur Habbo',
    // Piece a linscription
    'monedas'   =>     '5',
	// Rang maximum pour la HK
	'maxrank'   =>     '10',
	// Rango minimum pour la HK
	'minhkr'    =>     '8',
	// Facebook oficie 
	'fb'        =>     'https://facebook.com/habbofr/',
    // Photo de profil
    'foto_p'    =>     '/assets/images/perfil_default.png',
    // Bio par default
    'portada'   =>     '/assets/images/me_page.jpg',
	// Footer 
	'footer'    =>     '
		<div style="position: absolute; width:100%;" class="footer">
            <div id="swidth">
               <center> <font size="2" color="white">
<p style="line-height: 1px;">© 2016 Crée pour <a href="#" style="color: inherit;text-decoration:none;">HABBO</a>. En aucun cas liée à Sulake Corp Oy. </p>
					
				</font></center>
            </div>
        </div>',
	// URL avatar
	'avatar'    =>     'https://www.habbo.com/habbo-imaging/avatarimage?figure=',
	// URL badges
	'url_badges'=>     'http://localhost/swf/c_images/album1584/'

	
	);
?>