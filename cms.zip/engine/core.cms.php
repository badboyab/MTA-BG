<?php

session_start();
define("DR", $_SERVER['DOCUMENT_ROOT']);
define('CHARSET', 'UTF-8');
header('Content-type: text/html; charset='.CHARSET);
ini_set('display_errors', 0);

if(file_exists(DR .'/engine/config.cms.php')) {
    require_once('config.cms.php');
} else { 
    require_once('config.cms.php');
}

// Fecha
$H = date('H');
$i = date('i');
$s = date('s');
$m = date('m');
$d = date('d');
$Y = date('Y');
$j = date('j');
$n = date('n');
$today = $d;
$month = $m;
$year = $Y;
$getmoney_date = date('d/m/Y',mktime($m,$d,$Y));
$birthday_date = date('d/m', mktime($m,$d));
$date_normal = date('d/m/Y',mktime($m,$d,$Y));
$date_full = date('d/m/Y - H:i:s',mktime($H,$i,$s,$m,$d,$Y));

// Última conexión
function GetLast($a){
		if(!empty($a) || !$a == ''){
			if(is_numeric($a)){
				$date = $a;
				$date_now = time();
				$difference = $date_now - $date;
				if($difference <= '59'){ $echo = 'Hace '. $difference .' segundo(s)'; }
				elseif($difference <= '3599' && $difference >= '60'){ 
					$minutos = date('i', $difference);
					if($minutos[0] == 0) { $minutos = $minutos[1]; }
					if($minutos == 1) { $minutos_str = 'minuto'; }
					else { $minutos_str = 'minutos'; }
					$echo = 'Hace '.$minutos.' '.$minutos_str;//Minutos
				}elseif($difference <= '86399' && $difference >= '3600') {
				    $horas = floor(date('H', $difference));
					if($horas == 1) { $horas_str = 'hora'; }
					else { $horas_str = 'horas'; }
					$echo = 'Hace '.$horas.' '.$horas_str;//Minutos
				}elseif($difference <= '518399' && $difference >= '86400'){
					$dias = floor(date('d', $difference));
					if($dias == 1) { $dias_str = 'd&iacute;a'; }
					else { $dias_str = 'd&iacute;as'; }
					$echo = 'Hace '.$dias.' '.$dias_str;//Minutos
				}elseif($difference <= '2678399' && $difference >= '518400'){
					$semana = floor(date('d', $difference) / 7).'<!-- WTF -->';
					if($semana == 1) { $semana_str = 'semana'; }
					else { $semana_str = 'semanas'; }
					$echo = 'Hace '.floor($semana).' '.$semana_str;//Minutos
				}else { $echo = 'Hace '.floor(date('m', $difference)).' mes(es)'; }
				return $echo;
			}else{ return $a; }
		}else{ return 'A&uacute;n no se ha conectado'; }
	}

// Sacar IP
function SacarIP() {
	if($_SERVER) {
		if($_SERVER["HTTP_X_FORWARDED_FOR"]) {
		$realip = $_SERVER["HTTP_X_FORWARDED_FOR"];
		} elseif ($_SERVER["HTTP_CLIENT_IP"]) {
		$realip = $_SERVER["HTTP_CLIENT_IP"];
		} else {
		$realip = $_SERVER["REMOTE_ADDR"];
		}
	} else {
				if(getenv("HTTP_X_FORWARDED_FOR")) {
					$realip = getenv("HTTP_X_FORWARDED_FOR");
				} elseif(getenv("HTTP_CLIENT_IP")) {
					$realip = getenv("HTTP_CLIENT_IP");
				} else {
					$realip = getenv("REMOTE_ADDR");
				}
			}
	return $realip;
}
$ip = SacarIP();

// Filtros para seguridad
function filtro($str) {
		$str = mysql_real_escape_string(htmlspecialchars(trim($str)));;
		$texto = $str; // Eliminamos espacios en blanco o caracteres al principio y final del post
		$texto = str_replace("INSERT","IN-SER-T",$texto);  // Remplazamos palabras que podrian ser usadas para alterar la BD
		$texto = str_replace("DELETE","DE-LE-TE",$texto);
		$texto = str_replace("TRUNCATE","TRUN-CA-TE",$texto);
		$texto = str_replace("SELECT","SE-LEC-T",$texto);
		$texto = str_replace("ALTER","AL-TER",$texto);
		$texto = str_replace("UPDATE","UP-DA-TE",$texto);
		$texto = str_replace("inert","IN-SER-T",$texto);  // Remplazamos palabras que podrian ser usadas para alterar la BD
		$texto = str_replace("delete","DE-LE-TE",$texto);
		$texto = str_replace("truncate","TRUN-CA-TE",$texto);
		$texto = str_replace("select","SE-LEC-T",$texto);
		$texto = str_replace("alter","AL-TER",$texto);
		$texto = str_replace("update","UP-DA-TE",$texto);
		$texto = str_replace("script","",$texto);
		$texto = str_replace("SCRIPT","",$texto);
		$texto = str_replace('"','&#34;',$texto);
		$texto = str_replace("'","&#39;",$texto);
		$texto = str_replace("<","&#60;",$texto);
		$texto = str_replace(">","&#62;",$texto);
		$texto = str_replace("(","",$texto);
		$str = str_replace(")","",$texto);
		return $str;
	}
// Generar pregunta de seguridad
function generarPregunta()
{
    $preguntas = array('¿Cuanto es 2 + 2?',
        '¿Cuánto es 45 + 20?', '¿Cuánto es 80 + 80?', '¿Cuánto es 50 + 50?',
        '¿Cuánto es 40 + 40?', '¿Cuánto es 60 + 60?',
        '¿Cuánto es 30 + 30?', '¿Cuánto es 10 + 10?', '¿Cuánto es 200 + 400?',
        '¿Cuánto es 25 + 25?', '¿Cuánto es 150 + 155?');
    $respuestas = array('4', '65', '160', '100', '80', '120', '60', '20', '600', '50', '305');
    $number = rand(0, 10);
    $preg = $preguntas[$number];
    $resp = $respuestas[$number];
    $_SESSION['preg'] = $preg;
    $_SESSION['resp'] = $resp;
    return $preg;
}

// Usuarios en linea
function Onlines()
{
    $on = mysql_query("SELECT * FROM users WHERE online = '1'");
	$on1 = mysql_num_rows($on);
	$ons = $on1 . '';
    return $ons;
}

// Sesión del usuario
if(isset($_SESSION['Username']) && isset($_SESSION['Password']))
{
	$Sesion = mysql_query("SELECT * FROM users WHERE username = '". $_SESSION['Username'] ."' AND password = '". md5($_SESSION['Password']) ."'");

	// Si el usuario existe, nombramos sus datos
	if(mysql_num_rows($Sesion) > 0)
	{
		$myrow = mysql_fetch_assoc($Sesion);
		define("Loged", TRUE);
	}
}
else
{
	define("Loged", FALSE);
}

$last_new = mysql_fetch_assoc(mysql_query("SELECT * FROM cms_news ORDER BY id DESC LIMIT 1"));

## Checamos que el usuario no este baneado, si lo esta, lo manda a la página de baneado
$chb = mysql_query("SELECT * FROM bans WHERE value = '". $myrow['username'] ."' OR value = '". $myrow['ip_last'] ."'");

## Vemos si esta en mantenimiento
$mantenimiento = mysql_query("SELECT mantenimiento, motivo FROM cms_mantenimiento");
$mantenimientoo = mysql_fetch_assoc($mantenimiento);
$mant = $mantenimientoo['mantenimiento'];
define("MANTENIMIENTO", $mant);

## Contador de referidos
$referidos = mysql_query("SELECT COUNT(*) aantalleden FROM users_referidos WHERE usuario = '". $myrow['username'] ."'") or die (mysql_error());
$r = mysql_fetch_assoc($referidos);
?>