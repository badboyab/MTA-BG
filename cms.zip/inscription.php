<?php


require_once("engine/core.cms.php");

if(Loged == TRUE)
{
	header("Location: me");
	exit;
}
if(MANTENIMIENTO == '1') 
{
    header("Location: maintenance");
	exit;
}


if(isset($_POST['Usuario']) && isset($_POST['Mail']) && isset($_POST['Contrasena']) && isset($_POST['RContrasena']) && isset($_POST['DD']) && isset($_POST['MM']) && isset($_POST['AAAA']))
{   

	
    $dia = $_POST['DD'];
	$mes = $_POST['MM'];
	$ano = $_POST['AAAA'];
	
	
	$Getnombre = mysql_query("SELECT * FROM users WHERE username = '". $_POST['Usuario'] ."'");
	
	$Getmail = mysql_query("SELECT * FROM users WHERE mail = '". $_POST['Mail'] ."'");

	
	if(empty($_POST['Usuario']) || empty($_POST['Mail']) || empty($_POST['Contrasena']) || empty($_POST['RContrasena']) || empty($dia) || empty($mes) || empty($ano))
	{
		$regerror = '<p style="color: rgba(231, 76, 60, 1.0);" align="center">Ne pas laisser les champs vides</p>';
	}
	
	elseif(mysql_num_rows($Getnombre) > 0)
	{
		$regerror = '<p style="color: rgba(231, 76, 60, 1.0);" align="center">Pseudo déjà utilisé</p>';
	}
	
	elseif(mysql_num_rows($Getmail) > 0)
	{
		$regerror = '<p style="color: rgba(231, 76, 60, 1.0);" align="center">E-mail déjà utilisé</p>';
	}
	
	elseif($_POST['Contrasena'] !== $_POST['RContrasena'])
	{
		$regerror = '<p style="color: rgba(231, 76, 60, 1.0);" align="center">Les mots de pase ne coincide pas</p>';
	}
    elseif (strlen($_POST['Usuario']) > 12 || strlen($_POST['Usuario']) < 4) 
	{
        $regerror = '<p style="color: rgba(231, 76, 60, 1.0);" align="center">Le nom d utilisateur doit avoir entre 4 et 12 caractères</p>';
	} 
	elseif (strrpos($_POST['Usuario'], "MOD-") !== false) 
	{
	    $regerror = '<p style="color: rgba(231, 76, 60, 1.0);" align="center">Vous ne pouvez pas vous inscrire avec le préfixe <i>MOD-</i></p>';
    } 
	elseif (strrpos($_POST['Usuario'], " ") || strrpos($_POST['Usuario'], " ") !== false) 
	{
	    $regerror = '<p style="color: rgba(231, 76, 60, 1.0);" align="center">Votre nom ne peut pas contenir d espaces</p>';
	} 
	elseif (strrpos($_POST['Usuario'], ".") || strrpos($_POST['Usuario'], ".") !== false) 
	{
	    $regerror = '<p style="color: rgba(231, 76, 60, 1.0);" align="center">Votre nom ne peut pas contenir des points</p>';
    }
	else
	{
		mysql_query("INSERT INTO users (username, password, mail, look, gender, motto, ip_reg, monedas, photo_perfil, portada, date_created, birth) VALUES ('". filtro($_POST['Usuario']) ."', '".md5($_POST['Contrasena'])."', '". filtro($_POST['Mail']) ."', '". filtro($_POST['LOOK']) ."', '". filtro($_POST['Gender']) ."', '". $Holo['mision'] ."', '". $ip ."', '". $Holo['monedas'] ."', '". $Holo['foto_p'] ."', '". $Holo['portada'] ."', '" . time() ."', '$dia/$mes/$ano')");
		$_SESSION['Username'] = $_POST['Usuario'];
		$_SESSION['Password'] = $_POST['Contrasena'];
		header("Location: me");
	}
}

$_GET['Usuario'] = $_POST['Usuario'];
$_GET['Mail'] = $_POST['Mail'];
$_GET['Contrasena'] = $_POST['Contrasena'];
$_GET['RContrasena'] = $_POST['RContrasena'];
$_GET['DD'] = $_POST['DD'];
$_GET['MM'] = $_POST['MM'];
$_GET['AAAA'] = $_POST['AAAA'];
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title><?php echo $Holo['name']; ?> > Inscription</title>
		
		<script src="public/public/jquery.min.js.descarga"></script>
		<script>
			$(function() {
				var interval = 4000;
				var intervalF = setInterval(slide, interval);
				
				$('.control').click(function() {
					$('.active').removeClass('active');
					$('div.item:eq(' + $(this).data('goto') + ')').addClass('active');
					$('li.control:eq(' + $(this).data('goto') + ')').addClass('active');

					clearInterval(intervalF);
					intervalF = setInterval(slide, interval);
				});
			  
				function slide() {
					if ($('.active').is('.item:last-child')) {
						$('.active').removeClass('active');
						$('div.item').first().addClass('active');
						$('li.control').first().addClass('active');            
					} else {  
						$('div.active').removeClass('active').next().addClass('active'); 
						$('li.active').removeClass('active').next().addClass('active'); 
					}
				}
			});
		</script>
		
		<link href="public/public/css" rel="stylesheet" type="text/css">
		<link type="text/css" href="public/public/YeezyHalloween.css" rel="stylesheet">
		<link rel="icon" href="favicon.ico" type="image/gif">
		<script src='https://www.google.com/recaptcha/api.js'></script>
		

	</head>
	<body>
			<div id="header_top">
				<div id="start_width">
					<div id="header_logo">
						<div class="logo"></div>
						<div class="user_online">
							<b><?php echo Onlines(); ?></b> Joueur(s) en ligne
						</div>
					</div>
					<div id="header_hbg">
						<div id="header_button">
							<a href="index">
										<button class="checkin_client" value="">
											RETOUR
										</button>
									</a>						</div>
					</div>
				</div>
			</div>
<div id="web_main">
    <div id="main">

<div style="height: 20px;"></div>

<div style="float: left; height: 625px; width: 600px;display: block;background-color: #1b5067;background-image: url(&#39;http://imgur.com/01o0OiR.png&#39;);background-repeat: no-repeat;">
<p style="font-size: 20px;margin-bottom: 0px;padding: 5px;margin-left: 40px;margin-top: 165px;width: 103px;border-radius: 3px;color: white;margin-left: 200px;background: rgba(0,0,0,0.5);text-shadow: 0px 1px 1px rgba(0, 0, 0, 0.4);"> 
Vous êtes la ! </p>
<img src="http://www.habbo.nl/habbo-imaging/avatarimage?figure=hr-115-1028.lg-280-81.ch-3030-92.sh-290-92.ca-1813-62.hd-180-7" style="float: left;margin-top: 30px;margin-left: 225px;">
<div style="font-size: 20px;border-radius: 3px;color:white;float: right;margin-right: 26px;width: 250;margin-top: 20px; padding: 8px;height: 30px;background: rgba(0,0,0,0.5);">
Crédits: 50000
</div>
<div style="height: 10px;"></div>
<div style="font-size: 20px;border-radius: 3px;color:white;float: right;margin-right: 26px;width: 250;margin-top: 20px; padding: 8px;height: 30px;background: rgba(0,0,0,0.5);">
Duckets: 5000	
</div>
<div style="height: 10px;"></div>
<div style="font-size: 20px;border-radius: 3px;color:white;float: right;margin-right: 26px;width: 260;margin-top: 20px; padding: 8px;height: 30px;margin-left: 20px;background: rgba(0,0,0,0.5);">
Mission: Nouveau sur Habbo!
</div>
                </div>
				
 <div style="width: 360px;float: right;">


                <div id="ul_box">
<form action="" method="POST">
                    <div style="font-size: 28px;font-weight: 400;" id="title">Complete le formulaire</div>
					    <?php echo $regerror; ?>

															<label style="float: left;font-size: 13px;font-weight: 700;color: rgba(0,0,0,0.9);margin: 0px 25px 10px 25px;">Pseudo:</label>
<input style=" float: left;width: 280px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" class="textbox" type="text" name="Usuario" id="register" placeholder="Pseudo" value="<?php echo $_GET['Usuario']; ?>" pattern="^[A-Za-z0-9]+$">
<br>
					<label style="float: left;font-size: 13px;font-weight: 700;color: rgba(0,0,0,0.9);margin: 0px 25px 10px 25px;">Email:</label>
<input style=" float: left;width: 280px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" type="text" name="Mail" id="register" placeholder="E-mail" value="<?php echo $_GET['Mail']; ?>" class="textbox">
<br>
					<label style="float: left;font-size: 13px;font-weight: 700;color: rgba(0,0,0,0.9);margin: 0px 25px 10px 25px;">Mot de passe:</label>
<input style=" float: left;width: 280px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" type="password" name="Contrasena" id="register" placeholder="Mot de passe" value="<?php echo $_GET['Contrasena']; ?>" class="textbox">
<br>
					<label style="float: left;font-size: 13px;font-weight: 700;color: rgba(0,0,0,0.9);margin: 0px 25px 10px 25px;">Repete le mot de passe:</label>
<input style=" float: left;width: 280px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);" type="password" name="RContrasena" id="register" placeholder="Repete le mot de passe" value="<?php echo $_GET['RContrasena']; ?>" class="textbox">
	<center>
												<label style="float: left;font-size: 13px;font-weight: 700;color: rgba(0,0,0,0.9);margin: 0px 80px 10px 25px;">Date de naissance:</label>
				<center>
				    <input 
					style=" float: left;width: 55px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 50px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);"
					class="textbox" type="text" name="DD" placeholder="DD" maxlength="2" value="<?php echo $_GET['DD']; ?>" />
				
				    <input style=" float: left;width: 55px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);"
					class="textbox" type="text" name="MM" placeholder="MM" maxlength="2" value="<?php echo $_GET['MM']; ?>" />
					
				    <input style=" float: left;width: 65px;height: auto;line-height: 35px;font-size: 13px;color: rgba(0, 0, 0, 0.9);padding: 0px 0px 0px 15px;border-radius: 5px;margin: 0px 25px 10px 25px;border: 1px solid rgba(0,0,0,0.2);border-bottom: 2px solid rgba(0,0,0,0.2);box-shadow: 0px 0px 2px rgba(0,0,0,0.05);"
					class="textbox" type="text" name="AAAA" placeholder="AAAA" maxlength="4" value="<?php echo $_GET['AAAA']; ?>" />
				</center>
				

<br><br><br><br>
	<div class="g-recaptcha" data-sitekey="6Lf78AoUAAAAAOfZK-duHHfH0W-lFhUHppNbpz1T"></div>
	<script type="text/javascript" src="https://www.google.com/recaptcha/api.js?hl=fr"></script>
                        

					
<br>
<button style="width: 280px;height: 50px;margin-left: 25px; margin-top: 90px; " class="tb_bonus" type="submit" name="register" id="button" value=""><span style="cursor: pointer">Enregistrer</span></button>
<br><p style="margin-top: 350px;"><font color="#59666e">
En vous inscrivant, vous acceptez nos  <b><font color="#86a8b8"><label for="modal-1">Conditions d'utilisation</label></font></b> et confirmez que vous avez lu notre politique de confidentialité, y compris les règles relatives à l'utilisation de cookies</font></p>
                   
               </form>     

                </div></div>
<input class="modal-state" id="modal-1" type="checkbox">
<div class="modal">
  <label class="modal__bg" for="modal-1"></label>
  <div class="modal__inner">
    <label class="modal__close" for="modal-1"></label>
    <h2>Conditions d'utilisation</h2><hr>
    <p></p><h3>1. Generales</h3><br>


Notre plate-forme Internet (ci-après également appelé une communauté) offre enregistrée dans un monde virtuel où vous avez la possibilité de passer à travers un personnage créé par vous-même dans un virtuel utilisateurs d'hôtels pour faire leurs propres pages Web et pour communiquer avec d'autres utilisateurs. Les utilisateurs peuvent mettre à jour leur propre profil indépendant, avec des contenus tels que des vidéos YouTube, une section sur moi, et les médias sociaux. Le contenu fourni est le seul utilisateur de responsiblility. Chaque utilisateur est tenu de respecter les principes de la communit; En particulier, cela inclut tout contenu qui est délibérément inexactes un libility, ou rencontrer d'autres crimes qui violent les droits d'autrui. Par ailleurs, les règles normales de conduite sont respectées et Internet sont en place pour protéger les coutumes générales.<br><br>



<h3>2. Inscription et Connexion</h3><br>

1.Les principaux domaines ou les caractéristiques de notre communauté peuvent être utilisés pour des raisons de sécurité après inscription préalable. <br><br>
2.Nous nous réservons le droit de refuser un nom d'utilisateur ou de changer, surtout si elle est déjà affectée ou les conditions d'utilisation (règles) sont violés. Un utilisateur ne sera pas relancée après le retrait du compte. <br><br>
3.Votre nom d'utilisateur, si les conditions d'utilisation ne sont pas respectées ou contient d'autres caractères non valides sera rejeté lors de l'inscription. <br><br>

<h3>3. Mon contenu.</h3><br>

1.Nous nous réservons le droit de modifier le texte ou de données, supprimer et avertir l'utilisateur, fermer le compte si elle comprend un des éléments suivants: <br>
✓ contenu glorifiant la violence, le racisme ou la discrimination, promouvoir, d'approuver ou de minimiser <br>
✓ contenu nazi <br>
contenu sexiste, pornographique et inappropriée <br> ✓
✓ contenu érotique, en particulier des photos montrant une personne qui n'a pas atteint l'âge de 18 ans au moment de la formation photo <br>
✓ Contenu adulte <br>
✓ liens vers les sites d'abonnement et les numéros de péage <br>
✓ Contenu violant tout brevet, notamment le droit d'auteur et les droits (par exemple, des informations personnelles sur un autre utilisateur ou un tiers) personnel, dommageable et des commentaires désobligeants ou offensants <br>
✓ le spam <br>
✓ Les données sont adéquates, nous fait du mal ou d'induire des tiers (tels que les virus, chevaux de Troie, dialers) Guide
✓ contenu promu <br> leurs intérêts commerciaux ou financiers ou ceux d'un tiers
✓ contenus qui violent la loi ou le Code de conduite ou permettent ou encouragent la violation <br>
<br>
 2.Les sanctions possibles ou des mesures qui peuvent être exercés en violation de nous contre vous:<br>
<br>
✓ On modifie le contenu afin qu'il ne respecte pas les conditions d'utilisation. <br>
✓ Nous supprimons le contenu illégal que vous avez posté / utilisé. <br>
✓ Vous ne recevrez pas plus d'autorité, des conférences publiques / privées et publiques à écrire pour une certaine période de temps ou nous annuler le chat indéfiniment pour vous. <br>
✓ Votre compte sera bloqué sans préavis pendant une certaine période ou pour toujours par nos modérateurs ou administrateurs. <br><br>

<h3>4. Supression de ocmpte</h3><br>


1. Si vous le souhaitez, vous pouvez à tout moment demander à être retiré ou supprimé de la base de données. Nous nous réservons le droit de citer une période de compensation d'un mois, comme la suppression des données utilisateur de toutes les bases et connexes prend beaucoup de temps pour compléter les services. <br>

2. Après avoir demandé la suppression automatique vous résilier votre compte. <br>

3. Une demande d'annulation ne peut être annulée. <br>
<H3> 5. Garantie </h3> <br>

1. Nous puedemos garantissons pas que le site sera disponible en tout temps, sans interruption et / ou des erreurs, y compris un dysfonctionnement de chansons gratuites. En raison de circonstances techniques ne relevant pas du contrôle de la Société, ce qui peut conduire à des échecs; Par exemple, il pourrait y avoir une indisponibilité temporaire du site dans son intégralité. Cela vaut également dans le cas de la maintenance et des mises à niveau. Toute mise à jour ou de maintenance seront expliqués dans un délai raisonnable avant que cela arrive, et les obstacles associés aux utilisateurs de se mettre d'accord sur une mesure raisonnable sera nécessaire. <br>
<H3> 6. Politique de confidentialité </h3> <br>

1.any les données demandées par nous de vous ils seront imposées conformément à la loi sur la vie privée et la protection des données. Il peut stocker, traiter et / ou enlevés. <br>
2. Sauf si vous liez les politiques de confidentialité qui ont été expliquées dans le cadre de l'accord d'enregistrement, vous peuvent être révoqués à tout moment par e-mail avec le consentement. <br>
<H3> 7. Dispositions finales </h3> <br>

1. Politique de confidentialité, Code de conduite ( «règles») font également partie de ces conditions d'utilisation. <br>
2.Nuestra se réserve le droit de modifier les conditions d'utilisation à tout moment et vous informera en temps voulu des changements. <br>
loi 3.Se anglais applique. <P></p><br>
  </div>
</div>
<div style="clear:both;"></div>
<div style="height:20px;"></div>
<div style="clear:both;"></div>
   <div style="width: 310px;margin-right: 15px;float: left;">
 <div id="ul_box">
 <div class="subimage1"></div>
  <p><?php echo $Holo['name']; ?> Hôtel est un monde virtuel gratuit où vous pouvez parler, marcher, et les amis peuvent se rassembler. Il est également possible d'avoir votre propre chambre.</p>
 </div>
 </div>
   <div style="width: 310px;margin-right: 15px;float: left;">
 <div id="ul_box">
<div class="subimage2"></div>
  <p>En <?php echo $Holo['name']; ?> Hôtel peut faire de nouveaux amis. Discuter avec eux, jouer ou construire votre propre chambre. Vous serez divertis en <?php echo $Holo['name']; ?> Hotel!</p>
 </div>
 </div>
   <div style="width: 310px;margin-right: 0px;float: left;">
 <div id="ul_box">
<div class="subimage3"></div>
  <p>Construisez votre propre chambre, et participer à des compétitions d'envergure! Devenez l'un des plus riches de l'hôtel, rejoindre le reste et vous amuser.</p>
 </div>
 </div>

    </div>
</div>

		<div style="clear:both; height:20px;"></div>
		<div style="position: absolute; width:100%;" class="footer">
            <div id="swidth">
               <center> <font size="2" color="white">
<p style="line-height: 50px;">© 2016 Crée pour <?php echo $Holo['name']; ?> . En aucun cas liée à Sulake Corp Oy.
					
				</font></center>
            </div>
        </div>
	
</body></html>